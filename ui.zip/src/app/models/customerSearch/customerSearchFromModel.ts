export class CustomerSearchFromModel {
  constructor(
    public customerName?: String,
    public accountNo?: Number,
    public ssnTin?: Number,
    public mobilePhone?: Number
  ) {
  }
}
