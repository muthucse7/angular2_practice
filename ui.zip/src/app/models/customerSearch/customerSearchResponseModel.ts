export class CustomerSearchResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  customerDetails: CustomerDetails[];
  customerIds: CustomerIds[];
  custometContact: CustometContact[];
  customerUsbRelationship: CustomerUsbRelationship[];
  customerNonUSACitizenCountries: CustomerNonUSACitizenCountries[];
}

interface CustomerDetails {
  name: String;
  altName: String;
  occupation: String;
  nationality: String;
  dob: String;
}

interface CustomerIds {
  ssnOrTin: Number;
}

interface CustometContact {
  address1: String;
  address2: String;
  address3: String;
  address4: String;
  workPhone: String;
  homePhone: String;
  contactPhone: String;
  mobilePhone: String;
}

interface CustomerUsbRelationship {
  bankIdNo: Number;
  productNo: Number;
  accountNo: Number;
  branhcCostCtr: Number;
  kycName: String;
}

interface CustomerNonUSACitizenCountries {
  nonUsaCitizenCntry1: String;
  nonUsaCitizenCntry2: String;
  nonUsaCitizenCntry3: String;
  nonUsaCitizenCntry4: String;
  nonUsaCitizenCntry5: String;
  cntryOfPrimaryRes: String;
  cntryOfAddRes1: String;
  cntryOfAddRes2: String;
  cntryOfAddRes3: String;
  cntryOfAddRes4: String;
  cntryOfAddRes5: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
