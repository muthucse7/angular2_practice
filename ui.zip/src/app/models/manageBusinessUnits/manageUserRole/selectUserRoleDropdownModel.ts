interface SelectUserRoleDropdownModel {
  userName: String;
  userId: Number;
}
