export class ManageBUUserRoleModel {
  constructor(
    public userName?: String,
    public userId?: Number,
    public buRoleName?: String,
    public buRoleId?: Number,
    public buName?: String,
    public buId?: Number,
    public buUserRoleMappingId?: Number
  ) {
  }
}
