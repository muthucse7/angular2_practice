export class ManageBUCreateAndUpdateResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buId: Number;
  buName: String;
  buShortName: String;
  buContactPerson: String;
  buEmailId: String;
  active: String;
  createdDate: String;
  createdBy: String;
  lastUpdateDate: String;
  lastUpdatedBy: String;
  uIComponentID: String;
  buSupportUnit: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
