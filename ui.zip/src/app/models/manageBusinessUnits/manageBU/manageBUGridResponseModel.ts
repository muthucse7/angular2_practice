export class ManageBUGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buId: Number;
  buName: String;
  buShortName: String;
  active: String;
  buContactPerson: String;
  buEmailId: String;
  createdDate: String;
  createdBy: String;
  lastUpdateDate: String;
  lastUpdatedBy: String;
  uIComponentID: String;
  buSupportUnit: String;
  unitName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
