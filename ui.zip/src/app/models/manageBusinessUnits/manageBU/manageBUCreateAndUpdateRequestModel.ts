export class ManageBUCreateAndUpdateRequestModel {

  public buId: Number;
  public buName: String;
  public buShortName: String;
  public buContactPerson: String;
  public buEmailId: String;
  public buSupportUnit: String;
  public unitName: String;
  public active: String;
  public uIComponentID = 'AUTHORIZATION_BU_CREATE';

}





