export class ManageBUComponentModel {
  constructor(
    public buId = '',
    public uIComponentID = 'AUTHORIZATION_BU'
  ) {
  }
}



