export class ManageBURoleModel {
  constructor(
    public buRoleName?: String,
    public roleName?: String,
    public active?: String,
    public buRoleId?: Number,
    public functionName?: String,
    public functionId?: Number,
  ) {
  }
}
