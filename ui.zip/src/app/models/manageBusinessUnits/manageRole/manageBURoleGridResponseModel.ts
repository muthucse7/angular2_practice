export class ManageBURoleGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buRoleId: Number;
  active: String;
  reqref: Number;
  buId: Number;
  format: String;
  fromDate: Date;
  toDate: Date;
  submittedDate: Data;
  status: String;
  requestType: String;
  buName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
