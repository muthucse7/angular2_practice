export class SelectBUFunctionDropdownResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  functionName: String;
  functionId: Number;

}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: String[];
}
