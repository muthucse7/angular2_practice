export class ManageBUFunctionGridResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buRoleName: String;
  buFunctionName: String;
  functionName: String;
  functionId: Number;
  buRoleId: Number;
  userName: String;
  userId: Number;
  buName: String;
  buId: Number;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
