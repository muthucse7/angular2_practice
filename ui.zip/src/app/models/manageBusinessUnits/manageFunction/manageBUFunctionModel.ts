export class ManageBUFunctionModel {
  constructor(
    public selectRole?: String,
    public selectFunction?: String
  ) {
  }
}
