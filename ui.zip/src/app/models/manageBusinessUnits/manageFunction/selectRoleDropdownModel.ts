interface SelectRoleDropdownModel {
  buRoleName: String;
  buRoleId: Number;
}
