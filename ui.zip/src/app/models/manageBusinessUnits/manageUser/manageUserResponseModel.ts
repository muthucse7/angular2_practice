export class ManageUserResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  userId: Number;
  buId: Number;
  firstName: String;
  lastName: String;
  networkId: String;
  email: String;
  active: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
