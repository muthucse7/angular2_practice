export class ManageUserCreateAndUpdateRequestModel {

  public userId?: Number;
  public firstName?: String;
  public lastName ?: String;
  public networkId?: String;
  public email?: String;
  public createdDate?: String;
  public createdBy?: String;
  public lastUpdateDate?: String;
  public lastUpdatedBy?: String;
  public active: String;
  public uIComponentID = 'AUTHORIZATION_BU_CREATE';

}



