export class ManageUserModel {
  constructor(
    public firstName?: String,
    public lastName?: String,
    public networkID?: String,
    public emailID?: String,
    public active?: String,
    public manageUserId?: Number
  ) {
  }
}
