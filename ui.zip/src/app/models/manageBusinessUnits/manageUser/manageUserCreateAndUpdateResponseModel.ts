export class ManageUserCreateAndUpdateResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  userId: Number;
  firstName: String;
  lastName: String;
  networkId: String;
  email: String;
  active: String;
  createdDate: String;
  createdBy: String;
  lastUpdateDate: String;
  lastUpdatedBy: String;
  uIComponentID: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
