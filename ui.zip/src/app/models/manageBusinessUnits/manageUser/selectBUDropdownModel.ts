interface SelectBUDropdownModel {
  buName: String;
  buId: Number;
}
