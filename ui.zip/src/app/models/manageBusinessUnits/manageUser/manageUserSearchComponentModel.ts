export class ManageUserSearchComponentModel {
  constructor(
    public selectBU?: String,
    public firstName?: String,
    public lastName?: String,
  ) {
  }
}
