export class TxnRescanningSeachComponentModel {
  constructor(
   /* public buName?: String,*/
    public selectBU?: String,
    public buId?: Number,
    public formatName?: String,
    public formatId?: Number,
    public fromDate?: Date,
    public toDate?: Date
  ) {
  }
}
