export class RescanStatusCompletedModel {
    public rescanRequestId?: Number;
    public messageId?: String;
    public status?: String;
    public decision?: String;
    public buName?: String

}
