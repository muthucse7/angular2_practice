export class RescanStatusCompletedResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  messageId: String;
  decision: String;
  buName: String;
  rescanDt: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
