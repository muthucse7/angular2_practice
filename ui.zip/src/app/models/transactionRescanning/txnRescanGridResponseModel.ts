export class TxnRescanGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  rescanRequestId: Number;
  buId: Number;
  format: String;
  fromDate: Date;
  toDate: Date;
  status: String;
  buName: String;
  submittedDt: Date;
  messageId: Number;
  decision: String;
  uIComponentID: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
