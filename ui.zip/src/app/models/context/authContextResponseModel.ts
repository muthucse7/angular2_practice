export class AuthContextResponseModel {
  context: Context[];
  token: String;
  metadata: Metadata;
  userInfo: UserInfo;
  userId: String;
}

interface Context {
  bu: Bu;
  role: Role[];
  functions: Functions[];
}

interface Bu {
  buId: Number;
  buName: String;
  buShortName: String;
  buContactPerson: String;
  buEmailId: String;
  active: String;
  unitName: String;
  uIComponentID: String;
}

interface Role {
  buRoleName: String;
  uiRole: String[];
}

interface Functions {
  buFunctionName: String;
  buFunctionKey: String;
  buFunctionLevel: String;
}

interface UserInfo {
  userName: String;
  userNetworkId: String;
  ofacDashboardAccess: Boolean;
  isMultiBUAccess: Boolean;
  buSupportUnit: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}

