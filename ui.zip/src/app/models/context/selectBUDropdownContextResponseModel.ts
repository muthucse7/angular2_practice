export class SelectBUDropdownContextResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buUsersViewId: Number;
  buId: Number;
  buName: String;
  buShortName: String;
  buContactPerson: String;
  buEmailId: String;
  buStatus: String;
  buRoleName: String;
  buFunctionName: String;
  userName: String;
  userNetworkId: String;
  buUserRoleMappingId: String;
  buFunctionKey: String;
  buFunctionLevel: String;
  uiRole: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
