export class CrudConfigGridResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  configId: Number;
  key: String;
  value: Number;
  active: String;
  categoryID: Number;
  subCategoryID: Number;
  categoryName: String;
  subCategoryName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
