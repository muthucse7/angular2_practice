export class SelectFormatResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  key: String;
  value: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: String[];
}
