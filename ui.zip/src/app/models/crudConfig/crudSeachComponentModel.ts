export class CrudSearchComponentModel {
  constructor(
    public categoryName?: String,
    public subCategoryName?: String,
    public key1?: String,
    public value1?: String,
    public categoryID?: Number,
    public subCategoryID?: Number,
    public active?: String
  ) {
  }
}
