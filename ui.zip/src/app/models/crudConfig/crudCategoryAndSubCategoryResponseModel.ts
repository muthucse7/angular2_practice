export class CrudCategoryAndSubCategoryResponseModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  categoryID: Number;
  categoryName: String;
  subCategoryID: Number;
  subCategoryName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: String[];
}
