interface SubCategoryDropdownModel {
  subCategoryName: String;
  subCategoryID: Number;
}
