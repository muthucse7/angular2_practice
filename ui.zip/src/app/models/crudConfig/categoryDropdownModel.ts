interface CategoryDropdownModel {
  categoryName: String;
  categoryID: Number;
}
