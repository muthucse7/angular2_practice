export class CrudConfigAddAndUpdateRequestModel {
  public configId: Number;
  public category: Category[];
  public subCategory: SubCategory[];
  public key: String;
  public value: String;
  public active: String;
}

interface Category {
  categoryID: Number;
  categoryName: String;
}

interface SubCategory {
  subCategoryID: Number;
  subCategoryName: String;
}
