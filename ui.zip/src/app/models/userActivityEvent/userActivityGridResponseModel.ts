export class UserActivityGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  activityId: Number;
  userId: String;
  userName: String;
  eventLogDt: String;
  dashboardPage: String;
  dashboardFunction: String;
  newDeatil: String;
  oldDetail: Date;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
