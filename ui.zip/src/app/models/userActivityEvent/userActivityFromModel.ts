export class UserActivityFromModel {
  constructor(
    public activityId?: number,
    public userId?: String,
    public userName?: String,
    public eventLogFromDt?: Date,
    public eventLogToDt?: Date,
    public eventLogDt?: Date,
    public dashboardPage?: String,
    public dashboardFunction?: String,
    public newDeatil?: String,
    public oldDetail?: String,
    public uIComponentID?: String
  ) {
  }
}
