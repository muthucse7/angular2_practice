export class ReportRescreenReconResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  rescanRequestId: Number;
  buName: String;
  format: String;
  messageId: String;
  previousScreenDt: String;
  previousResult: String;
  previousFCTYState: String;
  rescreenScreenDt: String;
  rescreensResult: String;
  rescreenFCTYState: String;
  initSystemId: String;
  rescreenSystemId: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
