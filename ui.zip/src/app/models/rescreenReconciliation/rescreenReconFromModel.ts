export class RescreenReconFromModel {
  constructor(
    public reportType?: String,
    public rescanRequestID?: Number
  ) {
  }
}
