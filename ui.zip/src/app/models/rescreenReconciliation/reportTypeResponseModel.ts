export class ReportTypeResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  key: String;
  value: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
