export class DashboardOverallSummary {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  dashboardSummaryList: DashboardSummaryList[],
  summaryTotal: SummaryTotal
}

interface SummaryTotal {
  screenDate: String;
  sumTotalNoHits: Number;
  sumTotalHits: Number;
  sumTotalOpen: Number;
  sumTotalReceived: Number;
  sumTotalOpenFinalHits: Number;
  sumTotalPercentageHits: Number;
  sumTotalStopRate: Number;

}

interface DashboardSummaryList {
  businessUnit: String;
  totalReceived: Number;
  totalNoHits: Number;
  totalHits: Number;
  totalOpenFinalHits: Number;
  totalPercentageHits: Number;
  totalOpen: Number;
  totalStopRate: Number;
  dashboardType: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: String;
  errorDesc: String;
}

