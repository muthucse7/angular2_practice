export class DashboardListMgt {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  fileName: String;
  startDate: String;
  endDate:String;
  status:String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}

