export class BatchStatusModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  batchName: String;
  batchStatus: String;
  jobType: String;
  serverTier: String;
  lastRanDate: Date;
  scheduledRunDate: Date;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: String;
  errorDesc: String;
}

