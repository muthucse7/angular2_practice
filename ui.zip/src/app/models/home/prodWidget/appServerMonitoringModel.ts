export class AppServerMonitoringModel {
    data: Data[];
    metadata: Metadata;
  }
  
  interface Data {
    configId: Number;
    id: Number;
    componentType: String;
    componentName: String;
    lastJobRunDate: String;
    componentStatus : String;
    subComponent: String;
    moduleType: String;
    uIComponentID: String;
  }
  
  interface Metadata {
    uIComponentID: String;
    dataCount: Number;
    status: String;
    errorMsg: ErrorMsg[];
  }
  
  interface ErrorMsg {
    errorCode: Number;
    errorDesc: String;
  }
