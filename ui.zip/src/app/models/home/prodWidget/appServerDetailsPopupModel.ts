export class AppServerDetailsPopupModel {
    data: Data[];
    metadata: Metadata;
  }
  
  interface Data {
    componentName: String;
    serverName: String;
    subComponent:String;
    serverEnvironment: String;
    flag: String;
    runningSince: String;
  }
  
  interface Metadata {
    uIComponentID: String;
    dataCount: Number;
    status: String;
    errorMsg: ErrorMsg[];
  }
  
  interface ErrorMsg {
    errorCode: Number;
    errorDesc: String;
  }

