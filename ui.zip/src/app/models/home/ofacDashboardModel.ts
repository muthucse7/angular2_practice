export class OfacDashboardModel {
  response: Response[];
  metadata: Metadata;
}

interface Response {
  data: Data[];
  dataset: Dataset;
  metadata: Metadata;
}

interface Data {
  productId: Number;
  category: String;
  subcategory: String;
  country: String;
  hits: Number;
  coe_success: Number[];
  coe_failed: Number[];
  coe_pending: Number[];
  coe_submitted: Number[];
  prdId: Number;
  name: String;
  date: Date;
  status: String;
  messageReceived: Number;
  messageWithNoHits: Number;
  messageWithHits: Number;
  totalHits: Number;
  percentageOfHitRate: Number;
  hitsPendingReview: Number;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface Dataset {
  prd_failedCount: Number[];
  prd_inProgressCount: Number[];
  prd_activeCount: Number[];
}


interface ErrorMsg {
  errorCode: String;
  errorDesc: String;
}

