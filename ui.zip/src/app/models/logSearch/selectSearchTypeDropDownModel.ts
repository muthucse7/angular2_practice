interface SelectSearchTypeDropdownModel {
  value: String;
  key: String;
}

