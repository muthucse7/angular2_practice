export class LogSearchComponentModel {
  constructor(
    public searchType?: String,
    public buName?: String,
    public buId?: Number,
    public contextId?: String,
    public transactionId?: String,
    public fromDate?: Date,
    public toDate?: Date
  ) {
  }
}
