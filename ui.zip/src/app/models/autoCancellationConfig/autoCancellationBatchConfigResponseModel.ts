export class AutoCancellationBatchConfigResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  isAutoPassBatchRunning: String;
  lastAutoPassBatchCompletedDateTime: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
