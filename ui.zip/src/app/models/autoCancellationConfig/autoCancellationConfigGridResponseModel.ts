export class AutoCancellationConfigGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  autoSuspendPassConfigId: Number;
  autoAction: String;
  isActive: String;
  status: String;
  startCutoffTime: Date;
  endCutoffTime: Date;
  runFrequencyMins: Number;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
