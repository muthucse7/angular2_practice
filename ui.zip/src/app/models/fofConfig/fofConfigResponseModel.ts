export class FofConfigGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  userId: Number;
  buId: Number;
  businessType: String;
  format: String;
  hitRateMax: String;
  hitRateMin: String;
  dataDays: String;
  fofDataConfigId: Number;
  updatedDate: String;
  createdDate: String;
  createdBy: String;
  updatedBy: String;
  active: String;
  status: String;
  uiComponentID: String;

}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
