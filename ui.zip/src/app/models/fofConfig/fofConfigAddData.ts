export class FofAddDataModel {
  constructor(
    public selectBU?: String,
    public formatName?: String,
    public hitRateMax?: Number,
    public hitRateMin?: Number,
    public dataDays?: Number
  ) {
  }
}
