export class FofConfigCreateAndUpdateRequestModel {

  public userId?: Number;
  public businessType?: String;
  public format ?: String;
  public createdBy?: String;
  public updatedBy?: String;
  public active?: String;
  public uiComponentID = 'FOFTEST_DATA_CONFIG';
  public hitRateMin?: String;
  public hitRateMax?: String;
  public dataDays?: String;
  public fofDataConfigId?: Number;
  public randomSampleSizeIsActive?: String;
  public randomSampleSizePerDay?: Number;
  updatedDate?: String;
  createdDate?: String

}



