export class FofTestConfigEnabledComponentModel {
  constructor(
    public active?: String
  ) {
  }
}
