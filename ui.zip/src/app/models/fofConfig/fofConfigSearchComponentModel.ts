export class FofConfigSearchComponentModel {
  constructor(
    public selectBU?: String,
    public formatName?: String,
    public uiComponentID?: String
  ) {
  }
}
