interface BusinessTypeDropdownModel {
  businessType: String;
  businessId: String;
}
