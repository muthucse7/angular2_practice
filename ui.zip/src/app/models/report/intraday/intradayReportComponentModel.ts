export class IntradayReportComponentModel {
  constructor(
    public selectBU?: String,
    public operatorId?: String
  ) {
  }
}
