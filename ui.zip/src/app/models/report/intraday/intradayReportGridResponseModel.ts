export class IntradayReportGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buId: Number;
  buName: String;
  operatorId: String;
  state: String;
  volume: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
