interface SelectOperatorDropdownModel {
  operatorName: String;
  operatorId: String;
}


