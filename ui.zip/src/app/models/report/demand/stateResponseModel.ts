export class StateResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  referenceId: Number;
  buId: Number;
  buName: String;
  operatorId: String;
  messageType: String;
  transactionType: String;
  initialStatusDate: String;
  remidiationStatusId: Number;
  remidiationStatus: String;
  remidiationDate: String;
  startDateTime: String;
  endDateTime: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
