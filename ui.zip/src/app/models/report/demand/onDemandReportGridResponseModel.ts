export class OnDemandReportGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  referenceId: String;
  buName: String;
  operatorId: String;
  messageType: String;
  transactionType: String;
  initialStatusDate: String;
  remidiationStatusId: String;
  remidiationStatus: String;
  remidiationDate: String;
  startDateTime: String;
  endDateTime: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
