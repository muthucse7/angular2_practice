export class OnDemandReportComponentModel {
  constructor(
    public selectBU?: String,
    public operatorId?: String,
    public stateId?: String,
    public startTime?: String,
    public endTime?: String

  ) {
  }
}
