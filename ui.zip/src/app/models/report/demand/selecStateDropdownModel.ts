interface SelectStateDropdownModel {
  remidiationStatusId: Number;
  remidiationStatus: String;
}
