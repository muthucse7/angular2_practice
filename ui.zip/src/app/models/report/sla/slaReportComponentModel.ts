export class SlaReportComponentModel {
  constructor(
    public selectBU?: String,
    public stateId?: String,
    public startTime?: String,
    public endTime?: String

  ) {
  }
}
