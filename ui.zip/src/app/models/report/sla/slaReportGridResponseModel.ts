export class SlaReportGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  minutesBU: String;
  min0to30: Number;
  min30to60: Number;
  min60to90: Number;
  min90to120: Number;
  min120to150: Number;
  min150to180: Number;
  min180to210: Number;
  min210to240: Number;
  min240plus: Number;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
