export class ProductionReportGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  buName: String;
  totalMessageRecived: Number;
  stopRate: Number;
  messagesHits: Number;
  totalHits: Number;
  alertRate: Number;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
