export class ProductionReportSearchComponentModel {
  constructor(
    public buName?: String,
    public startDateTime?: Date,
    public endDateTime?: Date,
    public uIComponentID?: String
  ) {
  }
}
