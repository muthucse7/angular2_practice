export class LoginFormComponentModel {
  constructor(
    public username?: String,
    public password?: String
  ) {
  }
}
