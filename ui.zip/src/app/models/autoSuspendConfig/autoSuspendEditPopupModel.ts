export class AutoSuspendEditPopupModel {
  constructor(
    public autoSuspendPassConfigIdModal?: Number,
    public autoActionModal?: String,
    public statusModal?: String,
    public startCutoffTimeModal?: Date,
    public endCutoffTimeModal?: Date,
    public runFrequencyMinsModel?: Number
  ) {
  }
}
