export class AutoSuspendPassBatchConfigResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  autoAction: String;
  batchRunning: String;
  batchCompleteTime: String;
  serverName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
