interface ModuleNameDropdownModel {
  moduleName: String;
  moduleId: Number;
}

