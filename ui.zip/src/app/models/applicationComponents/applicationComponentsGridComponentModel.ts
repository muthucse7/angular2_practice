export class ApplicationComponentsGridComponentModel {
  constructor(
    public configId?: Number,
    public moduleName?: String,
    public moduleId?: Number,
    public serverName?: String,
    public serverId?: Number,
    public componentName?: String,
    public componentId?: Number,
    public serverStatus?: String, 
    public serverType?: String
  ) {
  }
}
