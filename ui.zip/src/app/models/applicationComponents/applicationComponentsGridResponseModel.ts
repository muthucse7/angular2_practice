export class ApplicationComponentsGridResponseModel {
  data: Data[];
  metadata: Metadata;
}

interface Data {
  configId: Number;
  moduleId: Number;
  moduleName: String;
  componentId: Number;
  componentName: String;
  serverId: Number;
  serverName: String;
}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: ErrorMsg[];
}

interface ErrorMsg {
  errorCode: Number;
  errorDesc: String;
}
