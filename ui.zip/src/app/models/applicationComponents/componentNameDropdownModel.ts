interface ComponentNameDropdownModel {
  componentName: String;
  componentId: Number;
}
