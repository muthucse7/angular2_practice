export class ApplicationComponentDropdownResponseModel {
  data:Data[];
  metadata: Metadata;
}


interface Data {
  moduleId: Number;
  moduleName: String;
  componentId: Number;
  componentName: String;
  serverId: Number;
  serverName: String;

}

interface Metadata {
  uIComponentID: String;
  dataCount: Number;
  status: String;
  errorMsg: String[];
}
