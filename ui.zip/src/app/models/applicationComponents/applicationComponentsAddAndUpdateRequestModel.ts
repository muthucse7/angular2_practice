export class ApplicationComponentsAddAndUpdateRequestModel {
  public configId: Number;
  public module: Module[];
  public server: Server[];
  public component: Component[];
  public serverStatus: String;
  public serverType : String;
}

interface Module {
  moduleId: Number;
  moduleName: String;
}

interface Server {
  serverId: Number;
  serverName: String;
}

interface Component {
  componentId: Number;
  componentName: String;
}
