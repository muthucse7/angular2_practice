interface ServerNameDropdownModel {
  serverName: String;
  serverId: Number;
}
