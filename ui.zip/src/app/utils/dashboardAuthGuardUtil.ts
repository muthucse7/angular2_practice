export class DashboardAuthGuardUtil {
  /**
   * Preparing UI menu options to enable in the dashboard UI
   * @param context
   * @returns {any[dashboardActiveMenuItem]}
   */
  roleMappingWithFunction(context) {
    let dashboardActiveMenuItem = [];
    context.functions.filter(uiComponentName => {
      if (
        uiComponentName.buFunctionKey !== null &&
        uiComponentName.buFunctionKey !== undefined
      ) {
        if (uiComponentName.buFunctionKey === "crudConfig") {
          dashboardActiveMenuItem.push("isCrudConfigEnabled");
        } else if (uiComponentName.buFunctionKey === "manageBU") {
          dashboardActiveMenuItem.push("isManageBUEnabled");
        } else if (uiComponentName.buFunctionKey === "manageUser") {
          dashboardActiveMenuItem.push("isManageUserEnabled");
        } else if (uiComponentName.buFunctionKey === "manageRole") {
          dashboardActiveMenuItem.push("isManageRoleEnabled");
        } else if (uiComponentName.buFunctionKey === "manageUserRole") {
          dashboardActiveMenuItem.push("isManageUserRoleEnabled");
        } else if (uiComponentName.buFunctionKey === "manageFunction") {
          dashboardActiveMenuItem.push("isManageFunctionEnabled");
        } else if (uiComponentName.buFunctionKey === "tnxRescanning") {
          dashboardActiveMenuItem.push("isTnxRescanningEnabled");
        } else if (uiComponentName.buFunctionKey === "logSearch") {
          dashboardActiveMenuItem.push("isLogSearchEnabled");
        } else if (uiComponentName.buFunctionKey === "slaReport") {
          dashboardActiveMenuItem.push("isSlaEnabled");
        } else if (
          uiComponentName.buFunctionKey === "performanceManagementReport"
        ) {
          dashboardActiveMenuItem.push("isPerformanceManagementReportEnabled");
        } else if (uiComponentName.buFunctionKey === "onDemandReporting") {
          dashboardActiveMenuItem.push("isOnDemandReportingEnabled");
        } else if (uiComponentName.buFunctionKey === "fofTestDataConfig") {
          dashboardActiveMenuItem.push("isFofTestDataConfigEnabled");
        } else if (uiComponentName.buFunctionKey === "productionReport") {
          dashboardActiveMenuItem.push("isProductionReportEnabled");
        } else if (uiComponentName.buFunctionKey === "applicationComponents") {
          dashboardActiveMenuItem.push("isApplicationComponentsEnabled");
        } else if (uiComponentName.buFunctionKey === "userActivityEvent") {
          dashboardActiveMenuItem.push("isUserActivityEventEnabled");
        }else if (uiComponentName.buFunctionKey === "autoSuspendConfig") {
          dashboardActiveMenuItem.push("isAutoSuspendConfigEnabled");
        }else if (uiComponentName.buFunctionKey === "autoCancellationConfig") {
          dashboardActiveMenuItem.push("isAutoCancellationConfigEnabled");
        }else if (uiComponentName.buFunctionKey === "rescreenRecon") {
          dashboardActiveMenuItem.push("isRescreenReconciliationEnabled");
        }else if (uiComponentName.buFunctionKey === "customerSearch") {
          dashboardActiveMenuItem.push("isCustomerSearchEnabled");
        }else if (uiComponentName.buFunctionKey === "customerResearch") {
          dashboardActiveMenuItem.push("isCustomerResearchEnabled");
        }
      }
    });

    return dashboardActiveMenuItem;
  }

  /**
   * Enabling component based on the user role
   * @param loggedIn_userRole
   * @returns {any}
   */
  isRoleAccessEnabled(loggedIn_userRole) {
    let isRoleAccessEnabled;
    const authContext = JSON.parse(localStorage.getItem("context"));
    authContext.context.filter(context => {
      context.role.filter(role => {
        role.uiRole.filter(logged_role => {
          if (
            logged_role !== null &&
            logged_role.toUpperCase() === loggedIn_userRole
          ) {
            isRoleAccessEnabled = true;
          }
        });
      });
    });
    return isRoleAccessEnabled;
  }

  /**
   * Enable Read and Write access for the logged-in user
   */
  enableReadAndWriteAccess() {
    localStorage.setItem("isCreateRescanEnabled", "");
    localStorage.setItem("isHomeSummaryViewEnabled", "");
    localStorage.setItem("isHomeAgingSummaryViewEnabled", "");
    localStorage.setItem("isHomeListMgmtViewEnabled", "");
    localStorage.setItem("isHomeProdSupportViewEnabled", "");
    localStorage.setItem("isAutoSuspendRequestEnabled", "");
    localStorage.setItem("isAutoPassRequestEnabled", "");

    const authContext = JSON.parse(localStorage.getItem("context"));
    if (authContext != null) {
      authContext.context.filter(context => {
        context.functions.filter(uiComponentName => {
          if (
            uiComponentName.buFunctionKey !== null &&
            uiComponentName.buFunctionKey !== undefined &&
            uiComponentName.buFunctionLevel.toUpperCase() === "FUNCTION"
          ) {
            if (uiComponentName.buFunctionKey === "createRescan") {
              // Storing the values in the session object
              localStorage.setItem(
                "isCreateRescanEnabled",
                JSON.stringify(true)
              );
            } else if (uiComponentName.buFunctionKey === "homeSummaryView") {
              localStorage.setItem(
                "isHomeSummaryViewEnabled",
                JSON.stringify(true)
              );
            } else if (
              uiComponentName.buFunctionKey === "homeAgingSummaryView"
            ) {
              localStorage.setItem(
                "isHomeAgingSummaryViewEnabled",
                JSON.stringify(true)
              );
            } else if (uiComponentName.buFunctionKey === "homeListMgmtView") {
              localStorage.setItem("isHomeListMgmtViewEnabled",JSON.stringify(true));
            } else if (uiComponentName.buFunctionKey === "homeProdSupportView") {
              localStorage.setItem("isHomeProdSupportViewEnabled",JSON.stringify(true));
            } else if (uiComponentName.buFunctionKey === "createAutoSuspendRequest") {
              localStorage.setItem("isAutoSuspendRequestEnabled",JSON.stringify(true));
            } else if (uiComponentName.buFunctionKey === "createAutoPassRequest") {
              localStorage.setItem("isAutoPassRequestEnabled",JSON.stringify(true));
            }
          }
        });
      });
    }
  }
}
