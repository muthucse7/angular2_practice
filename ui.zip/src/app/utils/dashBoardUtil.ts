import * as moment from 'moment';

export class DashBoardUtil {

  // List Management charts 
  public categories: any[] = [];
  public completedStatus: any[] = [];
  public failedStatus: any[] = [];
  public pendingReviewStatus: any[] = [];


  convertMMDDYYYYFormat(selectedDate) {
    let d = new Date(selectedDate),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  // Mapping business unit and color codes
  getChartColorCodes(overallSummaryBLs) {
    let finalColorCOdes = [];
    overallSummaryBLs.forEach(function (response) {
      if (response.businessUnit === 'ACH') {
        finalColorCOdes.push('#3399FF');
      } else if (response.businessUnit.toUpperCase() === 'ACH GA') {
        finalColorCOdes.push('#33CCFF');
      } else if (response.businessUnit.toUpperCase() === 'CDIRA') {
        finalColorCOdes.push('#BFBFBF');
      } else if (response.businessUnit.toUpperCase() === 'DI') {
        finalColorCOdes.push('#FFCC99');
      } else if (response.businessUnit.toUpperCase() === 'DP') {
        finalColorCOdes.push('#FFFF99');
      } else if (response.businessUnit.toUpperCase() === 'FX') {
        finalColorCOdes.push('#CC66FF');
      } else if (response.businessUnit.toUpperCase() === 'GDS') {
        finalColorCOdes.push('#339966');
      } else if (response.businessUnit.toUpperCase() === 'ICS') {
        finalColorCOdes.push('#990099');
      } else if (response.businessUnit.toUpperCase() === 'IR') {
        finalColorCOdes.push('#00CC99');
      } else if (response.businessUnit.toUpperCase() === 'LS') {
        finalColorCOdes.push('#A50021');
      } else if (response.businessUnit.toUpperCase() === 'RTP') {
        finalColorCOdes.push('#FF6600');
      } else if (response.businessUnit.toUpperCase() === 'WMIS') {
        finalColorCOdes.push('#4121B7');
      } else if (response.businessUnit.toUpperCase() === 'WIRES') {
        finalColorCOdes.push('#F132F7');
      } else if (response.businessUnit.toUpperCase() === 'WIRES FG') {
        finalColorCOdes.push('#05CF0A');
      }
    });
    return finalColorCOdes;
  }

  // Get the current date
  getCurrDate_MMDDYYYY_format() {
    let today = new Date, dd = today.getDate(), mm = today.getMonth() + 1, yyyy = today.getFullYear(), todayDate;
    if (dd < 10) {
      dd = parseInt('0' + dd);
    }
    if (mm < 10) {
      mm = parseInt('0' + mm);
    }

    todayDate = mm + '/' + dd + '/' + yyyy;
    return todayDate;
  }

  // CST = America/Chicago format = 'YYYY/MM/DD HH:mm:ss
  getDateAndTimeFormat(date, time) {
    let fromattedDate = moment(date).format('YYYY/MM/DD'),
      fromatToDate = moment(time).format('HH:mm:ss');
    return fromattedDate + " " + fromatToDate;
  }

  // get date for export XL title
  getExportXLDateFormat(date) {
    return (moment(date).format('MM-DD-YYYY') +"_"+date.getHours() + "-" + date.getMinutes() + "-" + date.getSeconds()).toString();
  }

  // Prepare List Management 3 month of data
  getListMgntChartData(listmgnt) {
    this.clearListMgntData();
    this.getCurrntMonthData(listmgnt);
    this.getPreviosMonthData(listmgnt);
    this.getPrevios2MonthData(listmgnt);
    this.getPrevios3MonthData(listmgnt);
    return { categories: this.categories, completed: this.completedStatus, pendingReview: this.pendingReviewStatus, failed: this.failedStatus };
  }

  getCurrntMonthData(listmgnt) {
    const currentMonth = this.getMonthToCompare(new Date().getMonth());
    let completedCount = 0;
    let pendingReviewCount = 0;
    let failedCount = 0;

    listmgnt.forEach(data => {

      // Calculating current month data
      if (currentMonth == this.findMonthFromString(data.startDate)) {

        // Inserting current month Catgory value
        if (!(this.categories.indexOf(this.getMonthInstring(this.findMonthFromString(data.startDate))) > -1)) {
          this.categories.push(this.getMonthInstring(this.findMonthFromString(data.startDate)));
        }

        // Calcluating status values
        if (data.status.toUpperCase() === 'COMPLETED') {
          completedCount++;
        } else if (data.status.toUpperCase() === 'FOFTEST STOPPED') {
          pendingReviewCount++;
        } else if (data.status.toUpperCase() === 'FAILED') {
          failedCount++;
        }
      }
    });

    if ((completedCount != 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount != 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount == 0)) {
      this.completedStatus.push(completedCount);
      this.pendingReviewStatus.push(pendingReviewCount);
      this.failedStatus.push(failedCount);
    }
  }

  getPreviosMonthData(listmgnt) {
    const previosMonth = this.getMonthToCompare(new Date().getMonth() - 1);
    let completedCount = 0;
    let pendingReviewCount = 0;
    let failedCount = 0;

    listmgnt.forEach(data => {

      // Calculating current month data
      if (previosMonth == this.findMonthFromString(data.startDate)) {
        // Inserting current month Catgory value
        if (!(this.categories.indexOf(this.getMonthInstring(this.findMonthFromString(data.startDate))) > -1)) {
          this.categories.push(this.getMonthInstring(this.findMonthFromString(data.startDate)));
        }

        // Calcluating status values
        if (data.status.toUpperCase() === 'COMPLETED') {
          completedCount++;
        } else if (data.status.toUpperCase() === 'FOFTEST STOPPED') {
          pendingReviewCount++;
        } else if (data.status.toUpperCase() === 'FAILED') {
          failedCount++;
        }
      }
    });
    if ((completedCount != 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount != 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount == 0)) {
      this.completedStatus.push(completedCount);
      this.pendingReviewStatus.push(pendingReviewCount);
      this.failedStatus.push(failedCount);
    }
  }

  getPrevios2MonthData(listmgnt) {
    const previos2Month = this.getMonthToCompare(new Date().getMonth() - 2);
    let completedCount = 0;
    let pendingReviewCount = 0;
    let failedCount = 0;

    listmgnt.forEach(data => {

      // Calculating current month data
      if (previos2Month == this.findMonthFromString(data.startDate)) {
        // Inserting current month Catgory value
        if (!(this.categories.indexOf(this.getMonthInstring(this.findMonthFromString(data.startDate))) > -1)) {
          this.categories.push(this.getMonthInstring(this.findMonthFromString(data.startDate)));
        }

        // Calcluating status values
        if (data.status.toUpperCase() === 'COMPLETED') {
          completedCount++;
        } else if (data.status.toUpperCase() === 'FOFTEST STOPPED') {
          pendingReviewCount++;
        } else if (data.status.toUpperCase() === 'FAILED') {
          failedCount++;
        }
      }
    });

    if ((completedCount != 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount != 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount == 0)) {
      this.completedStatus.push(completedCount);
      this.pendingReviewStatus.push(pendingReviewCount);
      this.failedStatus.push(failedCount);
    }
  }

  getPrevios3MonthData(listmgnt) {
    const previos3Month = this.getMonthToCompare(new Date().getMonth() - 3);
    let completedCount = 0;
    let pendingReviewCount = 0;
    let failedCount = 0;

    listmgnt.forEach(data => {

      // Calculating current month data
      if (previos3Month == this.findMonthFromString(data.startDate)) {
        // Inserting current month Catgory value
        if (!(this.categories.indexOf(this.getMonthInstring(this.findMonthFromString(data.startDate))) > -1)) {
          this.categories.push(this.getMonthInstring(this.findMonthFromString(data.startDate)));
        }

        // Calcluating status values
        if (data.status.toUpperCase() === 'COMPLETED') {
          completedCount++;
        } else if (data.status.toUpperCase() === 'FOFTEST STOPPED') {
          pendingReviewCount++;
        } else if (data.status.toUpperCase() === 'FAILED') {
          failedCount++;
        }
      }
    });
    if ((completedCount != 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount != 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount == 0 && failedCount != 0) ||
      (completedCount != 0 && pendingReviewCount == 0 && failedCount == 0) ||
      (completedCount == 0 && pendingReviewCount != 0 && failedCount == 0)) {
      this.completedStatus.push(completedCount);
      this.pendingReviewStatus.push(pendingReviewCount);
      this.failedStatus.push(failedCount);
    }

  }

  findMonthFromString(dateString) {
    const formattedDate = dateString.split(" ")[0];
    return new Date(new Date(formattedDate)).getMonth();
  }

  getMonthToCompare(month) {
    let finalMonth;
    if (month < 0) {
      finalMonth = month + 12;
    } else {
      finalMonth = month;
    }
    return finalMonth;
  }

  // 0 = January, 1= February, 2 = March, 3 = April, 4 = May, 5 = June, 6 = July, 7 = August, 8 = September, 9 = October, 10 = November, 11 = December
  getMonthInstring(number) {
    let monthInString;
    if (number == 0) {
      monthInString = 'January';
    } else if (number == 1) {
      monthInString = 'February';
    } else if (number == 2) {
      monthInString = 'March';
    } else if (number == 3) {
      monthInString = 'April';
    } else if (number == 4) {
      monthInString = 'May';
    } else if (number == 5) {
      monthInString = 'June';
    } else if (number == 6) {
      monthInString = 'July';
    } else if (number == 7) {
      monthInString = 'August';
    } else if (number == 8) {
      monthInString = 'September';
    } else if (number == 9) {
      monthInString = 'October';
    } else if (number == 10) {
      monthInString = 'November';
    } else if (number == 11) {
      monthInString = 'December';
    }
    return monthInString;
  }

  clearListMgntData() {
    this.categories = [];
    this.completedStatus = [];
    this.failedStatus = [];
    this.pendingReviewStatus = [];
  }

}