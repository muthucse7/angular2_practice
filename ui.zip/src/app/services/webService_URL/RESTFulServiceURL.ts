export const RESTFulServiceURL = {
  production: false,

  // WebFocus Aging next day summary
  IT_AGING_SUMMARY_WEB_FOCUS: 'https://webfocus-sanctionscreening-it.us.bank-dns.com/ibi_apps/WFServlet?&IBIF_ex=dailyaging.fex',
  UAT_AGING_SUMMARY_WEB_FOCUS: 'https://webfocus-sanctionscreening-uat.us.bank-dns.com/ibi_apps/WFServlet?&IBIF_ex=dailyaging.fex',
  PROD_AGING_SUMMARY_WEB_FOCUS: 'https://webfocus-sanctionscreening.us.bank-dns.com/ibi_apps/WFServlet?&IBIF_ex=dailyaging.fex',

  // User Context
  USER_CONTEXT: '/rtss/srvs/authorization/context/getUserContext',

  // Dashboard
  DASHBOARD_OVERALL_SUMMARY: '/rtss/srvs/ofacdashboard/dashboardcall/getDashboardSummary',
  DASHBOARD_LIST_MGT: '/rtss/srvs/ofacdashboard/dashboardcall/getListManagementData',
  DASHBOARD_RULE_LIST_MGT: '/rtss/srvs/ofacdashboard/dashboardcall/getRuleListManagementData',
  DASHBOARD_SERVER_LOG_COMP_DATA: '/rtss/srvs/ofacdashboard/dashboardcall/getServerLogCompData',
  DASHBOARD_SERVER_COMP_DATA: '/rtss/srvs/ofacdashboard/dashboardcall/getComponentStatus',

  // Common services
  GET_USER_BU_DETAILS: '/rtss/srvs/authorization/context/getBuByUserId',
  RESET_SESSION_TIMEOUT: '/rtss/srvs/authorization/context/resetSession',
  GET_ALL_BU_DETAILS: '/rtss/srvs/authorization/bu/readAll',
  BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT: '/rtss/srvs/authorization/bu/getBusinessUnits',

  // Application Configuration
  CRUD_CONFIG_SEARCH_ALL: '/rtss/srvs/ofacdashboard/adminconfigcall/searchall',
  CRUD_CONFIG_SEARCH: '/rtss/srvs/ofacdashboard/adminconfigcall/search',
  CRUD_CONFIG_CATEGORY_SUBCATEGORY: '/rtss/srvs/ofacdashboard/adminconfigcall/getmasterdatacatsubcat',
  CRUD_CONFIG_CREATE: '/rtss//srvs/ofacdashboard/adminconfigcall/create',
  CRUD_CONFIG_UPDATE: '/rtss/srvs/ofacdashboard/adminconfigcall/update',
  CRUD_CONFIG_DELETE: '/rtss/srvs/ofacdashboard/adminconfigcall/delete',

  // Application Components
  APP_COMP_SEARCH: '/rtss/srvs/ofacdashboard/adminconfig/getServerComponentConfigDetails',
  APP_COMP_CREATE: '/rtss//srvs/ofacdashboard/adminconfig/createServerComponent',
  APP_COMP_UPDATE: '/rtss/srvs/ofacdashboard/adminconfig/updateServerComponent',
  APP_COMP_MODULE_NAME: '/rtss/srvs/ofacdashboard/adminconfig/getApplicationModules',
  APP_COMP_SERVER_NAME: '/rtss/srvs/ofacdashboard/adminconfig/getApplicationServers',
  APP_COMP_COMPONENT_NAME: '/rtss/srvs/ofacdashboard/adminconfig/getApplicationComponents',

  // Manage BU details
  MANAGE_BU_DETAILS_READ_ALL: '/rtss/srvs/authorization/bu/readAll',
  MANAGE_BU_DETAILS_CREATE_BU: '/rtss/srvs/authorization/bu/createBU',
  MANAGE_BU_DETAILS_UPDATE_BU: '/rtss/srvs/authorization/bu/updateBU',

  // Manage BU Role
  MANAGE_BU_ROLE_GETBUROLE_DETAILS: '/rtss/srvs/authorization/bu/getBURoleDetails',
  MANAGE_BU_ROLE_CREATE_BU_ROLE: '/rtss/srvs/authorization/bu/createBURole',
  MANAGE_BU_ROLE_DELETE_BU_ROLE: '/rtss/srvs/authorization/bu/deleteBURole',

  // Manage BU Function
  MANAGE_BU_FUNCTION_GRID_DETAILS: '/rtss/srvs/authorization/bu/getBURoleFunctionGridDetails',
  MANAGE_BU_FUNCTION_CREATE_BUROLE_FUNCTION: '/rtss/srvs/authorization/bu/createBURoleFunction',
  MANAGE_BU_FUNCTION_DELETE_BUROLE_FUNCTION: '/rtss/srvs/authorization/bu/deleteBURoleFunction',

  // Manage BU USER
  MANAGE_BU_USER_SEARCH: '/rtss/srvs/dashboarduser/user/search',
  MANAGE_BU_USER_CREATE: '/rtss/srvs/dashboarduser/user/create',
  MANAGE_BU_USER_UPDATE: '/rtss/srvs/dashboarduser/user/update',
  MANAGE_BU_USER_DELETE: '/rtss/srvs/dashboarduser/user/delete',

  // Manage BU USER Role
  MANAGE_BU_USER_ROLE_DATA: '/rtss/srvs/authorization/bu/getManageUserRoleData',
  MANAGE_BU_USER_ROLE_ASSIGN_ROLE: '/rtss/srvs/authorization/bu/assignUserRole',
  MANAGE_BU_USER_ROLE_DELETE_ROLE: '/rtss/srvs/authorization/bu/deleteUserRole',

  // Transaction Rescanning
  TXN_SUBMIT_RESCAN: '/rtss/srvs/transactionRescan/submitRescan',
  TXN_SEARCH_RESCAN: '/rtss/srvs/transactionRescan/searchRescan',
  TXN_RESCAN_COMPLETED_STATUS : '/rtss/srvs/transactionRescan/getBatchMsgDetails',

  // Log Search
  LOG_SEARCH_RESCAN: '/rtss/srvs/log/rescanSearch',

  // User Activity Event
  USER_ACTIVITY_EVENT_SEARCH: '/rtss/srvs/log/userActivityEventSearch',

  // Report: Performance
  REPORT_PERFORMANCE: '/rtss/srvs/reporting/reports/getIntraDayQualityReport',
  GET_REPORT_OPERATORS: '/rtss/srvs/reporting/reports/getOperators',
  GET_REPORT_REMIDIATION_STATUS: '/rtss/srvs/reporting/reports/getRemidiationStatus',
  GET_ONDEMAND_REPORTS: '/rtss/srvs/reporting/reports/getOnDemandReport',
  GET_SLA_REPORT: '/rtss/srvs/reporting/reports/getSlaReport',
  GET_PRODUCTION_REPORT:'/rtss/srvs/reporting/reports/getProductionReport',

  // Fof Test Data Configuration
  FOF_TEST_DATA_CONFIG_SEARCH: '/rtss/srvs/ofacdashboard/adminconfig/searchFofTestData',
  FOF_TEST_DATA_CONFIG_DELETE: '/rtss/srvs/ofacdashboard/adminconfig/deleteFofTestData',
  FOF_TEST_DATA_CONFIG_CREATE: '/rtss/srvs/ofacdashboard/adminconfig/createFofTestData',
  FOF_TEST_DATA_CONFIG_UPDATE: '/rtss/srvs/ofacdashboard/adminconfig/updateFofTestData',
  FOF_TEST_DATA_CONFIG_STATUS_CHANGE: '/rtss/srvs/ofacdashboard/adminconfig/updateListManagementJobStatus',

  // Auto SusesPend and Pass Configuration
  AUTO_SUSPEND_PASS_BATCH_CONFIG: '/rtss/srvs/ofacdashboard/adminconfig/getAutoSuspendPassBatchStatus',
  AUTO_SUSPEND_PASS_CONFIG_SEARCH: '/rtss/srvs/ofacdashboard/adminconfig/getAutoSuspendPassConfig',
  UPDATE_SUSPEND_PASS_CONFIG: '/rtss/srvs/ofacdashboard/adminconfig/updateAutoSuspendPassConfig',

  // Recsreen Recon report
  GET_RESCREEN_RECON_MSG_DETAIL:'/rtss/srvs/transactionRescan/getRescreenReconDetails',

  // POC Customer Research Webservice 
  GET_CUSTOMER_DEATILS:'/rtss/srvs/customer/search',
  GET_CUSTOMER_RESEARCH:'/rtss/srvs/customer/research',
  RESEARCH_CUSTOMER_ALERTS: '/rtss/srvs/customer/researchAlertCustomers', 
  SEND_ALERT_DECISIONS:'/rtss/srvs/customer/sendAlertDecisions'
};
