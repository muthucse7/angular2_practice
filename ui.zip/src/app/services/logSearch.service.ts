import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {ManageBURoleGridResponseModel} from '../models/manageBusinessUnits/manageRole/manageBURoleGridResponseModel';
import {SelectFormatResponseModel} from '../models/crudConfig/selectFormatDropdownResponseModel';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class LogSearchService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {
    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    /*return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));*/
  }

  public getLogSearchGridComponent(inputRequestObj) {
    return this.http.post<ManageBURoleGridResponseModel>(RESTFulServiceURL.LOG_SEARCH_RESCAN, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/logSearch/logSearchMockGridData.json').pipe(map(res => <ManageBURoleGridResponseModel>res));

  }

  /**
   * Invoking the services call for the Select SearchType dropdown
   * @param selectSearchTypeRequestObj
   * @returns {Observable<SelectFormatResponseModel>}
   */
  public getSelectSearchTypeDropDownValues(selectSearchTypeRequestObj) {
    // REST services end point URL
    return this.http.post<SelectFormatResponseModel>(RESTFulServiceURL.CRUD_CONFIG_SEARCH, selectSearchTypeRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    // return this.http.get('assets/mockdata/crudConfig/selectFormatDropDownMockJSON.json').map(res => (<SelectFormatResponseModel>res));
  }


}
