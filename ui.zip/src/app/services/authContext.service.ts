import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {catchError} from 'rxjs/operators';
import {AuthContextResponseModel} from '../models/context/authContextResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class AuthContextService extends BehaviorSubject<any[]> {

  constructor(private http: HttpClient) {
    super([]);
  }
  getContextService() {

   /* const role = 'BUSINESSUSER';
    let URL = '';
    if (role.toUpperCase() === 'COEANALYST') {
      URL = 'assets/mockdata/context/coe_analyst.json';
    } else if (role.toUpperCase() === 'PRODSUPPORT') {
      URL = 'assets/mockdata/context/prod_support.json';
    } else if(role.toUpperCase() === 'BUSINESSUSER'){
      URL = 'assets/mockdata/context/bu_user.json';
    }

    return this.http.get(URL).map(res => (<AuthContextResponseModel>res)); */ 

   return this.http.post<AuthContextResponseModel>(RESTFulServiceURL.USER_CONTEXT, '', httpOptions).pipe(
    catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

  resetSessionTimeout(){
    return this.http.post(RESTFulServiceURL.RESET_SESSION_TIMEOUT, '', httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }
}
