import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {SelectFormatResponseModel} from '../models/crudConfig/selectFormatDropdownResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import { ManageBUFunctionGridResponseModel } from '../models/manageBusinessUnits/manageFunction/manageBUFunctionGridResponseModel';
import { UserActivityGridResponseModel } from '../models/userActivityEvent/userActivityGridResponseModel';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class UserActivityEventService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }


  /**
   * Invoking the services call for the Select BU dropdown
   * @param requestObj
   * @returns {Observable<ManageBUFunctionGridResponseModel>}
   */
  public getDashboardFunctionDropdown(requestObj) {

    return this.http.post<ManageBUFunctionGridResponseModel>(RESTFulServiceURL.MANAGE_BU_FUNCTION_GRID_DETAILS, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 

     //return this.http.get('assets/mockdata/manageFunction/selectFunctionGridMockJSON.json').pipe(map(res => <ManageBUFunctionGridResponseModel>res));
  }

  public getUserActivityGridComponent(inputRequestObj) {
    return this.http.post<UserActivityGridResponseModel>(RESTFulServiceURL.USER_ACTIVITY_EVENT_SEARCH, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 

    // return this.http.get('assets/mockdata/userActivityEvent/userActivityEventMockGridData.json').pipe(map(res => <UserActivityGridResponseModel>res));

  }

}
