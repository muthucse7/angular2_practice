import {Injectable, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {OfacDashboardModel} from '../models/home/ofacDashboardModel';
import 'rxjs/add/operator/map';
import {DashboardOverallSummary} from '../models/home/dashboardOverallSummary';
import {DashboardListMgt} from '../models/home/dashboardListMgt';
import {HttpHeaders} from '@angular/common/http';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {catchError} from 'rxjs/operators';
import {BatchStatusModel} from '../models/home/prodWidget/batchStatusModel';
import {AppServerMonitoringModel} from '../models/home/prodWidget/appServerMonitoringModel';
import {AppServerDetailsPopupModel} from '../models/home/prodWidget/appServerDetailsPopupModel';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'

  })
};

@Injectable()
export class HomeService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  /**
   * Get Dashboard List Management grid data
   * @param requestObj
   */
  public fetchDashboardListMgt(requestObj) {
    return this.http.post<DashboardListMgt>(RESTFulServiceURL.DASHBOARD_LIST_MGT, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    // return this.http.get('assets/mockdata/home/dashboard_list_mgt.json').map(res => (<DashboardListMgt>res));
  }

  /**
   * Get Dashboard Rule Management grid data
   * @param requestObj
   */
  public fetchDashboardRuleListMgt(requestObj) {
    return this.http.post<DashboardListMgt>(RESTFulServiceURL.DASHBOARD_RULE_LIST_MGT, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    // return this.http.get('assets/mockdata/home/dashboard_list_mgt.json').map(res => (<DashboardListMgt>res));
  }

  /**
   * Get Dashboard overall Summary grid data
   * @param requestObj
   */
  public getOverallSummary(requestObj) {
    return this.http.post<DashboardOverallSummary>(RESTFulServiceURL.DASHBOARD_OVERALL_SUMMARY, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    // return this.http.get('assets/mockdata/home/dashboard_overall_summary.json').map(res => (<DashboardOverallSummary>res));
  }

  /**
   * Get Dashboard Batch status grid data
   * @param requestObj
   */
  public getBatchSystemStatus(requestObj) {
     return this.http.get('assets/mockdata/home/batch_status.json').map(res => (<BatchStatusModel>res));
  }
  
  public getBackendServerStatusGridData(requestObj) {
      return this.http.post<AppServerMonitoringModel>(RESTFulServiceURL.DASHBOARD_SERVER_COMP_DATA, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 
    
      //return this.http.get('assets/mockdata/home/backend_component.json').map(res => (<AppServerMonitoringModel>res));
  }

  public getBackendCompDetailsPoupData(requestObj) {
    return this.http.post<AppServerDetailsPopupModel>(RESTFulServiceURL.DASHBOARD_SERVER_LOG_COMP_DATA, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

     // return this.http.get('assets/mockdata/home/backend_component_popup.json').map(res => (<AppServerDetailsPopupModel>res));
}
}
