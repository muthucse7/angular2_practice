import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import { CustomerSearchResponseModel } from '../models/customerSearch/customerSearchResponseModel';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class CustomerSearchService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }


  /**
   * Invoking the services call for the customer search
   * @param requestObj
   * @returns {Observable<CustomerSearchResponseModel>}
   */
  public getCustomerProfile(requestObj) {

    return this.http.post<CustomerSearchResponseModel>(RESTFulServiceURL.GET_CUSTOMER_DEATILS, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 

    // return this.http.get('assets/mockdata/customerSearch/customerSearchMockData.json').pipe(map(res => <CustomerSearchResponseModel>res));
  }

  public getCustomerResearchService(requestObj) {

    return this.http.post<CustomerSearchResponseModel>(RESTFulServiceURL.GET_CUSTOMER_RESEARCH, requestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 

    // return this.http.get('assets/mockdata/customerSearch/customerReSearchMockData.json').pipe(map(res => <CustomerSearchResponseModel>res));
  }

  public initiateAlertsResearch(){

    return this.http.get(RESTFulServiceURL.RESEARCH_CUSTOMER_ALERTS, httpOptions).map(res => (<CustomerSearchResponseModel>res)); 

    //return this.http.get('assets/mockdata/customerSearch/initiateAlertsResearchMockData.json').map(res => (<CustomerSearchResponseModel>res));
  }

  public sendAlertDecisions(){
    return this.http.get(RESTFulServiceURL.SEND_ALERT_DECISIONS, httpOptions).map(res => (<CustomerSearchResponseModel>res)); 

    //return this.http.get('assets/mockdata/customerSearch/initiateAlertsResearchMockData.json').map(res => (<CustomerSearchResponseModel>res));
  }

}
