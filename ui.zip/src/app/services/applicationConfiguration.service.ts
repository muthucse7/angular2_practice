import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders, HttpRequest} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {CrudCategoryAndSubCategoryResponseModel} from '../models/crudConfig/crudCategoryAndSubCategoryResponseModel';
import {CrudConfigGridResponseModel} from '../models/crudConfig/crudConfigGridResponseModel';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';
const REMOVE_ACTION = 'DELETE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class ApplicationConfigurationService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  /**
   * Get the CRUD Grid values and return to the CrudConfigGridResponseModel
   * @returns {Observable<CrudConfigGridResponseModel>}
   */
  public getCrudGridComponentValues(inputRequestObj, searchType): Observable<CrudConfigGridResponseModel> {
    let srvsURL = '';
    if (searchType.toUpperCase() === 'SEARCH_ALL') {
      srvsURL = RESTFulServiceURL.CRUD_CONFIG_SEARCH_ALL;
    } else {
      srvsURL = RESTFulServiceURL.CRUD_CONFIG_SEARCH;
    }

    return this.http.post<CrudConfigGridResponseModel>(srvsURL, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/applicationConfig/crudConfigGridMockJSON.json').pipe(map(res => <CrudConfigGridResponseModel>res));

  }

  private serializeModels(data?: any): string {
    return data ? `&models=${JSON.stringify([data])}` : '';
  }


  /**
   * Get the CRUD dropdown values and return to CrudCategoryAndSubCategoryResponseModel
   * @returns {Observable<CrudCategoryAndSubCategoryResponseModel>}
   */
  public getCRUDSearchDropDownValues(searchComponentRequestObj) {

    // REST services end point URL
    return this.http.post<CrudCategoryAndSubCategoryResponseModel>(RESTFulServiceURL.CRUD_CONFIG_CATEGORY_SUBCATEGORY, searchComponentRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // Enable Mock JOSN data
    // return this.http.get('assets/mockdata/applicationConfig/CRUDSearchDropDownMockJSON.json').map(res => (<CrudCategoryAndSubCategoryResponseModel>res));

  }

  /**
   * @param insertORUpdateORDeleteRequestObj
   * @param requestType
   * @returns {Observable<any>}
   */
  public insertAndUpdateAndUpdateCRUDConfigData(insertORUpdateORDeleteRequestObj, requestType) {
    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.CRUD_CONFIG_CREATE;
    } else if (requestType.toUpperCase() === UPDATE_ACTION) {
      endpointURL = RESTFulServiceURL.CRUD_CONFIG_UPDATE;
    } else if (requestType.toUpperCase() === REMOVE_ACTION) {
      endpointURL = RESTFulServiceURL.CRUD_CONFIG_DELETE;
    }
    return this.http.post<CrudConfigGridResponseModel>(endpointURL, insertORUpdateORDeleteRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

}
