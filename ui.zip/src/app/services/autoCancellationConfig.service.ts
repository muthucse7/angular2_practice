import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import { AutoCancellationConfigGridResponseModel } from '../models/autoCancellationConfig/autoCancellationConfigGridResponseModel';
import { AutoCancellationBatchConfigResponseModel } from '../models/autoCancellationConfig/autoCancellationBatchConfigResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import { AutoSuspendPassBatchConfigResponseModel } from '../models/autoSuspendConfig/autoSuspendBatchConfigResponseModel';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class AutoCancellationConfigService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }


  public getAutoCancellationConfigServiceGridComponent(inputRequestObj) {
    
    return this.http.post<AutoCancellationConfigGridResponseModel>(RESTFulServiceURL.AUTO_SUSPEND_PASS_CONFIG_SEARCH, inputRequestObj, httpOptions).pipe(
    catchError(catchError((error: any) => Observable.throw(error.json())))); 
 
    // return this.http.get('assets/mockdata/autoCancellationConfig/autoCancellationConfigMockGridData.json').pipe(map(res => <AutoCancellationConfigGridResponseModel>res));
  }

  public getAutoCancellationBatchConfig(inputRequestObj) {
    return this.http.post<AutoSuspendPassBatchConfigResponseModel>(RESTFulServiceURL.AUTO_SUSPEND_PASS_BATCH_CONFIG, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 
 
   //  return this.http.get('assets/mockdata/autoCancellationConfig/autoCancellationBatchConfigMockGridData.json').pipe(map(res => <AutoSuspendPassBatchConfigResponseModel>res));
  }

  public updateAutoPassConfig(inputRequestObj) {
    return this.http.post<AutoCancellationConfigGridResponseModel>(RESTFulServiceURL.UPDATE_SUSPEND_PASS_CONFIG, inputRequestObj, httpOptions).pipe(
    catchError(catchError((error: any) => Observable.throw(error.json())))); 
  
  // return this.http.get('assets/mockdata/autoCancellationConfig/updateAutoPassConfigMockGridData.json').pipe(map(res => <AutoCancellationConfigGridResponseModel>res));
  }

}
