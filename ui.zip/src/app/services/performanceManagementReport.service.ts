import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {catchError, map} from 'rxjs/operators';
import {IntradayReportGridResponseModel} from '../models/report/intraday/intradayReportGridResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class PerformanceManagementReportService extends BehaviorSubject<any[]> {

  constructor(private http: HttpClient) {
    super([]);
  }

  /**
   * Get the SLA Report Grid values and return to the IntradayReportGridResponseModel
   * @returns {Observable<IntradayReportGridResponseModel>}
   */

  public getIntradayReportComponentGridValues(inputGenerateReportObj) {
    return this.http.post<IntradayReportGridResponseModel>(RESTFulServiceURL.REPORT_PERFORMANCE, inputGenerateReportObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    //return this.http.get('assets/mockdata/report/intraday/intradayReportGridMockJSON.json').pipe(map(res => <IntradayReportGridResponseModel>res));

    // return this.http.get('assets/mockdata/report/intraday/intradayReportGridMockJSON_6000records.json').pipe(map(res => <IntradayReportGridResponseModel>res));


  }

  // Export All services
  public exportAll(inputGenerateReportObj) {
    return this.http.post<IntradayReportGridResponseModel>(RESTFulServiceURL.REPORT_PERFORMANCE, inputGenerateReportObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    //return this.http.get('assets/mockdata/report/intraday/intradayReportGridMockJSON.json').pipe(map(res => <IntradayReportGridResponseModel>res));

    // return this.http.get('assets/mockdata/report/intraday/intradayReportGridMockJSON_6000records.json').pipe(map(res => <IntradayReportGridResponseModel>res));

  }

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {

    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));

  }

}
