import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectFormatResponseModel} from '../models/crudConfig/selectFormatDropdownResponseModel';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {FofConfigGridResponseModel} from '../models/fofConfig/fofConfigResponseModel';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'

  })
};

@Injectable()
export class FofTestConfigurationService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {
    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    /*return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));*/
  }

  /**
   * Invoking the services call for the Select Format dropdown
   * @param selectFormatRequestObj
   * @returns {Observable<SelectFormatResponseModel>}
   */
  public getSelectFormatDropDownValues(selectFormatRequestObj) {
    // REST services end point URL
    return this.http.post<SelectFormatResponseModel>(RESTFulServiceURL.CRUD_CONFIG_SEARCH, selectFormatRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    /*return this.http.get('assets/mockdata/crudConfig/selectFormatDropDownMockJSON.json').map(res => (<SelectFormatResponseModel>res));*/
  }


  /**
   * GET FOF GRID VALUSE BASED ON SEARCH CRITERIA  FofConfigGridResponseModel
   * @returns {Observable<FofConfigGridResponseModel>}
   */

  public getFofTestDataConfigGridComponent(inputSearchReqObj): Observable<FofConfigGridResponseModel> {
     return this.http.post<FofConfigGridResponseModel>(RESTFulServiceURL.FOF_TEST_DATA_CONFIG_SEARCH, inputSearchReqObj, httpOptions).pipe(
       catchError(catchError((error: any) => Observable.throw(error.json()))));

    /*return this.http.get('assets/mockdata/fofConfig/fofConfigSearchMOCKJSON.json').pipe(map(res => <FofConfigGridResponseModel>res));*/

  }

  public removeFoftTestDataConfig(inputReqObj): Observable<FofConfigGridResponseModel> {
    return this.http.post<FofConfigGridResponseModel>(RESTFulServiceURL.FOF_TEST_DATA_CONFIG_DELETE, inputReqObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

  public insertAndUpdateAndUpdateConfigData(insertORUpdateRequestObj, requestType) {
    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.FOF_TEST_DATA_CONFIG_CREATE;
    } else if (requestType.toUpperCase() === UPDATE_ACTION) {
      endpointURL = RESTFulServiceURL.FOF_TEST_DATA_CONFIG_UPDATE;
    }

    return this.http.post<FofConfigGridResponseModel>(endpointURL, insertORUpdateRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

  public fofTestCurrentAndUpdateService(inputSearchReqObj): Observable<FofConfigGridResponseModel> {
      return this.http.post<FofConfigGridResponseModel>(RESTFulServiceURL.FOF_TEST_DATA_CONFIG_STATUS_CHANGE, inputSearchReqObj, httpOptions).pipe(
        catchError(catchError((error: any) => Observable.throw(error.json()))));

    /* return this.http.get('assets/mockdata/fofConfig/fofTestEnableMOCKJSON.json').pipe(map(res => <FofConfigGridResponseModel>res));*/
  }

  public getFofTestCurrentStatus(inputSearchReqObj): Observable<FofConfigGridResponseModel> {
    return this.http.post<FofConfigGridResponseModel>(RESTFulServiceURL.FOF_TEST_DATA_CONFIG_STATUS_CHANGE, inputSearchReqObj, httpOptions).pipe(
       catchError(catchError((error: any) => Observable.throw(error.json()))));

    /* return this.http.get('assets/mockdata/fofConfig/fofTestCurrentMOCKJSON.json').pipe(map(res => <FofConfigGridResponseModel>res)); */
  }



}
