import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {catchError, map} from 'rxjs/operators';
import {OnDemandReportGridResponseModel} from '../models/report/demand/onDemandReportGridResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {OperatorResponseModel} from '../models/report/demand/operatorResponseModel';
import {StateResponseModel} from '../models/report/demand/stateResponseModel';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class OnDemandReportingService extends BehaviorSubject<any[]> {

  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Get the OnDemand Report Grid values and return to the OnDemandReportGridResponseModel
   * @returns {Observable<SlaReportGridResponseModel>}
   */

  public getOnDemandReportingComponentGridValues(inputGenerateReportObj) {
     return this.http.post<OnDemandReportGridResponseModel>(RESTFulServiceURL.GET_ONDEMAND_REPORTS, inputGenerateReportObj, httpOptions).pipe(
       catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/report/demand/onDemandReportingGridMockJSON.json').pipe(map(res => <OnDemandReportGridResponseModel>res));
  }

  /**
   *  Export All services
   */

  public exportAll(inputGenerateReportObj) {
     return this.http.post<OnDemandReportGridResponseModel>(RESTFulServiceURL.GET_ONDEMAND_REPORTS, inputGenerateReportObj, httpOptions).pipe(
       catchError(catchError((error: any) => Observable.throw(error.json()))));

    //return this.http.get('assets/mockdata/report/demand/onDemandReportingGridMockJSON.json').pipe(map(res => <OnDemandReportGridResponseModel>res));

  }


  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {

    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));

  }

  /**
   * Invoking operator services call
   * @param operatorRequestObj
   */
  public getOperatorDropDownValues(operatorRequestObj) {

    // REST services end point URL
    return this.http.post<OperatorResponseModel>(RESTFulServiceURL.GET_REPORT_OPERATORS, operatorRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

     //return this.http.get('assets/mockdata/report/demand/operatorMockJSON.json').map(res => (<OperatorResponseModel>res));

  }

  public getStateDropDownValues(stateRequestObj) {

    // REST services end point URL
    return this.http.post<StateResponseModel>(RESTFulServiceURL.GET_REPORT_REMIDIATION_STATUS, stateRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

     //return this.http.get('assets/mockdata/report/demand/remidiationStatusMockJSON.json').map(res => (<StateResponseModel>res));

  }


}
