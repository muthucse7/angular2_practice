import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import { ReportTypeResponseModel } from '../models/rescreenReconciliation/reportTypeResponseModel';
import { ReportRescreenReconResponseModel } from '../models/rescreenReconciliation/reportRescreenReconResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class RescreenReconciliationService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }


  /**
   * Invoking the services call for the Select report Dropdown
   * @param requestObj
   * @returns {Observable<ReportTypeResponseModel>}
   */
  public getReportTypeDropdown() { 
     return this.http.get('assets/mockdata/rescreenReconciliation/rescreenReconReportTypeMock.json').pipe(map(res => <ReportTypeResponseModel>res));
   }

    /**
   * Invoking the services call for the rescreen recon report
   * @param requestObj
   * @returns {Observable<ReportRescreenReconResponseModel>}
   */
   public getRescreenReconReport(inputRequestObj) { 
    return this.http.post<ReportRescreenReconResponseModel>(RESTFulServiceURL.GET_RESCREEN_RECON_MSG_DETAIL, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    //return this.http.get('assets/mockdata/rescreenReconciliation/rescreenReconGridMock.json').pipe(map(res => <ReportRescreenReconResponseModel>res));
  }


}
