import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import { AutoSuspendConfigGridResponseModel } from '../models/autoSuspendConfig/autoSuspendConfigGridResponseModel';
import { AutoSuspendPassBatchConfigResponseModel } from '../models/autoSuspendConfig/autoSuspendBatchConfigResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';


const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class AutoSuspendConfigService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }


  public getAutoSuspendConfigServiceGridComponent(inputRequestObj) {
    return this.http.post<AutoSuspendConfigGridResponseModel>(RESTFulServiceURL.AUTO_SUSPEND_PASS_CONFIG_SEARCH, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 
 
    // return this.http.get('assets/mockdata/autoSuspendConfig/autoSuspendConfigMockGridData.json').pipe(map(res => <AutoSuspendConfigGridResponseModel>res));
  }

  public getAutoSuspendBatchConfig(inputRequestObj) {
    return this.http.post<AutoSuspendPassBatchConfigResponseModel>(RESTFulServiceURL.AUTO_SUSPEND_PASS_BATCH_CONFIG, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 
 
   //  return this.http.get('assets/mockdata/autoSuspendConfig/autoSuspendBatchConfigMockGridData.json').pipe(map(res => <AutoSuspendPassBatchConfigResponseModel>res));
  }

  public updateAutoSuspendConfig(inputRequestObj) {
    return this.http.post<AutoSuspendConfigGridResponseModel>(RESTFulServiceURL.UPDATE_SUSPEND_PASS_CONFIG, inputRequestObj, httpOptions).pipe(
     catchError(catchError((error: any) => Observable.throw(error.json())))); 
 
    // return this.http.get('assets/mockdata/autoSuspendConfig/updateAutoSuspendConfigMockGridData.json').pipe(map(res => <AutoSuspendConfigGridResponseModel>res));
  }

}
