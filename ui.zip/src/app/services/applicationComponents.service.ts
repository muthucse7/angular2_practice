import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders, HttpRequest} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {ApplicationComponentsGridResponseModel} from '../models/applicationComponents/applicationComponentsGridResponseModel';
import {ApplicationComponentDropdownResponseModel} from '../models/applicationComponents/applicationComponentDropdownResponseModel';
import {ApplicationComponentsAddAndUpdateRequestModel} from '../models/applicationComponents/applicationComponentsAddAndUpdateRequestModel';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class ApplicationComponentsService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  /**
   * Get the CRUD Grid values and return to the CrudConfigGridResponseModel
   * @returns {Observable<CrudConfigGridResponseModel>}
   */
  public getAppComponentsGridValues(inputRequestObj): Observable<ApplicationComponentsGridResponseModel> {
    

    return this.http.post<ApplicationComponentsGridResponseModel>(RESTFulServiceURL.APP_COMP_SEARCH, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json())))); 

    //return this.http.get('assets/mockdata/applicationComponents/applicationComponentsGridMock.json').pipe(map(res => <ApplicationComponentsGridResponseModel>res));

  }

  private serializeModels(data?: any): string {
    return data ? `&models=${JSON.stringify([data])}` : '';
  }
  

  /**
   * Invoking the services call for the Select Module Name dropdown
   * @param selectModuleNameRequestObj
   * @returns {Observable<SelectModuleNameRequestObj>}
   */
  public getSelectModuleNameDropDownValues(selectModuleNameRequestObj) {
    // REST services end point URL
    return this.http.post<ApplicationComponentDropdownResponseModel>(RESTFulServiceURL.APP_COMP_MODULE_NAME, selectModuleNameRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
       //return this.http.get('assets/mockdata/applicationComponents/applicationModuleNameDropDownMock.json').map(res => (<ApplicationComponentDropdownResponseModel>res));
  }

  /**
   * Invoking the services call for the Select Server Name dropdown
   * @param selectServerNameRequestObj
   * @returns {Observable<SelectServerNameRequestObj>}
   */
  public getSelectServerNameDropDownValues(selectServerNameRequestObj) {
    // REST services end point URL
    return this.http.post<ApplicationComponentDropdownResponseModel>(RESTFulServiceURL.APP_COMP_SERVER_NAME, selectServerNameRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
      //return this.http.get('assets/mockdata/applicationComponents/applicationServerDropDownMock.json').map(res => (<ApplicationComponentDropdownResponseModel>res));
  }

  /**
   * Invoking the services call for the Select Component Name dropdown
   * @param selectComponentNameRequestObj
   * @returns {Observable<SelectComponentNameRequestObj>}
   */
  public getSelectComponentNameDropDownValues(selectComponentNameRequestObj) {
    // REST services end point URL
    return this.http.post<ApplicationComponentDropdownResponseModel>(RESTFulServiceURL.APP_COMP_COMPONENT_NAME, selectComponentNameRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
      //return this.http.get('assets/mockdata/applicationComponents/applicationComponentsDropDownMock.json').map(res => (<ApplicationComponentDropdownResponseModel>res));
  }


  /**
   * @param insertORUpdateRequestObj
   * @param requestType
   * @returns {Observable<any>}
   */
  public insertAndUpdateAppComponentData(insertORUpdateRequestObj, requestType) {
    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.APP_COMP_CREATE;
    } else if (requestType.toUpperCase() === UPDATE_ACTION) {
      endpointURL = RESTFulServiceURL.APP_COMP_UPDATE;
    } 
    return this.http.post<ApplicationComponentsAddAndUpdateRequestModel>(endpointURL, insertORUpdateRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

}
