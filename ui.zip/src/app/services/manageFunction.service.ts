import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';

import {ManageBUCreateAndUpdateResponseModel} from '../models/manageBusinessUnits/manageBU/manageBUCreateAndUpdateResponseModel';
import {ManageBUFunctionGridResponseModel} from '../models/manageBusinessUnits/manageFunction/manageBUFunctionGridResponseModel';
import {ManageBURoleGridResponseModel} from '../models/manageBusinessUnits/manageRole/manageBURoleGridResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';


const CREATE_ACTION = 'CREATE';
const REMOVE_ACTION = 'DELETE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};


@Injectable()
export class ManageFunctionService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Get the MANAGE BU ROle Grid values and return to the ManageBUGridResponseModel
   * @returns {Observable<ManageBURoleGridResponseModel>}
   */

  public getManageBUFunctionGridComponent(inputRequestObj) {

    return this.http.post<ManageBUFunctionGridResponseModel>(RESTFulServiceURL.MANAGE_BU_FUNCTION_GRID_DETAILS, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/manageFunction/selectFunctionGridMockJSON.json').pipe(map(res => <ManageBUFunctionGridResponseModel>res));

  }

  /**
   * BU: CREATE AND DELETE Manage Role Grid Component
   * @param createAndDeleteBURoleGridData
   * @param requestType
   * @returns {Observable<any>}
   */
  public createAndDeleteBURoleGridData(createAndDeleteBURoleGridDataRequestObj, requestType) {

    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_FUNCTION_CREATE_BUROLE_FUNCTION;
    } else if (requestType.toUpperCase() === REMOVE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_FUNCTION_DELETE_BUROLE_FUNCTION;
    }
    return this.http.post<ManageBUCreateAndUpdateResponseModel>(endpointURL, createAndDeleteBURoleGridDataRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {
    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.GET_ALL_BU_DETAILS, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    /* return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));*/
  }


}
