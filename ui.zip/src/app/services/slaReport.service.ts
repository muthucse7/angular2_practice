import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {catchError, map} from 'rxjs/operators';
import {SlaReportGridResponseModel} from '../models/report/sla/slaReportGridResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {StateResponseModel} from '../models/report/demand/stateResponseModel';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }),
};

@Injectable()
export class SlaReportService extends BehaviorSubject<any[]> {

  constructor(private http: HttpClient) {
    super([]);
  }

  public SlaReportGridResponseModel: SlaReportGridResponseModel;
  private data: any[] = [];

  /**
   * Get the SLA Report Grid values and return to the SlaReportGridResponseModel
   * @returns {Observable<SlaReportGridResponseModel>}
   */

  public getSlaReportComponentGridValues(inputGenerateReportObj) {
    return this.http.post<SlaReportGridResponseModel>(RESTFulServiceURL.GET_SLA_REPORT, inputGenerateReportObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    // return this.http.get('assets/mockdata/report/sla/slaReportGridMockJSON.json').pipe(map(res => <SlaReportGridResponseModel>res));
  }

  /**
   *  Export All services
   */

  public exportAll(inputGenerateReportObj) {
    return this.http.post<SlaReportGridResponseModel>(RESTFulServiceURL.GET_SLA_REPORT, inputGenerateReportObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/report/sla/slaReportGridMockJSON.json').pipe(map(res => <SlaReportGridResponseModel>res));

  }


  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {

    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));

  }

}
