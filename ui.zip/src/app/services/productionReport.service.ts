import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {ProductionReportGridResponseModel} from '../models/report/productionReport/productionReportGridResponseModel';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class ProductionReportService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Get the Production Report Grid values and return to the ProductionReportGridResponseModel
   * @returns {Observable<ProductionReportGridResponseModel>}
   */

  public getProdReportGridComponent(inputRequestObj) {
    
     return this.http.post<ProductionReportGridResponseModel>(RESTFulServiceURL.GET_PRODUCTION_REPORT, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

     // return this.http.get('assets/mockdata/report/productionReport/productionReportMockGridData.json').pipe(map(res => <ProductionReportGridResponseModel>res));

     }

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
    public getSelectBUDropDownValues(selectBURequestObj) {
        // REST services end point URL
        return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
        catchError(catchError((error: any) => Observable.throw(error.json()))));

       // return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));
    }
  

}
