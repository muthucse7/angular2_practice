import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';

import {ManageUserCreateAndUpdateResponseModel} from '../models/manageBusinessUnits/manageUser/manageUserCreateAndUpdateResponseModel';
import {ManageUserResponseModel} from '../models/manageBusinessUnits/manageUser/manageUserResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';


const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';
const REMOVE_ACTION = 'DELETE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};


@Injectable()
export class ManageUserService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * GET MANAGE USER GRID VALUSE BASED ON SEARCH CRITERIA  ManageUserResponseModel
   * @returns {Observable<ManageUserResponseModel>}
   */

  public getManageUserGridComponent(inputSearchReqObj): Observable<ManageUserResponseModel> {
    return this.http.post<ManageUserResponseModel>(RESTFulServiceURL.MANAGE_BU_USER_SEARCH, inputSearchReqObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/manageUser/manageUserSearchMockJSON.json').pipe(map(res => <ManageUserResponseModel>res));

  }

  /**
   * MANAGE USER: CREATE AND DELETE ACTION
   * @param createAndDeleteUserRequestObj
   * @param requestType
   * @returns {Observable<any>}
   */
  public createUpdateRemoveUserGridData(createAndUpdateUserRequestObj, requestType) {

    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_USER_CREATE;
    } else if (requestType.toUpperCase() === UPDATE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_USER_UPDATE;
    } else if (requestType.toUpperCase() === REMOVE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_USER_DELETE;
    }

    return this.http.post<ManageUserCreateAndUpdateResponseModel>(endpointURL, createAndUpdateUserRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
  }

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {

    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.GET_ALL_BU_DETAILS, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    /* return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));*/

  }
}
