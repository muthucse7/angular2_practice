import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {SelectFormatResponseModel} from '../models/crudConfig/selectFormatDropdownResponseModel';
import {SelectBUDropdownContextResponseModel} from '../models/context/selectBUDropdownContextResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {RescanStatusCompletedResponseModel} from '../models/transactionRescanning/detail/rescanStatusCompletedResponseModel';
import { TxnRescanGridResponseModel } from '../models/transactionRescanning/txnRescanGridResponseModel';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'
  })
};

@Injectable()
export class TnxRescanningService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  private data: any[] = [];

  /**
   * Get the MANAGE BU ROle Grid values and return to the ManageBUGridResponseModel
   * @returns {Observable<TxnRescanGridResponseModel>}
   */

  public getTnxRescanningGridComponent(inputRequestObj) {
    let endpointUrl = '';
    if (inputRequestObj.requestType !== undefined && (inputRequestObj.requestType.toUpperCase() === 'RESCAN')) {
      endpointUrl = RESTFulServiceURL.TXN_SUBMIT_RESCAN;
    } else {
      endpointUrl = RESTFulServiceURL.TXN_SEARCH_RESCAN;
    }

    return this.http.post<TxnRescanGridResponseModel>(endpointUrl, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

      /*return this.http.get('assets/mockdata/transactionRescanning/transactionRescanningMockGridData.json').pipe(map(res => <TxnRescanGridResponseModel>res));*/

  }

  /**
   * Invoking the services call for the Select BU dropdown
   * @param selectBURequestObj
   * @returns {Observable<SelectBUDropdownContextResponseModel>}
   */
  public getSelectBUDropDownValues(selectBURequestObj) {
    // REST services end point URL
    return this.http.post<SelectBUDropdownContextResponseModel>(RESTFulServiceURL.BUSINESSUNIT_DETAILS_NO_SUPPORTUNIT, selectBURequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    /* return this.http.get('assets/mockdata/context/userContextBUMockJSON.json').map(res => (<SelectBUDropdownContextResponseModel>res));*/
  }


  /**
   * Invoking the services call for the Select Format dropdown
   * @param selectFormatRequestObj
   * @returns {Observable<SelectFormatResponseModel>}
   */
  public getSelectFormatDropDownValues(selectFormatRequestObj) {
    // REST services end point URL
    return this.http.post<SelectFormatResponseModel>(RESTFulServiceURL.CRUD_CONFIG_SEARCH, selectFormatRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));
    //return this.http.get('assets/mockdata/crudConfig/selectFormatDropDownMockJSON.json').map(res => (<SelectFormatResponseModel>res));
  }

  public getRescanCompletedDetails(reqObject){
    let endpointUrl = '';
    if (reqObject !== undefined && (reqObject != null)) {
      endpointUrl = RESTFulServiceURL.TXN_RESCAN_COMPLETED_STATUS;
    }
    return this.http.post<RescanStatusCompletedResponseModel>(endpointUrl, reqObject, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    /*return this.http.get('assets/mockdata/transactionRescanning/statusCompletedGridMockJSON.json').pipe(map(res => <RescanStatusCompletedResponseModel>res));*/
  }

  /**
   *  Export All services
   */

  public exportAll(inputRequestObj) {
     return this.http.post<RescanStatusCompletedResponseModel>(RESTFulServiceURL.TXN_RESCAN_COMPLETED_STATUS, inputRequestObj, httpOptions).pipe(
       catchError(catchError((error: any) => Observable.throw(error.json()))));
    /*return this.http.get('assets/mockdata/transactionRescanning/statusCompletedGridMockJSON.json').pipe(map(res => <RescanStatusCompletedResponseModel>res));*/
  }


}
