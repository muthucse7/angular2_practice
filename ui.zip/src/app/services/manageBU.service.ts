import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/map';
import {catchError} from 'rxjs/operators';
import {map} from 'rxjs/operators';
import {ManageBUGridResponseModel} from '../models/manageBusinessUnits/manageBU/manageBUGridResponseModel';
import {ManageBUCreateAndUpdateResponseModel} from '../models/manageBusinessUnits/manageBU/manageBUCreateAndUpdateResponseModel';
import {RESTFulServiceURL} from './webService_URL/RESTFulServiceURL';
import {SelectFormatResponseModel} from '../models/crudConfig/selectFormatDropdownResponseModel';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': 'my-auth-token',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Access-Control-Allow-Headers': 'X-Custom-Header'

  })
};

@Injectable()
export class ManageBUService extends BehaviorSubject<any[]> {
  constructor(private http: HttpClient) {
    super([]);
  }

  public ManageBUGridResponseModel: ManageBUGridResponseModel;
  private data: any[] = [];

  /**
   * Get the MANAGE BU Grid values and return to the ManageBUGridResponseModel
   * @returns {Observable<ManageBUGridResponseModel>}
   */

  public getManageBUComponentGridValues(inputRequestObj) {

    return this.http.post<ManageBUGridResponseModel>(RESTFulServiceURL.MANAGE_BU_DETAILS_READ_ALL, inputRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    //return this.http.get('assets/mockdata/manageBU/manageBUMockJSON.json').pipe(map(res => <ManageBUGridResponseModel>res));

  }

  /**
   * BU: CREATE AND UPDATE
   * @param createAndUpdateBUGridDataRequestObj
   * @param requestType
   * @returns {Observable<any>}
   */
  public createAndUpdateBUGridData(createAndUpdateBUGridDataRequestObj, requestType) {
    let endpointURL = '';
    if (requestType.toUpperCase() === CREATE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_DETAILS_CREATE_BU;

    } else if (requestType.toUpperCase() === UPDATE_ACTION) {
      endpointURL = RESTFulServiceURL.MANAGE_BU_DETAILS_UPDATE_BU;
    }
    return this.http.post<ManageBUCreateAndUpdateResponseModel>(endpointURL, createAndUpdateBUGridDataRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

  }

  /**
   * Invoking the services call for the Select SearchType dropdown
   * @param selectSearchTypeRequestObj
   * @returns {Observable<SelectFormatResponseModel>}
   */
  public getSelectUnitNameDropDownValues(selectSearchTypeRequestObj) {
    // REST services end point URL
    return this.http.post<SelectFormatResponseModel>(RESTFulServiceURL.CRUD_CONFIG_SEARCH, selectSearchTypeRequestObj, httpOptions).pipe(
      catchError(catchError((error: any) => Observable.throw(error.json()))));

    // return this.http.get('assets/mockdata/crudConfig/selectFormatDropDownMockJSON.json').map(res => (<SelectFormatResponseModel>res));
  }

  public remove(data: any) {
    this.reset();

  }

  private reset() {
    this.data = [];
  }
}
