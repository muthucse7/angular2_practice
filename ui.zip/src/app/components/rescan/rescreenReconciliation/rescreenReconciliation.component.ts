import {
  Component,
  OnInit,
  Inject,
  ChangeDetectorRef,
  ViewChild,
  OnDestroy
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import * as moment from 'moment';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { RescreenReconFromModel } from '../../../models/rescreenReconciliation/rescreenReconFromModel';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { RescreenReconciliationService } from '../../../services/rescreenReconciliation.service';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'rescreenRecon',
  templateUrl: './rescreenReconciliation.component.html'
})

export class RescreenReconciliationComponent implements OnInit, OnDestroy {

  // Form group and validation 
  active = true;
  public rescreenReconReportForm: FormGroup;
  public error: any = { isError: false, errorMessage: '' };
  public rescreenReconGridData: Observable<GridDataResult>;
  private girdData: any[] = [];

  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');
  public gridState: State = { sort: [], skip: 0, take: 10 };
  public isGridLoadingIndicator: Boolean = false;


  // Service layer and model init
  public rescreenReconFromModel = new RescreenReconFromModel();
  private rescreenReconciliationService: RescreenReconciliationService;

  // Report DropDown 
  public defaultItem: SelectFormatDropdownModel = { "value": "Select Report Type", "key": null };
  public reportTypeDropDownItem: Array<SelectFormatDropdownModel> = [];


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  constructor(@Inject(RescreenReconciliationService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.rescreenReconciliationService = editServiceFactory();
  }

  public ngOnInit(): void {
    this.initializeReportForm();
    this.loadReportDropDown();
  }

  private initializeReportForm() {
    this.rescreenReconReportForm = this.formBuilder.group({
      'reportType': [this.rescreenReconFromModel.reportType, [Validators.required]],
      'rescanRequestID': [this.rescreenReconFromModel.rescanRequestID, [Validators.required]]
    });
    this.rescreenReconReportForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  // Form validation  
  onValueChanged(data?: any) {
    if (!this.rescreenReconReportForm) {
      return;
    }
    const form = this.rescreenReconReportForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = { 'reportType': '', 'rescanRequestID': '' };
  validationMessages = {
    'reportType': {
      'required': 'Please Select Report Type'
    },
    'rescanRequestID': {
      'required': 'Please Enter Rescan Request ID'
    }
  };

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  public onStateChange(state: State) {
    this.gridState = state;
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.rescreenReconGridData = this.rescreenReconciliationService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    if (this.rescreenReconReportForm.valid) {

      let rescanRequestId = this.rescreenReconReportForm.controls.rescanRequestID.value;
      let selectedReportType = this.rescreenReconReportForm.controls.reportType.value.key;
      let previousFCTYState = null;
      let rescreenFCTYState = null;

      if (selectedReportType === null) {
        this.rescreenReconReportForm.markAsDirty({});
        this.formErrors['reportType'] = 'Please Select Report Type';
        return;
      } else {
        this.formErrors['reportType'] = '';
      }

      if (selectedReportType === 'HITS_AND_HITS') {
        previousFCTYState = "HITS";
        rescreenFCTYState = "HITS";
      } else if (selectedReportType === 'HITS_AND_NO_HIT') {
        previousFCTYState = "HITS";
        rescreenFCTYState = "NO HIT";
      } else if (selectedReportType === 'NO_HIT_AND_NO_HIT') {
        previousFCTYState = "NO HIT";
        rescreenFCTYState = "NO HIT";
      } else if (selectedReportType === 'NO_HIT_AND_HITS') {
        previousFCTYState = "NO HIT";
        rescreenFCTYState = "HITS";
      }

      let inputRequestObj = {
        'rescanRequestId': rescanRequestId,
        'previousFCTYState': previousFCTYState,
        'rescreenFCTYState': rescreenFCTYState,
        'uIComponentID': 'GET_RESCREEN_RECON_MSG_DETAIL'
      };

      return this.rescreenReconciliationService.getRescreenReconReport(inputRequestObj).pipe(
        finalize(() => {
          this.isGridLoadingIndicator = false;
        }));
    }
  };

  // Refresh the component 
  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  // Load Report Type Dropdown values 
  private loadReportDropDown() {
    this.rescreenReconciliationService.getReportTypeDropdown().subscribe(dataResponse => {
      if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'RESCREEN_RECON_REPORT_TYPE')) {
        this.reportTypeDropDownItem = [];
        dataResponse.data.forEach(reportTypeElement => {
          this.reportTypeDropDownItem.push({
            'key': reportTypeElement.key,
            'value': reportTypeElement.value
          });
        });
      }
    });
  }

  // Generate report by calling REST service
  public generateReport() {
    if (this.rescreenReconReportForm.valid) {

      let rescanRequestId = this.rescreenReconReportForm.controls.rescanRequestID.value;
      let selectedReportType = this.rescreenReconReportForm.controls.reportType.value.key;
      let previousFCTYState = null;
      let rescreenFCTYState = null;

      if (selectedReportType === null) {
        this.rescreenReconReportForm.markAsDirty({});
        this.formErrors['reportType'] = 'Please Select Report Type';
        return;
      } else {
        this.formErrors['reportType'] = '';
      }

      if (selectedReportType === 'HITS_AND_HITS') {
        previousFCTYState = "HITS";
        rescreenFCTYState = "HITS";
      } else if (selectedReportType === 'HITS_AND_NO_HIT') {
        previousFCTYState = "HITS";
        rescreenFCTYState = "NO HIT";
      } else if (selectedReportType === 'NO_HIT_AND_NO_HIT') {
        previousFCTYState = "NO HIT";
        rescreenFCTYState = "NO HIT";
      } else if (selectedReportType === 'NO_HIT_AND_HITS') {
        previousFCTYState = "NO HIT";
        rescreenFCTYState = "HITS";
      }

      let inputRequestObj = {
        'rescanRequestId': rescanRequestId,
        'previousFCTYState': previousFCTYState,
        'rescreenFCTYState': rescreenFCTYState,
        'uIComponentID': 'GET_RESCREEN_RECON_MSG_DETAIL'
      };
      this.getRescreenReconReport(inputRequestObj);
    }
  }

  private getRescreenReconReport(inputRequestObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };
    this.rescreenReconciliationService.getRescreenReconReport(inputRequestObj).pipe(
      tap(rescreenReconData => {
        this.girdData = rescreenReconData.data;
      }))
      .subscribe(rescreenReconGridData => {
        if (((rescreenReconGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((rescreenReconGridData.metadata.uIComponentID === 'GET_RESCREEN_RECON_MSG_DETAIL'))) {
          if (rescreenReconGridData.data.length > 0) {
            this.rescreenReconGridData = this.rescreenReconciliationService.pipe(map(data => process(rescreenReconGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.rescreenReconGridData = this.rescreenReconciliationService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((rescreenReconGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.rescreenReconGridData = this.rescreenReconciliationService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = rescreenReconGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  // Form rest and clear the Grid values
  public resetMe() {
    this.rescreenReconReportForm.reset();
    this.rescreenReconGridData = this.rescreenReconciliationService.pipe(map(data => process([], this.gridState)));
    this.isGridLoadingIndicator = false;
    this.error = '';
  }

  // Unsubscribe to ensure no memory leaks
  ngOnDestroy() {
    this.rescreenReconciliationService.unsubscribe();
  }

}

