import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  ChangeDetectorRef, Inject, ViewChild, Output, EventEmitter, OnDestroy
} from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TnxRescanningService } from '../../../services/tnxRescanning.service';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';
import { TxnRescanningSeachComponentModel } from '../../../models/transactionRescanning/txnRescanningSeachComponentModel';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { RescanStatusCompletedModel } from '../../../models/transactionRescanning/detail/rescanStatusCompletedModel';
import * as moment from 'moment';
import { DashBoardUtil } from '../../../utils/dashBoardUtil';

@Component({
  selector: 'tnxRescanning',
  templateUrl: './tnxRescanning.component.html'
})

export class TnxRescanningComponent implements OnInit, OnDestroy {
  public gridTitle = 'Transaction Details';
  public transRescanGrid: Observable<GridDataResult>;
  public rescanStatusCompletedGrid: Observable<GridDataResult>;
  public popup_girdData: any[] = [];
  private tnxRescanningService: TnxRescanningService;
  txnRescanningSearchComponentsObj = new TxnRescanningSeachComponentModel();
  public txnRescanningForm: FormGroup;

  public fromDate = '';
  public toDate = '';
  public error: any = { isError: false, errorMessage: '' };
  public errormsg1: any = { isError: false, errorMessage: '' };
  public errormsg2: any = { isError: false, errorMessage: '' };

  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public defaultBUItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: 0 };

  public selectFormatItems: Array<SelectFormatDropdownModel> = [];
  public defaultItem: SelectFormatDropdownModel = { value: 'Please select format', key: 'SelectFormat' };
  public max: Date = new Date(this.getCurrDate());
  public gridState: State = { sort: [], skip: 0, take: 10 };
  private girdData: any[] = [];
  public isCreateRescanEnabled = false;

  public userNetworkId;
  public currentBUName;
  public currentBUId;
  public selectedBUName;
  public startTime;
  public endTime;
  public startTimeMaxTime;
  public endTimeMaxTime;

  public rescanStatusCompletedModel: RescanStatusCompletedModel;
  public isNew: boolean;
  public rescanRequestId;

  public buDropdown_loading_indicator: Boolean = false;
  public formatDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;
  public isPopupGridLoadingIndicator: Boolean = false;
  public isSubmitRescanClicked: String = 'hidden';

  public dashBoardUtil = new DashBoardUtil();

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(TnxRescanningService) tnxRescanningServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.tnxRescanningService = tnxRescanningServiceFactory();
  }

  public ngOnInit(): void {
    const networkID = localStorage.getItem('userNetworkId');
    const currentBUName = localStorage.getItem('currentBUName');
    const currentBUID = localStorage.getItem('currentBUId');

    if (networkID != null && networkID != '') {
      this.userNetworkId = JSON.parse(networkID);
    }

    if (currentBUName != null && currentBUName != '') {
      this.currentBUName = JSON.parse(currentBUName);
    }

    if (currentBUID != null && currentBUID != '') {
      this.currentBUId = JSON.parse(currentBUID);
    }

    this.initiateTxnSearchForm();
    this.loadSelectFormatDropDown();
    this.getCurrDate();
    this.verifyReadAndWriteAccess();
    this.loadSelectBUDropDown();
    //this.endDateMaxTime = new Date(moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'));
  }

  verifyReadAndWriteAccess() {
    let createRescanOption = localStorage.getItem('isCreateRescanEnabled');
    if (createRescanOption != '' && createRescanOption != null) {
      this.isCreateRescanEnabled = JSON.parse(localStorage.getItem('isCreateRescanEnabled'));
    } else {
      this.isCreateRescanEnabled = false;
    }
  }

  getCurrDate() {
    const dateMaxLimit = new Date();
    return dateMaxLimit;
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  initiateTxnSearchForm(): void {
    this.txnRescanningForm = this.formBuilder.group({
      'selectBU': [this.txnRescanningSearchComponentsObj.selectBU, [Validators.required]],
      'formatName': [this.txnRescanningSearchComponentsObj.formatName],
      'fromDate': [this.txnRescanningSearchComponentsObj.fromDate],
      'startTime': [this.txnRescanningSearchComponentsObj.toDate],
      'toDate': [this.txnRescanningSearchComponentsObj.toDate],
      'endTime': [this.txnRescanningSearchComponentsObj.toDate]
    });

    this.txnRescanningForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }


  onValueChanged(data?: any) {
    if (!this.txnRescanningForm) {
      return;
    }
    const form = this.txnRescanningForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'formatName': '',
    'selectBU': '',
  };

  validationMessages = {
    'formatName': {
      'required': 'Please select the formatName'
    },
    'selectBU': {
      'required': 'Please select the selectBU'
    }
  };

  public onStateChange(state: State) {
    this.gridState = state;
    //this.onSearch();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.transRescanGrid = this.tnxRescanningService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public startTimeChange() {
    let todayDate = new Date(moment(moment.now()).format('YYYY/MM/DD'));
    let selectedDate = new Date(moment(this.fromDate).format('YYYY/MM/DD'));
    if (todayDate <= selectedDate) {
      this.startTimeMaxTime = new Date(moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'));
    } else {
      this.startTimeMaxTime = '';
    }
  }

  public endTimeChange() {
    let todayDate = new Date(moment(moment.now()).format('YYYY/MM/DD'));
    let selectedDate = new Date(moment(this.toDate).format('YYYY/MM/DD'));
    if (todayDate <= selectedDate) {
      this.endTimeMaxTime = new Date(moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'));
    } else {
      this.endTimeMaxTime = '';
    }
  }

  /**
   * Open pop up on completed status
   * @param dataItem
   */
  public editHandler({ dataItem }) {
    // Cleaer the existing Message Details Grid values 
    this.rescanStatusCompletedGrid = this.tnxRescanningService.pipe(map(data => process([], this.gridState)));

    this.rescanStatusCompletedModel = dataItem;
    this.rescanRequestId = dataItem.rescanRequestId;
    this.selectedBUName = dataItem.buName;
    this.isNew = true;
    let reqObject = {
      'rescanRequestId': dataItem.rescanRequestId,
      'uIComponentID': 'TRANSACTION_RESCANING'
    };
    this.rescanStatusCompletedDetail(reqObject);
  }


  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }


  public submitRescan(): void {
    if (this.txnRescanningForm.valid) {
      this.isSubmitRescanClicked = 'show';
      let inputRequestObj, formatName, fromDateYYYYMMDD, toDateYYYYDDMM, calculateFromDate, calculateToDate, calculateStartTime, calculateEndDate;
      const fromDate = this.txnRescanningForm.controls.fromDate.value;
      const toDate = this.txnRescanningForm.controls.toDate.value;
      let buId = this.txnRescanningForm.controls.selectBU.value.buId;
      let buName = this.txnRescanningForm.controls.selectBU.value.buName;

      if (this.txnRescanningForm.controls.formatName.value != null) {
        formatName = this.txnRescanningForm.controls.formatName.value.key;
      }

      // Error check => BU = 0 + Format = invalid + From Date = invalid + To Date = invalid
      if ((buId == 0) && (formatName == undefined || formatName === 'SelectFormat') && (fromDate == null || fromDate == undefined) && (toDate == null || toDate == undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['selectBU'] = 'Please select the selectBU';
        this.formErrors['formatName'] = 'Please select the formatName';
        this.errormsg2 = { isError: true, errorMessage: 'Please select to date' };
        this.errormsg1 = { isError: true, errorMessage: 'Please select from date' };
        return;
      }

      // Error check => Format = invalid + From Date = invalid + To Date = invalid
      if ((formatName == undefined || formatName === 'SelectFormat') && (fromDate == null || fromDate == undefined) && (toDate == null || toDate == undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['formatName'] = 'Please select the formatName';
        this.errormsg2 = { isError: true, errorMessage: 'Please select to date' };
        this.errormsg1 = { isError: true, errorMessage: 'Please select from date' };
        return;
      }

      // Error check => Format = invalid + From Date = valid + To Date = valid
      if ((formatName == undefined || formatName === 'SelectFormat') && (fromDate != null || fromDate != undefined) && (toDate != null || toDate != undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
        this.formErrors['formatName'] = 'Please select the formatName';
        return;
      }

      // Error check => Format = invalid + From Date = Invalid + To Date = valid
      if ((formatName == undefined || formatName === 'SelectFormat') && (fromDate == null || fromDate == undefined) && (toDate != null || toDate != undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.errormsg1 = { isError: true, errorMessage: 'Please select from date' };
        this.errormsg2 = { isError: false, errorMessage: '' };
        this.formErrors['formatName'] = 'Please select the formatName';
        return;
      }

      // Error check => Format = invalid + From Date = valid + To Date = Invalid
      if ((formatName == undefined || formatName === 'SelectFormat') && (fromDate != null || fromDate != undefined) && (toDate == null || toDate == undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: true, errorMessage: 'Please select to date' };
        this.formErrors['formatName'] = 'Please select the formatName';
        return;
      }

      // Error check => Format = valid + From Date = invalid + To Date = invalid
      if ((formatName != undefined || formatName != 'SelectFormat') && (fromDate == null || fromDate == undefined) && (toDate == null || toDate == undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['formatName'] = '';
        this.errormsg2 = { isError: true, errorMessage: 'Please select to date' };
        this.errormsg1 = { isError: true, errorMessage: 'Please select from date' };
        return;
      }

      // Error check => Format = valid + From Date = valid + To Date = invalid
      if ((formatName != undefined || formatName != 'SelectFormat') && (fromDate != null || fromDate != undefined) && (toDate == null || toDate == undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['formatName'] = '';
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: true, errorMessage: 'Please select to date' };
        return;
      }

      // Error check => Format = valid + From Date = invalid + To Date = valid
      if ((formatName != undefined || formatName != 'SelectFormat') && (fromDate == null || fromDate == undefined) && (toDate != null || toDate != undefined)) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['formatName'] = '';
        this.errormsg2 = { isError: false, errorMessage: '' };
        this.errormsg1 = { isError: true, errorMessage: 'Please select from date' };
        return;
      }

      // Clear error message form date picker
      if ((toDate != null || toDate != undefined) && (fromDate != null || fromDate != undefined)) {
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
      }

      // To date can not be greater then from date
      if (new Date(this.txnRescanningForm.controls['toDate'].value) < new Date(this.txnRescanningForm.controls['fromDate'].value)) {
        this.error = { isError: true, errorMessage: 'To Date can not before start date' };
        return;
      } else {
        this.error = { isError: false, errorMessage: '' };
      }

      // Start Time and End validation
      if ((this.startTime != undefined && this.startTime != null) && (this.endTime != undefined && this.endTime != null)) {
        fromDateYYYYMMDD = this.dashBoardUtil.getDateAndTimeFormat(fromDate, this.startTime);
        toDateYYYYDDMM = this.dashBoardUtil.getDateAndTimeFormat(toDate, this.endTime);
      } else {
        fromDateYYYYMMDD = moment(fromDate).format('YYYY/MM/DD 00:00:00');
        toDateYYYYDDMM = moment(toDate).format('YYYY/MM/DD 23:59:59');
      }

      if ((formatName == null) || (formatName.key == 'SelectFormat')) {
        inputRequestObj = {
          'buId': buId,
          'buName': buName,
          'format': null,
          'fromDate': fromDateYYYYMMDD,
          'toDate': toDateYYYYDDMM,
          'status': 'Submitted',
          'requestType': 'Rescan',
          'submittedDt': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss')
        };
      } else {
        inputRequestObj = {
          'buId': buId,
          'buName': buName,
          'format': formatName,
          'fromDate': fromDateYYYYMMDD,
          'toDate': toDateYYYYDDMM,
          'status': 'Submitted',
          'requestType': 'Rescan',
          'submittedDt': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss')
        };
      }
      this.getRescanGridData(inputRequestObj);
    }
  }

  public onSearch(): void {
    if (this.txnRescanningForm.valid) {
      let buId = this.txnRescanningForm.controls.selectBU.value.buId;
      let buName = this.txnRescanningForm.controls.selectBU.value.buName;
      let formatName = this.txnRescanningForm.controls.formatName.value;
      let fromDate = this.txnRescanningForm.controls.fromDate.value;
      let toDate = this.txnRescanningForm.controls.toDate.value;
      let inputRequestObj, fromDateYYYYMMDD, toDateYYYYDDMM;

      if (buId == 0) {
        this.txnRescanningForm.markAsDirty({});
        this.formErrors['selectBU'] = 'Please select the selectBU';
        return;
      }

      if (fromDate != null || fromDate != undefined) {
        if (toDate == null || toDate == undefined) {
          this.errormsg2 = { isError: true, errorMessage: 'Please select toDate' };
          this.errormsg1 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if (toDate != null || toDate != undefined) {
        if (fromDate == null || fromDate == undefined) {
          this.errormsg1 = { isError: true, errorMessage: 'Please select fromDate' };
          this.errormsg2 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if ((toDate != null || toDate != undefined) && (fromDate != null || fromDate != undefined)) {
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
      }

      // Compare To date and from date
      if (new Date(this.txnRescanningForm.controls['toDate'].value) < new Date(this.txnRescanningForm.controls['fromDate'].value)) {
        this.error = { isError: true, errorMessage: 'To Date can not before start date' };
        return;
      } else {
        this.error = { isError: false, errorMessage: '' };
      }

      // From date and start time validation
      if (fromDate != null) {
        if (this.startTime != undefined && this.startTime != null) {
          fromDateYYYYMMDD = this.dashBoardUtil.getDateAndTimeFormat(fromDate, this.startTime);
        } else {
          fromDateYYYYMMDD = moment(fromDate).format('YYYY/MM/DD 00:00:00');
        }
      } else {
        fromDateYYYYMMDD = null;
      }

      // To date and end time validation
      if (toDate != null) {
        if (this.endTime != undefined && this.endTime != null) {
          toDateYYYYDDMM = this.dashBoardUtil.getDateAndTimeFormat(toDate, this.endTime);
        } else {
          toDateYYYYDDMM = moment(toDate).format('YYYY/MM/DD 23:59:59');
        }
      } else {
        toDateYYYYDDMM = null;
      }

      if ((formatName == null) || (formatName.key == 'SelectFormat')) {
        inputRequestObj = {
          'buId': buId,
          'buName': buName,
          'fromDate': fromDateYYYYMMDD,
          'format': null,
          'toDate': toDateYYYYDDMM,
          'uIComponentID': 'TRANSACTION_RESCANNING'
        };
      } else {
        inputRequestObj = {
          'buId': buId,
          'buName': buName,
          'fromDate': fromDateYYYYMMDD,
          'format': formatName.key,
          'toDate': toDateYYYYDDMM,
          'uIComponentID': 'TRANSACTION_RESCANNING'
        };
      }

      this.getRescanGridData(inputRequestObj);
    }
  }

  private getRescanGridData(inputRequestObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    this.tnxRescanningService.getTnxRescanningGridComponent(inputRequestObj)
      .pipe(
        tap(tnxRescanningGridData => {
          this.girdData = tnxRescanningGridData.data;
        }))
      .subscribe(tnxRescanningGridData => {
        if (((tnxRescanningGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((tnxRescanningGridData.metadata.uIComponentID === 'TRANSACTION_RESCANING'))) {

          if (tnxRescanningGridData.data.length > 0) {
            this.transRescanGrid = this.tnxRescanningService.pipe(map(data => process(tnxRescanningGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.transRescanGrid = this.tnxRescanningService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((tnxRescanningGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.transRescanGrid = this.tnxRescanningService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = tnxRescanningGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }


  /**
   * Load the select Format dropdown component
   */
  private loadSelectFormatDropDown() {
    this.formatDropdown_loading_indicator = true;
    const selectFormatRequestObj = '{ "searchCriteria1": [{ "key": "categoryName", "value": "Transaction", "datatype": "string"}, { "key": "subCategoryName", "value": "Format", "datatype": "string"}, { "key": "active", "value": "Active", "datatype": "string"},{ "key": "uiComponentID","value": "ADMIN_CONFIG_SEARCHBYID","datatype": "string"}]}';
    this.tnxRescanningService.getSelectFormatDropDownValues(selectFormatRequestObj).subscribe(crudConfigGridData => {
      crudConfigGridData.response.filter(dataResponse => {
        if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_CONFIG_SEARCHBYID'))) {
          dataResponse.data.forEach(selectFormatElement => {
            this.selectFormatItems.push(selectFormatElement);
          });
        }
        this.formatDropdown_loading_indicator = false;
      });
    });
    error => console.log(error);

  }

  /**
   * SEARCH COMPONENT RESET VALIDATION FORM
   *
   */
  public resetMe() {
    this.txnRescanningForm.reset();
    this.transRescanGrid = this.tnxRescanningService.pipe(map(data => process([], this.gridState)));
    this.isGridLoadingIndicator = false;
    this.isSubmitRescanClicked = 'hidden';
    this.errormsg1 = '';
    this.errormsg2 = '';
    this.error = '';
    this.startTime = undefined;
    this.endTime = undefined;
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.tnxRescanningService.unsubscribe();
  }

  /**
   * services call to load grid data in pop up on completed status
   * @param reqRef
   */
  public rescanStatusCompletedDetail(reqObject) {
    this.isPopupGridLoadingIndicator = true;
    this.tnxRescanningService.getRescanCompletedDetails(reqObject)
      .pipe(
        tap(rescanStatusCompletedGridData => {
          this.popup_girdData = rescanStatusCompletedGridData.data;
        }))
      .subscribe(rescanStatusCompletedGridData => {
        if (((rescanStatusCompletedGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((rescanStatusCompletedGridData.metadata.uIComponentID === 'TRANSACTION_RESCANING'))) {
          this.rescanStatusCompletedGrid = this.tnxRescanningService.pipe(map(data => process(rescanStatusCompletedGridData.data, this.gridState)));
          this.refresh();
        } else if ((rescanStatusCompletedGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.rescanStatusCompletedGrid = this.tnxRescanningService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = rescanStatusCompletedGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isPopupGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.tnxRescanningService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

}

