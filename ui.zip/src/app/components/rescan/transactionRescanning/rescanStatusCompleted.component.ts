import { Component, EventEmitter, Inject, Input, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { RescanStatusCompletedModel } from '../../../models/transactionRescanning/detail/rescanStatusCompletedModel';
import { process, State } from '@progress/kendo-data-query';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';
import { TnxRescanningService } from '../../../services/tnxRescanning.service';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { map, tap } from 'rxjs/operators';
import * as moment from 'moment';



@Component({
  selector: 'kendo-grid-detail-form',
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13 txnDetailWrapper col-sm-12">
      <kendo-dialog-titlebar>
        {{selectedBUName}}: Completed Rescan Details
      </kendo-dialog-titlebar>
      <div class="row">
        <div class="col-md-12">
          <kendo-grid
            [data]="rescanStatusCompletedGrid | async"
            [height]="495"
            [pageSize]="gridState.take" [skip]="gridState.skip" [sort]="gridState.sort"
            [pageable]="true" [sortable]="true" (pageChange)="pageChange($event)"
            (excelExport)="onExcelExport($event)"
            (dataStateChange)="onStateChange($event)" class="font13">

            <ng-template kendoGridToolbarTemplate>
              <button type="button" kendoGridExcelCommand icon="file-excel">
                <span class="k-icon k-i-file-excel font12" role="presentation"></span>Export to Excel
              </button>
              <button kendoGridPDFCommand icon="file-pdf">
                <span class="k-icon k-i-file-pdf font12" role="presentation"></span>Export to PDF
              </button>
            </ng-template>

            <kendo-grid-column field="messageId" title="MESSAGE ID"></kendo-grid-column>
            <kendo-grid-column field="decision" title="DECISION" [width]="120"></kendo-grid-column>
            <kendo-grid-column field="rescanDt" title="RESCAN DATE" [width]="210"></kendo-grid-column>

            <kendo-grid-excel fileName="Completed_Rescan_Details_{{currentDateTime}}.xlsx" [fetchData]="fetchAll">
            </kendo-grid-excel>
            
            <kendo-grid-pdf fileName="Completed_Rescan_Details_{{currentDateTime}}.pdf" [allPages]="true" paperSize="A4"
                            [repeatHeaders]="true" [landscape]="false" [scale]="0.7">
              <kendo-grid-pdf-margin top="2cm" left="1cm" right="1cm" bottom="2cm"></kendo-grid-pdf-margin>
              <ng-template kendoGridPDFTemplate let-pageNum="pageNum" let-totalPages="totalPages">
                <div class="intra-page-template">
                  <div class="header">
                    <div style="float: right">Page {{ pageNum }} of {{ totalPages }}</div>
                    Completed Rescan Details Generated On: {{currentDateTime}}
                  </div>
                  <div class="footer">
                    Page {{ pageNum }} of {{ totalPages }}
                  </div>
                </div>
              </ng-template>
            </kendo-grid-pdf>
          </kendo-grid>
        </div>
      </div>

      <kendo-dialog-actions class="btn-ok-Wrapper">
        <button class="btn btn-primary font13 rescan_completed_cancelBtn" (click)="onOK($event)">Close</button>
      </kendo-dialog-actions>
      <div *ngIf="isPopupGridLoadingIndicator" class="k-i-loading grid_loading_indicator"></div>
    </kendo-dialog>
      `
})

export class RescanStatusCompletedComponent {
  @Input() public rescanStatusCompletedGrid: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  private tnxRescanningService: TnxRescanningService;
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');

  public active = false;
  @Input() public rescanRequestId;
  @Input() public selectedBUName;
  @Input() public popup_girdData: any[];
  @Input() public isPopupGridLoadingIndicator;

  @Input()
  public set model(rescanStatusCompletedModel: RescanStatusCompletedModel) {
    this.active = rescanStatusCompletedModel !== undefined;
  }

  @Input() public isNew = false;
  @Output() ok: EventEmitter<RescanStatusCompletedModel> = new EventEmitter();

  /**
   * Trigger error message popup if the services is throwing an error
   */
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  public detailTxnRescanningForm: FormGroup = new FormGroup({});

  constructor(@Inject(TnxRescanningService) tnxRescanningServiceFactory: any) {
    this.tnxRescanningService = tnxRescanningServiceFactory();
  }

  public onOK(e): void {
    this.ok.emit(this.detailTxnRescanningForm.value);
    this.active = false;
    e.preventDefault();
  }

  private closeForm(): void {
    this.active = false;
  }


  public onStateChange(state: State) {
    this.gridState = state;
    if ((this.popup_girdData != undefined) && (this.popup_girdData.length)) {
      let sortedData = this.popup_girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.rescanStatusCompletedGrid = this.tnxRescanningService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    const reqObject = {
      'rescanRequestId': this.rescanRequestId,
      'uIComponentID': 'TRANSACTION_RESCANING'
    };
    return this.tnxRescanningService.exportAll(reqObject);
  };

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }
}
