import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {AuthContextService} from '../../services/authContext.service';
import {DomSanitizer} from '@angular/platform-browser';
import {RESTFulServiceURL} from '../../services/webService_URL/RESTFulServiceURL';
import {DashboardAuthGuardUtil} from '../../utils/dashboardAuthGuardUtil';


@Component({
  selector: 'home',
  templateUrl: './home.components.html'
})

export class HomeComponent implements OnInit, OnDestroy {

  public url;
  public userName;
  private authContextService: AuthContextService;
  public dashboardAuthGuardUtil = new DashboardAuthGuardUtil();

  public unitName;
  public isHomeSummaryViewEnabled = 'hidden';
  public isHomeAgingSummaryViewEnabled = 'hidden';
  public isHomeListMgmtViewEnabled = 'hidden';
  public isHomeProdSupportViewEnabled = 'hidden';
  public footer_min_height = 'hidden';

  constructor(@Inject(AuthContextService) authContextServiceFactory: any, private sanitizer: DomSanitizer) {
    this.authContextService = authContextServiceFactory();
    //this.url = this.sanitizer.bypassSecurityTrustResourceUrl();
  }

  public ngOnInit(): void {
    const authContext = JSON.parse(localStorage.getItem('context'));
    const environment = window.location.hostname;
    if (authContext != null) {
      this.loadUserInfoSection(authContext);
      this.loadDashboardWidgets();
    } else {
      // Recalling the services to update user info
      this.loadAuthContextService();
    }

    // Set dynamic web focus URL
    console.log("Environment: "+environment);
    if (environment.toUpperCase() === 'WEBFOCUS-SANCTIONSCREENING.US.BANK-DNS.COM') {
      this.url = RESTFulServiceURL.PROD_AGING_SUMMARY_WEB_FOCUS;
    } else if (environment.toUpperCase() === 'WEBFOCUS-SANCTIONSCREENING-UAT.US.BANK-DNS.COM') {
      this.url = RESTFulServiceURL.UAT_AGING_SUMMARY_WEB_FOCUS;
    } else {
      this.url = RESTFulServiceURL.IT_AGING_SUMMARY_WEB_FOCUS;
    }
  }

  public labelContent(e: any): string {
    return e.category;
  }

  loadUserInfoSection(authContext) {
    this.userName = authContext.userInfo.userName.toUpperCase();
  }

  loadDashboardWidgets() {
    const homeSummaryView = localStorage.getItem('isHomeSummaryViewEnabled');
    const homeAgingSummaryView = localStorage.getItem('isHomeAgingSummaryViewEnabled');
    const homeListMgmtView = localStorage.getItem('isHomeListMgmtViewEnabled');
    const homeProdSupportView = localStorage.getItem('isHomeProdSupportViewEnabled');

    if ((homeSummaryView != '') && JSON.parse(homeSummaryView)) {
      this.isHomeSummaryViewEnabled = 'show';
    }

    if ((homeAgingSummaryView != '') && JSON.parse(homeAgingSummaryView)) {
      this.isHomeAgingSummaryViewEnabled = 'show';
    }

    if ((homeListMgmtView != '') && JSON.parse(homeListMgmtView)) {
      this.isHomeListMgmtViewEnabled = 'show';
    }

    if ((homeProdSupportView != '') && JSON.parse(homeProdSupportView)) {
      this.isHomeProdSupportViewEnabled = 'show';
    }

    if (homeSummaryView == '' && homeAgingSummaryView == '' && homeListMgmtView == '' && homeProdSupportView == '') {
      this.footer_min_height = 'show';
    }

  }

  loadAuthContextService() {
    this.authContextService.getContextService().subscribe(
      response => {
        if (((response.metadata.status).toUpperCase() === 'SUCCESS') && ((response.metadata.uIComponentID === 'OFAC_USER_CONTEXT'))) {
          // Storing the values in the session object
          localStorage.setItem('context', JSON.stringify(response));
          this.loadUserInfoSection(JSON.parse(localStorage.getItem('context')));
          this.dashboardAuthGuardUtil.enableReadAndWriteAccess();
          this.loadDashboardWidgets();
        }
      });
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.authContextService.unsubscribe();
  }
}
