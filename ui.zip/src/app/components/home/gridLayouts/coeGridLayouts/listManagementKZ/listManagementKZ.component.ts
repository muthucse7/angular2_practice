import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, ChangeDetectorRef, OnDestroy, ViewEncapsulation, ViewChild } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { HomeService } from '../../../../../services/home.service';
import { map } from 'rxjs/operators/map';
import { OfacDashboardModel } from '../../../../../models/home/ofacDashboardModel';
import { FailureMsgPopupComponent } from '../../../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../../../services/sessionTimeout.service';
import { tap } from 'rxjs/operators';
import { DashBoardUtil } from '../../../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';
import * as moment from 'moment';


@Component({
  selector: 'listManagementKZ',
  templateUrl: './listManagementKZ.component.html',
  encapsulation: ViewEncapsulation.None
})

export class ListManagementKZComponent implements OnInit, OnDestroy {

  /**
   * Child component properties (passing the data)
   */
  public girdData: any[];
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');
  public lastRefreshDate = new Date().toLocaleString();
  public list_management_kz_View: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  public isNew: boolean;
  private dashboardService: HomeService;
  public ofacDashboardModel: OfacDashboardModel;
  public isGridLoadingIndicator: Boolean = false;
  public todaysDate = new DashBoardUtil().getCurrDate_MMDDYYYY_format();
  public dashBoardUtil = new DashBoardUtil();

  public categories: any[] = [];
  public completedStatus: any[] = [];
  public failedStatus: any[] = [];
  public pendingReviewStatus: any[] = [];

  /**
   * Trigger error message popup if the services is throwing an error
   */
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  constructor(@Inject(HomeService) dashboardServiceFactory: any, private _sessionTimeoutService: SessionTimeoutService) {
    this.dashboardService = dashboardServiceFactory();
  }

  /**
   * Invoking the REST services call for the COE_USER Grid & COE_USER_DONUT_CHART components
   */
  public ngOnInit(): void {
    this.loadHomeWidget();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    //this.loadHomeWidget();
    // Custom Sorting without loading entire services
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.list_management_kz_View = this.dashboardService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public addHandler() {
    this.loadHomeWidget();
  }

  public editHandler({ dataItem }) {
    this.ofacDashboardModel = dataItem;
    this.isNew = false;
  }

  public cancelHandler() {
    this.ofacDashboardModel = undefined;
  }

  public loadHomeWidget() {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
    let requestObj = {
      "uIComponentID": "MANAGEMENT_DATA"
    };
    this.dashboardService.fetchDashboardListMgt(requestObj).pipe(tap(res => {
      this.girdData = res.data;
    })).subscribe(res => {
      if (((res.metadata.status).toUpperCase() === 'SUCCESS') && (res.metadata.uIComponentID === 'MANAGEMENT_DATA')) {
        this.list_management_kz_View = this.dashboardService.pipe(map(data => process(res.data, this.gridState)));
        this.generateListMgntChart(res.data);
      }
      this.lastRefreshDate = new Date().toLocaleString();
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');

    });
  }

  public generateListMgntChart(listMgntData) {
    const chartData = this.dashBoardUtil.getListMgntChartData(listMgntData);
    this.categories = chartData.categories;
    this.completedStatus = chartData.completed;
    this.pendingReviewStatus = chartData.pendingReview;
    this.failedStatus = chartData.failed;
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    let requestObj = {
      "uIComponentID": "MANAGEMENT_DATA"
    };
    return this.dashboardService.fetchDashboardListMgt(requestObj).pipe(
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  };

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.dashboardService.unsubscribe();
  }
}
