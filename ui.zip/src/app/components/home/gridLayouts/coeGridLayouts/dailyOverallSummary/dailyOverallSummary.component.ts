import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, ChangeDetectorRef, OnDestroy, ViewEncapsulation, Input, ViewChild, Output } from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { HomeService } from '../../../../../services/home.service';
import { map } from 'rxjs/operators/map';
import { OfacDashboardModel } from '../../../../../models/home/ofacDashboardModel';
import { FailureMsgPopupComponent } from '../../../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../../../services/sessionTimeout.service';
import { DashBoardUtil } from '../../../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';
import { forEach } from '@angular/router/src/utils/collection';
import * as moment from 'moment';


@Component({
  selector: 'dailyOverallSummary',
  templateUrl: './dailyOverallSummary.component.html',
  encapsulation: ViewEncapsulation.None
})

export class DailyOverallSummaryComponent implements OnInit, OnDestroy {

  /**
   * Child component properties (passing the data)
   */
  public girdData: any[];
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');
  public lastRefreshDate = new Date().toLocaleString();
  public dashBoardUtil = new DashBoardUtil();

  // Bar chart data
  public messageReceived: Number;
  public messageWithNoHits: Number;
  public messageWithHits: Number;
  public totalHits: Number;
  public percentageOfHitRate: Number;
  public hitsPendingReview: Number;

  public daily_Overall_Summary_View: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  public isNew: boolean;
  private dashboardService: HomeService;
  public ofacDashboardModel: OfacDashboardModel;

  public isGridLoadingIndicator: Boolean = false;

  public messageWithHitsData: any[] = [];
  public messageWithHitsTitle = 'Message With Hits';
  public businessUnitColorCodes: any[];

  public hitsPendingReviewData: any[] = [];
  public hitsPendingReviewTile = 'Hits Pending Review';

  public totalHitsData: any[] = [];
  public totalHitsTitle = 'Total Hits';

  public stopRateData: any[] = [];
  public stopRateBusinessUnit: any[] = [];
  public stopRateDataTitle = 'Alert/Stop Rate %';

  public totalReceivedData: any[] = [];
  public totalReceivedTitle = 'Messages Received';

  public alertsRateData: any[];
  public alertRateBusinessUnit: any[];
  public alertRateDataTitle = 'Hit Rate %';

  public messagesWNoHitsData: any[] = [];
  public messagesWNoHitsTitle = 'Messages With No Hits';

  public todaysDate = new DashBoardUtil().getCurrDate_MMDDYYYY_format();


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  constructor(@Inject(HomeService) dashboardServiceFactory: any, private _sessionTimeoutService: SessionTimeoutService) {
    this.dashboardService = dashboardServiceFactory();
  }

  /**
   * Invoking the REST services call for the COE_USER Grid & COE_USER_DONUT_CHART components
   */
  public ngOnInit(): void {
    this.loadHomeWidget();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    // Custom Sorting without loading entire services
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.daily_Overall_Summary_View = this.dashboardService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }


  // Export XL fetching all the data from the database
  /*public fetchAll = (): Observable<any> => {
    //this.isGridLoadingIndicator = true;
    let requestObj = {
      'uIComponentID': 'DASHBOARD_SUMMARY'
    };
    return this.dashboardService.getOverallSummary(requestObj).pipe(
      map((response) => {
        return 
        console.log("data"+response['data'][0].dashboardSummaryList);
      }),
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  } */

  public addHandler() {
    this.loadHomeWidget();
  }

  public editHandler({ dataItem }) {
    this.ofacDashboardModel = dataItem;
    this.isNew = false;
  }

  public cancelHandler() {
    this.ofacDashboardModel = undefined;
  }

  public loadHomeWidget() {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    let requestObj = {
      'uIComponentID': 'DASHBOARD_SUMMARY'
    };

    this.dashboardService.getOverallSummary(requestObj).subscribe(response => {
      if (((response.metadata.status).toUpperCase() === 'SUCCESS') && (response.metadata.uIComponentID === 'DASHBOARD_SUMMARY')) {
        response.data.forEach(dataObj => {
          this.daily_Overall_Summary_View = this.dashboardService.pipe(map(response => process(dataObj.dashboardSummaryList, this.gridState)));
          this.girdData = dataObj.dashboardSummaryList;
          // Bar charts data mapping
          this.messageReceived = dataObj.summaryTotal.sumTotalReceived;
          this.messageWithNoHits = dataObj.summaryTotal.sumTotalNoHits;
          this.messageWithHits = dataObj.summaryTotal.sumTotalHits;
          this.totalHits = dataObj.summaryTotal.sumTotalOpenFinalHits;
          this.percentageOfHitRate = dataObj.summaryTotal.sumTotalPercentageHits;
          this.hitsPendingReview = dataObj.summaryTotal.sumTotalOpen;

          // Preparing Message with Hits chart data
          this.prepareOverallSummaryChartsData(dataObj.dashboardSummaryList);

        });
      }
      this.lastRefreshDate = new Date().toLocaleString();
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');

    });
  }

  prepareOverallSummaryChartsData(dashboardSummaryList) {
    this.clearOverallSummaryChartsData();
    dashboardSummaryList.forEach(response => {
      // Message With Hits
      this.messageWithHitsData.push({
        category: response.businessUnit, value: response.totalHits
      });

      // Hits Pending Review
      this.hitsPendingReviewData.push({
        category: response.businessUnit, value: response.totalOpen
      });

      // Total Hits
      this.totalHitsData.push({
        category: response.businessUnit, value: response.totalOpenFinalHits
      });

      // Alerts Rate
      this.alertsRateData.push(response.totalPercentageHits);
      this.alertRateBusinessUnit.push(response.businessUnit);

      // Stop Rate
      this.stopRateData.push(response.totalStopRate);
      this.stopRateBusinessUnit.push(response.businessUnit);

      // Total Received
      this.totalReceivedData.push({
        kind: response.businessUnit, share: response.totalReceived
      });

      // Messages With No Hits
      this.messagesWNoHitsData.push({
        kind: response.businessUnit, share: response.totalNoHits
      });

    });
    // Get the color code in each business unit
    this.businessUnitColorCodes = this.dashBoardUtil.getChartColorCodes(dashboardSummaryList);
  }

  clearOverallSummaryChartsData() {
    this.messageWithHitsData = [];
    this.hitsPendingReviewData = [];
    this.totalHitsData = [];
    this.alertsRateData = [];
    this.alertRateBusinessUnit = [];
    this.stopRateData = [];
    this.stopRateBusinessUnit = [];
    this.totalReceivedData = [];
    this.messagesWNoHitsData = [];
  }


  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.dashboardService.unsubscribe();
  }

  /**
   * Display chart according to selected row
   */
  public selectedRowChange(e) {
    let selectedItem = e.selectedRows[0].dataItem;
    this.messageReceived = selectedItem.totalReceived;
    this.messageWithNoHits = selectedItem.totalNoHits;
    this.messageWithHits = selectedItem.totalHits;
    this.totalHits = selectedItem.totalOpenFinalHits;
    this.percentageOfHitRate = selectedItem.totalPercentageHits;
    this.hitsPendingReview = selectedItem.totalOpen;
  }

}
