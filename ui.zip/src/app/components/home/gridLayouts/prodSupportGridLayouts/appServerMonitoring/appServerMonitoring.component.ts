import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {process, State} from '@progress/kendo-data-query';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {HomeService} from '../../../../../services/home.service';
import {map} from 'rxjs/operators/map';
import {OfacDashboardModel} from '../../../../../models/home/ofacDashboardModel';
import {AppServerDetailsPopupModel} from '../../../../../models/home/prodWidget/appServerDetailsPopupModel';
import {SessionTimeoutService} from '../../../../../services/sessionTimeout.service';
import {tap} from 'rxjs/operators';
import { DashBoardUtil } from '../../../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';
import * as moment from 'moment';



@Component({
  selector: 'app-serverMonitoring',
  templateUrl: './appServerMonitoring.component.html'
})

export class AppServerMonitoringComponent implements OnInit, OnDestroy {

  public currentDateTime = moment(new Date()).format('MM:DD:YYYY, h:mm:ss A');
  public lastRefreshDate = new Date().toLocaleString();
  private dashboardService: HomeService;
  public prod_components_status_view: Observable<GridDataResult>;
  public ofacDashboardModel: OfacDashboardModel;
  public serverDetailsPopupGrid: Observable<GridDataResult>;
  public isNew: boolean;
  public gridState: State = {sort: [], skip: 0, take: 10};
  public isGridLoadingIndicator: Boolean = false;
  public girdData: any[];
  public popup_gridData: any[] = [];
  public appServerDetailsPopupModel: AppServerDetailsPopupModel;
  public status;
  public componentType;
  public dashBoardUtil = new DashBoardUtil();

  constructor(@Inject(HomeService) dashboardServiceFactory: any, private _sessionTimeoutService: SessionTimeoutService) {
    this.dashboardService = dashboardServiceFactory();
  }


  public ngOnInit(): void {
     //this.loadBackendServerStatus();
  }

  public loadBackendServerStatus() {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
    let requestObj = {
      'uIComponentID': 'GET_COMPONENT_STATUS'
    };
    this.dashboardService.getBackendServerStatusGridData(requestObj).pipe(tap(res => {
      this.girdData = res.data;
    })).subscribe(res => {
      if (((res.metadata.status).toUpperCase() === 'SUCCESS') && (res.metadata.uIComponentID === 'GET_COMPONENT_STATUS')) {
        this.prod_components_status_view = this.dashboardService.pipe(map(data => process(res.data, this.gridState)));
      }
      this.lastRefreshDate = this.girdData[0].lastJobRunDate;
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');

    });
  }

  public onStateChange(state: State) {
    this.gridState = state;
    // Custom Sorting without loading entire services
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.prod_components_status_view = this.dashboardService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public editHandler({dataItem}) {
    const requestObj = {
      "fromDate": dataItem.fromDate,
      "toDate": dataItem.toDate,
      "serverName": dataItem.serverName,
      'uIComponentID': 'GET_COMPONENT_DETAILS'
    };
    this.appServerDetailsPopupModel = dataItem;
    this.isNew = true;
    this.componentType = dataItem.componentType;
    

    //this.getBackendCompDetailsPopupGridData(requestObj);
  }

  /**
   * services call to load grid data in pop up to show servers details
   * @param reqRef
   */
  public getBackendCompDetailsPopupGridData(requestObj) {

    this.dashboardService.getBackendCompDetailsPoupData(requestObj).pipe(tap(res => {
      this.popup_gridData = res.data;
    })).subscribe(res => {
      if (((res.metadata.status).toUpperCase() === 'SUCCESS') && (res.metadata.uIComponentID === 'GET_COMPONENT_DETAILS')) {
        this.serverDetailsPopupGrid = this.dashboardService.pipe(map(data => process(res.data, this.gridState)));
      }
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');

    });
    
  }

  public cancelHandler() {
    this.ofacDashboardModel = undefined;
  }

  public gridRefresh(){
     this.loadBackendServerStatus();
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;
    const requestObj = {
      "uIComponentID" :"GET_COMPONENT_STATUS"
    };
    return this.dashboardService.getBackendServerStatusGridData(requestObj).pipe(
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  };

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }

  
  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.dashboardService.unsubscribe();
  }

}
