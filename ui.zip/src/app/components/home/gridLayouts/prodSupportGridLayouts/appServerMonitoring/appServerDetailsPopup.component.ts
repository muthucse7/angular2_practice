import {Component, EventEmitter, Inject, Input, Output, ViewChild} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {AppServerDetailsPopupModel} from '../../../../../models/home/prodWidget/appServerDetailsPopupModel';
import {process, State} from '@progress/kendo-data-query';
import {GridDataResult, PageChangeEvent} from '@progress/kendo-angular-grid';
import {Observable} from 'rxjs/Observable';
import {HomeService} from '../../../../../services/home.service';
import {FailureMsgPopupComponent} from '../../../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../../../services/sessionTimeout.service';
import {map, tap} from 'rxjs/operators';


@Component({
  selector: 'kendo-grid-server-details-form',
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13 serverDetailsWrapper col-sm-12">
      <kendo-dialog-titlebar>
        {{componentType}}: SubComponent/Server Details
      </kendo-dialog-titlebar>
      <div id="backend_server_details_gridContent">
        <div class="row">
          <div class="col-md-12">
            <kendo-grid
              [data]="serverDetailsPopupGrid | async"
              [height]="430"
              [pageSize]="gridState.take" [skip]="gridState.skip" [sort]="gridState.sort"
              [pageable]="true" [sortable]="true" (pageChange)="pageChange($event)"
              (dataStateChange)="onStateChange($event)" class="font13">

              <kendo-grid-column field="componentName" title="Component Name" [width]="78"></kendo-grid-column>
              <kendo-grid-column field="serverName" title="Server" [width]="100"></kendo-grid-column>
              <kendo-grid-column field="subComponent" title="Subcomponent" [width]="190"></kendo-grid-column>
              <kendo-grid-column field="serverEnvironment" title="Environment" [width]="70"></kendo-grid-column>
              <kendo-grid-column field="flag" title="Status" [width]="80">
                   <ng-template kendoGridCellTemplate let-statusItem>
                      <div class="running_status fill_grid_column" *ngIf="statusItem.flag=='Running';">
                        <span>{{statusItem.flag}}</span>
                      </div>
                      <div class="failed_status fill_grid_column" *ngIf="statusItem.flag=='Failed';">
                        <span>{{statusItem.flag}}</span>
                    </div>
                </ng-template>
              </kendo-grid-column>
              <kendo-grid-column field="runningSince" title="Last Refreshed On" [width]="120"> </kendo-grid-column>
            </kendo-grid>
          </div>
        </div>
      </div>
      <kendo-dialog-actions class="btn-ok-Wrapper">
        <button class="btn btn-primary font13 rescan_completed_cancelBtn" (click)="onOK($event)">Close</button>
      </kendo-dialog-actions>

    </kendo-dialog>
    <div *ngIf="isGridLoadingIndicator" class="k-i-loading grid_loading_indicator"></div>
  `
})

export class AppServerDetailsPopup {
  @Input() public serverDetailsPopupGrid: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  private dashboardService: HomeService;
  public isGridLoadingIndicator: Boolean = false;
  public gridData: any[];

  public active = false;
  @Input() public popup_gridData: any[];
  @Input() public componentType;

  @Input()
  public set model(appServerDetailsPopupModel: AppServerDetailsPopupModel) {
    this.active = appServerDetailsPopupModel !== undefined;
    console.log('this.active ' + this.active);
  }

  @Input() public isNew = false;
  @Output() ok: EventEmitter<AppServerDetailsPopupModel> = new EventEmitter();

  /**
   * Trigger error message popup if the services is throwing an error
   */
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  public serverDetailForm: FormGroup = new FormGroup({});

  constructor(@Inject(HomeService) dashboardServiceFactory: any, private _sessionTimeoutService: SessionTimeoutService) {
    this.dashboardService = dashboardServiceFactory();
  }

  public onOK(e): void {
    this.ok.emit(this.serverDetailForm.value);
    this.active = false;
    e.preventDefault();
  }

  private closeForm(): void {
    this.active = false;

  }

  public onStateChange(state: State) {
    this.gridState = state;
    if ((this.popup_gridData != undefined) && (this.popup_gridData.length)) {
      let sortedData = this.popup_gridData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.serverDetailsPopupGrid = this.dashboardService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    let requestObj = {
      'uIComponentID': 'DASHBOARD_SUMMARY'
    };
    return this.dashboardService.getBatchSystemStatus(requestObj);
  };

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

}
