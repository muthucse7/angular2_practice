import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {process, State} from '@progress/kendo-data-query';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {HomeService} from '../../../../../services/home.service';
import {map} from 'rxjs/operators/map';
import {SessionTimeoutService} from '../../../../../services/sessionTimeout.service';


@Component({
  selector: 'app-batchServerMonitoring',
  templateUrl: './batchServerMonitoring.html'
})

export class BatchServerMonitoringComponent implements OnInit, OnDestroy {

  public currentDateTime = new Date().toLocaleString();
  public lastRefreshDate = new Date().toLocaleString();
  private dashboardService: HomeService;
  public batch_view: Observable<GridDataResult>;
  public isNew: boolean;
  public gridState: State = {sort: [], skip: 0, take: 10};
  public girdData: any[];
  public isGridLoadingIndicator: Boolean = false;

  constructor(@Inject(HomeService) dashboardServiceFactory: any, private _sessionTimeoutService: SessionTimeoutService) {
    this.dashboardService = dashboardServiceFactory();
  }

  public ngOnInit(): void {
    // this.loadBatchSystemStatus();
  }

  public gridRefresh(){
   // this.loadBatchSystemStatus();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    // Custom Sorting without loading entire services
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.batch_view = this.dashboardService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  private loadBatchSystemStatus() {
    this.isGridLoadingIndicator = true;
    const requestObj = {'uIComponentID': 'DASHBOARD_SUMMARY'};
    this.dashboardService.getBatchSystemStatus(requestObj).subscribe(response => {
      if (((response.metadata.status).toUpperCase() === 'SUCCESS') && (response.metadata.uIComponentID === 'BATCH_COMPONENTS')) {
        this.girdData = response.data;
        this.batch_view = this.dashboardService.pipe(map(value => process(response.data, this.gridState)));
      }
      this.lastRefreshDate = new Date().toLocaleString();
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    let requestObj = {
      "uIComponentID" :"DASHBOARD_SUMMARY"
    };
    return this.dashboardService.getBatchSystemStatus(requestObj);
  };

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.dashboardService.unsubscribe();
  }

}
