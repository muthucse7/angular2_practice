import {
  Component,
  OnInit,
  ChangeDetectorRef, Inject, ViewChild, Output, EventEmitter, OnDestroy
} from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { UserActivityEventService } from '../../../services/userActivityEvent.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { UserActivityFromModel } from '../../../models/userActivityEvent/userActivityFromModel';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';

@Component({
  selector: 'userActivityEvent',
  templateUrl: './userActivityEvent.component.html'
})

export class UserActivityEventComponent implements OnInit, OnDestroy {

  public userActivityEventGrid: Observable<GridDataResult>;
  private userActivityEventService : UserActivityEventService;
  private userActivityFromModel = new UserActivityFromModel();
  public userActivityEventForm: FormGroup;

  public gridState: State = { sort: [], skip: 0, take: 10 };
  private girdData: any[] = [];

  // Error message for Log date
  public error: any = { isError: false, errorMessage: '' };
  public errormsg1: any = { isError: false, errorMessage: '' };
  public errormsg2: any = { isError: false, errorMessage: '' };
  public min: Date = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() - 7);
  public max: Date = new Date(this.getCurrDate());
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');

  //dropdown dashboard page
  public defaultFnText: SelectFunctionDropdownModel = {'functionName': 'Select dashboard page', 'functionId': -1};
  public selectFunctionItems: Array<SelectFunctionDropdownModel> = [];

  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;
  public startDateYYYYMMDD;
  public endDateYYYYDDMM;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(UserActivityEventService) userActivityEventServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.userActivityEventService = userActivityEventServiceFactory();
  }

  public ngOnInit(): void {
    this.initiateuserActivityEventForm();
    this.loadManageFunctionGridComponent();
    this.getCurrDate();
  }

  initiateuserActivityEventForm(): void {
    this.userActivityEventForm = this.formBuilder.group({
      'eventLogFromDt': [this.userActivityFromModel.eventLogFromDt, [Validators.required]],
      'eventLogToDt': [this.userActivityFromModel.eventLogToDt, [Validators.required]],
      'dashboardPage': [this.userActivityFromModel.dashboardPage]
    });
    this.userActivityEventForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  
  onValueChanged(data?: any) {
    if (!this.userActivityEventForm) {
      return;
    }
    const form = this.userActivityEventForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }

  
  formErrors = {
    'eventLogFromDt': '',
    'eventLogToDt': ''
  };

  validationMessages = {
    'eventLogFromDt': {
      'required': 'Please select Event Log Date From'
    },
    'eventLogToDt': {
      'required': 'Please select Event Log Date To'
    }
  };

  
  public onStateChange(state: State) {
    this.gridState = state;
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.userActivityEventGrid = this.userActivityEventService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  getCurrDate() {
    const dateMaxLimit = new Date();
    return dateMaxLimit;
  }

  public convertDateToYYYYMMDDFormat(dateFormat){
    return moment(dateFormat).format('YYYYMMDD');
  }

  public onSearch(): void {
    if (this.userActivityEventForm.valid) {
      let inputRequestObj;
      let startDate = this.userActivityEventForm.controls.eventLogFromDt.value;
      let endDate = this.userActivityEventForm.controls.eventLogToDt.value;
      let dashboardPage = "";
      if(this.userActivityEventForm.controls.dashboardPage.value!=null){
        if(this.userActivityEventForm.controls.dashboardPage.value.functionId!=-1){
          dashboardPage = this.userActivityEventForm.controls.dashboardPage.value.functionName;
        }
      }

      if (startDate != null || startDate != undefined) {
        if (endDate == null || endDate == undefined) {
          this.errormsg2 = { isError: true, errorMessage: 'Please select Event Log Date To' };
          this.errormsg1 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if (endDate != null || endDate != undefined) {
        if (startDate == null || startDate == undefined) {
          this.errormsg1 = { isError: true, errorMessage: 'Please select Event Log Date From' };
          this.errormsg2 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if ((endDate != null || endDate != undefined) && (startDate != null || startDate != undefined)) {
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
      }

      // Compare To date and from date
      if (new Date(this.userActivityEventForm.controls['eventLogToDt'].value) < new Date(this.userActivityEventForm.controls['eventLogFromDt'].value)) {
        this.error = { isError: true, errorMessage: 'Log To Date can not before start Log Date From' };
        return;
      } else {
        this.error = { isError: false, errorMessage: '' };
      }

      if (startDate != null) {

        this.startDateYYYYMMDD = moment(startDate).format('YYYY-MM-DD');
      } else {
        this.startDateYYYYMMDD = null;
      }

      if (endDate != null) {
        this.endDateYYYYDDMM = moment(endDate).format('YYYY-MM-DD');
      } else {
        this.endDateYYYYDDMM = null;
      }

      inputRequestObj = {
        'dashboardPage':dashboardPage,
        'eventLogFromDt': this.startDateYYYYMMDD,
        'eventLogToDt': this.endDateYYYYDDMM,
        'uIComponentID': 'USER_ACTIVITY_EVENT_SEARCH'
      };
      this.getuserActivityEventGridData(inputRequestObj);
    }
  }

  private getuserActivityEventGridData(inputRequestObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    this.userActivityEventService.getUserActivityGridComponent(inputRequestObj)
      .pipe(
        tap(userActivityGridData => {
          this.girdData = userActivityGridData.data;
        }))
      .subscribe(userActivityGridData => {
        if (((userActivityGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((userActivityGridData.metadata.uIComponentID === 'USER_ACTIVITY_EVENT_SEARCH'))) {

          if (userActivityGridData.data.length > 0) {
            this.userActivityEventGrid = this.userActivityEventService.pipe(map(data => process(userActivityGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.userActivityEventGrid = this.userActivityEventService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((userActivityGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.userActivityEventGrid = this.userActivityEventService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = userActivityGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

   /**
   * Load the Dashboard Page dropdown 
   */
  private loadManageFunctionGridComponent() {
    const inputRequestObj = {'buId': '861', 'uIComponentID': 'AUTHORIZATION_BU_FUNCATION'};
    this.userActivityEventService.getDashboardFunctionDropdown(inputRequestObj).subscribe(dashboardFunctionDropdownData => {
      dashboardFunctionDropdownData.response.filter(dataResponse => {
          if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_BU_FUNCTION')) {
            this.selectFunctionItems = [];
            dataResponse.data.forEach(selectFunctionElement => {
              this.selectFunctionItems.push({
                'functionName': selectFunctionElement.functionName,
                'functionId': selectFunctionElement.functionId
              });
            });
          }
          this.isGridLoadingIndicator = false;
          this._sessionTimeoutService.filter('Session timeout Reset called');
        });
      });
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    if (this.userActivityEventForm.valid) {
      let startDate = this.userActivityEventForm.controls.eventLogFromDt.value;
      let endDate = this.userActivityEventForm.controls.eventLogToDt.value;
      let dashboardPage = "";
      if(this.userActivityEventForm.controls.dashboardPage.value!=null){
        if(this.userActivityEventForm.controls.dashboardPage.value.functionId!=-1){
          dashboardPage = this.userActivityEventForm.controls.dashboardPage.value.functionName;
        }
      }

      if (startDate != null) {
        this.startDateYYYYMMDD = moment(startDate).format('YYYY-MM-DD');
      } else {
        this.startDateYYYYMMDD = null;
      }

      if (endDate != null) {
        this.endDateYYYYDDMM = moment(endDate).format('YYYY-MM-DD');
      } else {
        this.endDateYYYYDDMM = null;
      }

      const inputGenerateReportObj = {
        'dashboardPage':dashboardPage,
        'eventLogFromDt': this.startDateYYYYMMDD,
        'eventLogToDt': this.endDateYYYYDDMM,
        'uIComponentID': 'USER_ACTIVITY_EVENT_SEARCH'
      };
      return this.userActivityEventService.getUserActivityGridComponent(inputGenerateReportObj).pipe(
        finalize(() => {
          this.isGridLoadingIndicator = false;
        }));
    }
  };
  
  /**
   * SEARCH COMPONENT RESET VALIDATION FORM
   *
   */
  public resetMe() {
    this.userActivityEventForm.reset();
    this.userActivityEventGrid = this.userActivityEventService.pipe(map(data => process([], this.gridState)));
    this.isGridLoadingIndicator = false;
    this.errormsg1 = '';
    this.errormsg2 = '';
    this.error = '';
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.userActivityEventService.unsubscribe();
  }

}
