import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  ChangeDetectorRef, Inject, ViewChild, Output, EventEmitter, OnDestroy
} from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { LogSearchService } from '../../../services/logSearch.service';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';
import { LogSearchComponentModel } from '../../../models/logSearch/logSearchComponentModel';
import { DatePipe } from '@angular/common';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';

@Component({
  selector: 'logSearch',
  templateUrl: './logSearch.component.html'
})

export class LogSearchComponent implements OnInit, OnDestroy {
  public gridTitle = 'Log Search';
  public logSearchGridData: Observable<GridDataResult>;
  public valueFrom = '';
  public valueTo = '';
  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10
  };
  public logSearchForm: FormGroup;
  logSearchSearchComponentsObj = new LogSearchComponentModel();
  private logSearchService: LogSearchService;

  private girdData: any[] = [];
  public userNetworkId;
  public currentUnitName;

  public endDateMaxTime: Date = new Date();

  // Grid Column display
  public grid_column_bUID = false;
  public grid_column_transcaionID = false;
  public grid_column_conextID = false;
  public grid_column_message = false;
  public isGridLoadingIndicator: Boolean = false;
  public itemDisabled: Boolean = false;


  // Default value selected from dropdown
  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public defaultItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: -1 };

  public searchTypeDefault = { value: 'Please select search type', key: 'placeholder' };
  public selectSearchTypeItems: Array<SelectSearchTypeDropdownModel> = [];

  public buDropdown_loading_indicator: Boolean = false;
  public searchDropdown_loading_indicator: Boolean = false;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  public error: any = { isError: false, errorMessage: '' };
  public errormsg1: any = { isError: false, errorMessage: '' };
  public errormsg2: any = { isError: false, errorMessage: '' };


  constructor(@Inject(LogSearchService) logSearchServiceFactory: any, private formBuilder: FormBuilder, private datePipe: DatePipe, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.logSearchService = logSearchServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    const unitName = localStorage.getItem('unitName');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }

    if (unitName != null && unitName != '') {
      this.currentUnitName = unitName;
    } else {
      this.currentUnitName = null;
    }
    this.buildForm();
    this.loadSelectBUDropDown();
    this.loadSearchTypeElementDropDown();

  }

  buildForm(): void {
    this.logSearchForm = this.formBuilder.group({
      'searchType': [this.logSearchSearchComponentsObj.searchType, [Validators.required]],
      'buName': [this.logSearchSearchComponentsObj.buName],
      'contextId': [this.logSearchSearchComponentsObj.contextId],
      'transactionId': [this.logSearchSearchComponentsObj.transactionId],
      'fromDate': [this.logSearchSearchComponentsObj.fromDate],
      'toDate': [this.logSearchSearchComponentsObj.toDate]
    });

    this.logSearchForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    if (!this.logSearchForm) {
      return;
    }
    const form = this.logSearchForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'searchType': ''
  };

  validationMessages = {
    'searchType': {
      'required': 'Please select the searchType.'
    }
  };


  public onStateChange(state: State) {
    this.gridState = state;
    //this.onLogSearch();
    // Custom Sorting without loading entire services
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.logSearchGridData = this.logSearchService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }


  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  /**
   * On Log Search:
   **/
  public onLogSearch(): void {
    if (this.logSearchForm.valid) {
      const searchType = this.logSearchForm.controls.searchType.value.key;
      let buId, buName, contextId, transactionId, fromDate, toDate, fromDateYYYYMMDD, toDateYYYYDDMM, buList = [];
      if (this.logSearchForm.controls.buName.value != null) {
        buId = this.logSearchForm.controls.buName.value.buId;
      }
      if (this.logSearchForm.controls.buName.value != null) {
        buName = this.logSearchForm.controls.buName.value.buName;
      }
      if (this.logSearchForm.controls.contextId.value != null) {
        contextId = this.logSearchForm.controls.contextId.value;
      }
      if (this.logSearchForm.controls.transactionId.value != null) {
        transactionId = this.logSearchForm.controls.transactionId.value;
      }
      if (this.logSearchForm.controls.fromDate.value != null) {
        fromDate = this.logSearchForm.controls.fromDate.value;
      }
      if (this.logSearchForm.controls.toDate.value != null) {
        toDate = this.logSearchForm.controls.toDate.value;
      }

      // Grid Column displays dynamically
      if (searchType.toUpperCase() == 'RESCAN') {
        this.grid_column_bUID = false;
        this.grid_column_transcaionID = false;
        this.grid_column_conextID = false;
        this.grid_column_message = false;
      } else if (searchType.toUpperCase() == 'OFACDASHBOARD') {
        this.grid_column_bUID = true;
        this.grid_column_transcaionID = true;
        this.grid_column_conextID = true;
        this.grid_column_message = false;
      } else if (searchType.toUpperCase() == 'MQERRORQUEUE') {
        this.grid_column_conextID = true;
        this.grid_column_bUID = true;
        this.grid_column_transcaionID = false;
        this.grid_column_message = true;
      } else if (searchType.toUpperCase() == 'GOLDENDATA') {
        this.grid_column_conextID = false;
        this.grid_column_bUID = false;
        this.grid_column_transcaionID = true;
        this.grid_column_message = false;
      } else {
        this.grid_column_bUID = false;
        this.grid_column_transcaionID = false;
        this.grid_column_conextID = false;
        this.grid_column_message = false;
      }

      if (searchType.toUpperCase() == 'PLACEHOLDER') {
        this.logSearchForm.markAsDirty({});
        this.formErrors['searchType'] = 'Please select the searchType.'
        return;
      }

      if (fromDate != null || fromDate != undefined) {
        if (toDate == null || toDate == undefined) {
          this.errormsg2 = { isError: true, errorMessage: 'Please select toDate' };
          this.errormsg1 = { isError: false, errorMessage: '' };
          return;
        }

      }
      if (toDate != null || toDate != undefined) {
        if (fromDate == null || fromDate == undefined) {
          this.errormsg1 = { isError: true, errorMessage: 'Please select fromDate' };
          this.errormsg2 = { isError: false, errorMessage: '' };
          return;
        }
      }

      if ((toDate != null || toDate != undefined) && (fromDate != null || fromDate != undefined)) {
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
      }

      // Compare To date and from date
      if (new Date(this.logSearchForm.controls['toDate'].value) < new Date(this.logSearchForm.controls['fromDate'].value)) {
        this.error = { isError: true, errorMessage: 'To Date can not before start date' };
        return;
      }
      else {
        this.error = { isError: false, errorMessage: '' };
      }

      fromDateYYYYMMDD = this.datePipe.transform(fromDate, 'yyyy-MM-dd');
      toDateYYYYDDMM = this.datePipe.transform(toDate, 'yyyy-MM-dd');

      if ((this.itemDisabled != true) && (buId != -1) && (buId != null)) {
        buList.push(buId);
      }

      const inputRequestObj = {
        'searchType': searchType,
        'buList': buList,
        'contextId': contextId,
        'transactionId': transactionId,
        'fromDate': fromDateYYYYMMDD,
        'toDate': toDateYYYYDDMM,
        'uIComponentID': 'LOG_SEARCH'
      };

      this.getLogSearchGridData(inputRequestObj);
    }

  }

  /**
   * Display data in grid
   * param: inputReqObj
   */
  private getLogSearchGridData(inputRequestObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    this.logSearchService.getLogSearchGridComponent(inputRequestObj)
      .pipe(
        tap(logSearchGridData => {
          this.girdData = logSearchGridData.data;
        }))
      .subscribe(logSearchGridData => {
        if (((logSearchGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((logSearchGridData.metadata.uIComponentID === 'LOG_SEARCH'))) {

          if (logSearchGridData.data.length > 0) {
            this.logSearchGridData = this.logSearchService.pipe(map(data => process(logSearchGridData.data, this.gridState)));
          } else {
            this.logSearchGridData = this.logSearchService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((logSearchGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.logSearchGridData = this.logSearchService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = logSearchGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });

  }


  /**
   * Load the select BU dropdown component
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.logSearchService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

  /**
   * Load the select Format dropdown component
   */
  private loadSearchTypeElementDropDown() {
    this.searchDropdown_loading_indicator = true;
    const selectSearchTypeRequestObj = '{ "searchCriteria1": [{ "key": "uiComponentID", "value": "ADMIN_CONFIG_SEARCHBYID", "datatype": "string"},{ "key": "categoryName", "value": "LogSearch", "datatype": "string"}, { "key": "subCategoryName", "value":' + this.currentUnitName + ', "datatype": "string"}, { "key": "active", "value": "Active", "datatype": "string"}]}';
    this.logSearchService.getSelectSearchTypeDropDownValues(selectSearchTypeRequestObj).subscribe(crudConfigGridData => {
      crudConfigGridData.response.filter(dataResponse => {
        if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_CONFIG_SEARCHBYID'))) {
          dataResponse.data.forEach(selectSearchTypeElement => {
            this.selectSearchTypeItems.push(selectSearchTypeElement);
          });
        }
        this.searchDropdown_loading_indicator = false;
      });
    });
    error => console.log(error);

  }

  /**
  *  Enabling and disbaling BU dropdown
  */
  public searchTypeValueChanged(event) {
    if (event.key === 'MQErrorQueue') {
      this.itemDisabled = true;
    } else {
      if (event.key != 'placeholder') {
        this.itemDisabled = false;
      }
    }
  }

  /**
   * SEARCH COMPONENT RESET VALIDATION FORM
   *
   */
  public resetMe() {
    this.logSearchForm.reset();
    this.isGridLoadingIndicator = false;
    this.logSearchGridData = this.logSearchService.pipe(map(data => process([], this.gridState)));
    this.errormsg1 = '';
    this.errormsg2 = '';
  }



  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.logSearchService.unsubscribe();
  }

}
