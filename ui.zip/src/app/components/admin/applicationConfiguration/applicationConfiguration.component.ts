import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  OnDestroy,
  Inject,
  ChangeDetectorRef,
  EventEmitter,
  Output,
  ViewChild,
} from '@angular/core';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {CrudConfigAddAndUpdateRequestModel} from '../../../models/crudConfig/crudConfigAddAndUpdateRequestModel';
import {ApplicationConfigurationService} from '../../../services/applicationConfiguration.service';
import {map} from 'rxjs/operators/map';
import {tap} from 'rxjs/operators/tap';
import {CrudSearchComponentModel} from '../../../models/crudConfig/crudSeachComponentModel';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {FailureMsgPopupComponent} from '../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../services/sessionTimeout.service';
import {BehaviorSubject} from '../../../../../node_modules/rxjs/BehaviorSubject';


const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';
const REMOVE_ACTION = 'DELETE';

@Component({
  selector: 'curd-screen',
  templateUrl: './applicationConfiguration.component.html'
})

export class ApplicationConfigurationComponent extends BehaviorSubject<any[]> implements OnInit, OnDestroy {

  public view: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  crudSearchComponentsObj = new CrudSearchComponentModel();
  active = true;
  crudForm: FormGroup;
  public editDataItem: CrudConfigAddAndUpdateRequestModel;
  public isNew: boolean;
  private cRUDConfigService: ApplicationConfigurationService;
  private girdData: any[] = [];
  public opened: Boolean = false;
  public selectedRowData : any;
  public itemDisabled: Boolean = true;

  // Add and edit popup drop-down
  public categoryItems_popup: Array<CategoryDropdownModel> = [];
  public subCategoryItems_popup: Array<SubCategoryDropdownModel> = [];
  public category_selectedValue_popup: CategoryDropdownModel;
  public subCategory_selectedValue_popup: SubCategoryDropdownModel;
  public activeFlag: String = 'checked';

  // Search component drop-down
  public categoryItems: Array<CategoryDropdownModel> = [{categoryName: 'All Category', categoryID: 0}];
  public category_model: CategoryDropdownModel = {categoryName :'All Category' , categoryID:0};
  public category_default_placeHolder: CategoryDropdownModel = {categoryName :'Select Category' , categoryID:-1};

  public subCategory_defaultText: SubCategoryDropdownModel = {'subCategoryName': 'Select SubCategory', 'subCategoryID':-1};
  public subCategoryItems: Array<SubCategoryDropdownModel> = [];

  //Loading Indicator
  public category_loading_indicator: Boolean = false;
  public subCategory_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ApplicationConfigurationService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeout: SessionTimeoutService) {
    super([]);
    this.cRUDConfigService = editServiceFactory();
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public ngOnInit(): void {
    this.loadCategoryAndSubCategoryDropDown();
    this.buildForm();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    //this.onSearch();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.view = this.cRUDConfigService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public addHandler() {
    this.editDataItem = new CrudConfigAddAndUpdateRequestModel();
    this.isNew = true;
    this.editDataItem.active = 'true';
    // Reset the selected dropdown values => Add/Edit
    this.category_selectedValue_popup = undefined;
    this.subCategory_selectedValue_popup = undefined;
  }

  public editHandler({dataItem}) {
    // Converting active field values=> Active = true & Inactive = false
    if (dataItem.active.toUpperCase() === 'ACTIVE') {
      this.activeFlag = 'checked';
    } else {
      this.activeFlag = null;
    }

    this.editDataItem = dataItem;
    this.isNew = false;
    this.category_selectedValue_popup = {categoryName: dataItem.categoryName, categoryID: dataItem.categoryID};
    this.subCategory_selectedValue_popup = {subCategoryName: dataItem.subCategoryName, subCategoryID: dataItem.subCategoryID};
  }

  public saveHandler(crudConfigGridModel: CrudConfigAddAndUpdateRequestModel) {
    const action = this.isNew ? CREATE_ACTION : UPDATE_ACTION;
    // If add config, sending config ID as 0
    if (action === CREATE_ACTION) {
      crudConfigGridModel.configId = 0;
    }
    // Converting active field values=> true = Active & false = Inactive
    if ((crudConfigGridModel.active !== null) && (crudConfigGridModel.active.toString() === 'true') || (crudConfigGridModel.active === 'Active')) {
      crudConfigGridModel.active = 'Active';
      this.editDataItem.active = 'Active';
    } else {
      crudConfigGridModel.active = 'Inactive';
      this.editDataItem.active = 'Inactive';
    }

     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    this.cRUDConfigService.insertAndUpdateAndUpdateCRUDConfigData(crudConfigGridModel, action).subscribe(crudConfigGridResponse => {
      const uIComponentID = crudConfigGridResponse.metadata.uIComponentID.toUpperCase();
      const responseStatus = crudConfigGridResponse.metadata.status.toUpperCase();

      if ((responseStatus === 'SUCCESS') && ((uIComponentID === 'ADMIN_CONFIG_CRUD_CREATE') || (uIComponentID === 'ADMIN_CONFIG_CRUD_UPDATE'))) {
        this.onSearch();
      } else if (responseStatus === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = crudConfigGridResponse.metadata.errorMsg[0].errorDesc;
      }

      this._sessionTimeout.filter('Session timeout Reset called');
    });
    this.editDataItem = undefined;
  }

  public removeHandler({dataItem}) {
    this.opened = true;
    this.selectedRowData = dataItem;
  }

  public onSearch() {
    if (this.crudForm.valid) {
      this.crudSearchComponentsObj = this.crudForm.value;

      // Invoking the services call to get the grid data values
      let inputRequestObj,
        searchType;
      const selectedCategoryValue = this.crudForm.controls.categoryName.value.categoryName.toUpperCase();

      if (selectedCategoryValue === 'ALL CATEGORY') {
        inputRequestObj = {
          'searchCriteria1': [
            {
              'key': 'search',
              'value': 'all',
              'datatype': 'string'
            },
            {
              'key': 'uiComponentID',
              'value': 'ADMIN_CONFIG_SEARCHALL',
              'datatype': 'string'
            }]
        };
        searchType = 'SEARCH_ALL';
      } else {
        let subCategoryValue;
        const categoryValue = this.crudForm.controls.categoryName.value.categoryName,
          key = this.crudForm.controls.key1.value,
          value = this.crudForm.controls.value1.value,
          active = this.crudForm.controls.active.value;

        if (this.crudForm.controls.subCategoryName.value != null) {
          subCategoryValue = this.crudForm.controls.subCategoryName.value.subCategoryName;
        }

        inputRequestObj = {
          'searchCriteria1': [
            {
              'key': 'uiComponentID',
              'value': 'ADMIN_CONFIG_SEARCHBYID',
              'datatype': 'string'
            }
          ]
        };

        if (categoryValue !== null && categoryValue !== undefined && categoryValue !== '') {
          const category = {
            'key': 'categoryName',
            'value': categoryValue,
            'datatype': 'string'
          };
          inputRequestObj.searchCriteria1.push(category);
        }

        if (subCategoryValue !== null && subCategoryValue !== undefined && subCategoryValue !== '' && subCategoryValue!='Select SubCategory') {
          const subCategory = {
            'key': 'subCategoryName',
            'value': subCategoryValue,
            'datatype': 'string'
          };
          inputRequestObj.searchCriteria1.push(subCategory);
        }

        if (key !== null && key !== undefined && key !== '') {
          const keys = {
            'key': 'key',
            'value': key,
            'datatype': 'string'
          };
          inputRequestObj.searchCriteria1.push(keys);
        }

        if (value !== null && value !== undefined && value !== '') {
          const values = {
            'key': 'value',
            'value': value,
            'datatype': 'string'
          };
          inputRequestObj.searchCriteria1.push(values);
        }

        if (active !== null && active !== undefined) {
          let activeValue = '';
          if (active) {
            activeValue = 'Active';
          } else {
            activeValue = 'Inactive';
          }

          const activeCheckBox = {
            'key': 'active',
            'value': activeValue,
            'datatype': 'string'
          };
          inputRequestObj.searchCriteria1.push(activeCheckBox);
        }

        searchType = selectedCategoryValue;
      }

      this.getApplicationConfigGridData(inputRequestObj, searchType);
    }
  }

  getApplicationConfigGridData(inputRequestObj, searchType) {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    this.cRUDConfigService.getCrudGridComponentValues(inputRequestObj, searchType).pipe(
      tap(crudConfigGridData => {
        crudConfigGridData.response.filter(dataResponse => {
          this.girdData = dataResponse.data;
        });
      })).subscribe(crudConfigGridData => {
      crudConfigGridData.response.filter(dataResponse => {

        const uIComponentID = dataResponse.metadata.uIComponentID.toUpperCase();
        const responseStatus = dataResponse.metadata.status.toUpperCase();

        if ((responseStatus === 'SUCCESS') && ((uIComponentID === 'ADMIN_CONFIG_SEARCHBYID') || (uIComponentID === 'ADMIN_CONFIG_SEARCHALL'))) {
          if (dataResponse.data.length > 0) {
            this.view = this.cRUDConfigService.pipe(map(data => process(dataResponse.data, this.gridState)));
            this.refresh();
          } else {
            this.view = this.cRUDConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if (responseStatus === 'ERROR') {
          this.view = this.cRUDConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = dataResponse.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeout.filter('Session timeout Reset called');
      });
    });
  }

  /**
   * Pre populating the Category and Sub Category dropdown values from the REST services
   */
  private loadCategoryAndSubCategoryDropDown() {
    this.category_loading_indicator = true;
    this.subCategory_loading_indicator = true;

    // Preparing input request for the category and sub category drop-down services
    const searchComponentRequestObj = {
      'searchCriteria1': [
        {'key': 'categoryType', 'value': 'TOS', 'datatype': 'string'},
        {'key': 'uiComponentID', 'value': 'ADMIN_CONFIG_CATEGORY', 'datatype': 'string'}
      ],
      'searchCriteria2': [
        {'key': 'subCategoryType', 'value': 'TOS', 'datatype': 'string'},
        {'key': 'uiComponentID', 'value': 'ADMIN_CONFIG_SUBCATEGORY', 'datatype': 'string'}
      ]
    };

    this.cRUDConfigService.getCRUDSearchDropDownValues(searchComponentRequestObj).subscribe(searchComponentResponse => {
        searchComponentResponse.response.filter(JSONResponse => {
          if (((JSONResponse.metadata.status).toUpperCase() === 'SUCCESS') && (JSONResponse.metadata.uIComponentID === 'ADMIN_CONFIG_CATEGORY')) {
            JSONResponse.data.forEach(categoryElement => {
              // search component category dropdown
              this.categoryItems.push(categoryElement);

              // Add/Edit popup category dropdown
              this.categoryItems_popup.push(categoryElement);
            });
          } else if (((JSONResponse.metadata.status).toUpperCase() === 'SUCCESS') && (JSONResponse.metadata.uIComponentID === 'ADMIN_CONFIG_SUBCATEGORY')) {
            JSONResponse.data.forEach(subCategoryElement => {
              // search component SubCategory dropdown
              this.subCategoryItems.push(subCategoryElement);

              // Add/Edit popup category dropdown
              this.subCategoryItems_popup.push(subCategoryElement);
            });
          }
          this.category_loading_indicator = false;
          this.subCategory_loading_indicator = false;
        });
      },
      error => console.log(error)
    );
  }

   /**
   *  After selecting All Category, disable optional fields
   */
  public isAllCategorySelected(event) {
    if (this.crudForm.value.categoryName.categoryID== 0) {
      this.crudForm.controls["subCategoryName"].reset();
      this.crudForm.controls["key1"].reset();
      this.crudForm.controls["value1"].reset();
      this.itemDisabled = true;
    } else {
      this.itemDisabled = false;
    }
  }

  /**
   * Close delete confirmation popup and delete slected row
   * @param fb
   */
  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === 'YES') {
      this.cRUDConfigService.insertAndUpdateAndUpdateCRUDConfigData(this.selectedRowData, REMOVE_ACTION).subscribe(crudConfigGridData => {

        const uIComponentID = crudConfigGridData.metadata.uIComponentID.toUpperCase();
        const responseStatus = crudConfigGridData.metadata.status.toUpperCase();
  
        if ((responseStatus === 'SUCCESS') && ((uIComponentID === 'ADMIN_CONFIG_CRUD_DELETE'))) {
          this.onSearch();
        } else if (responseStatus === 'ERROR') {
          this.failureMsgPopup.open();
          this.errorMessage = crudConfigGridData.metadata.errorMsg[0].errorDesc;
          this._sessionTimeout.filter('Session timeout Reset called');
        }
      });
    }
  }
  /**
   * search component reset validation form
   * @param fb
   */
  public resetMe(fb) {
    this.crudForm.reset();
    this.isGridLoadingIndicator = false;
    this.itemDisabled = true;
    this.category_model = {categoryName :'All Category' , categoryID:0};
    this.view = this.cRUDConfigService.pipe(map(data => process([], this.gridState)));
  }

  /**
   * Initializing the search component
   */
  buildForm(): void {
    this.crudForm = this.formBuilder.group({
      'categoryName': [this.crudSearchComponentsObj.categoryName, [Validators.required]],
      'subCategoryName': [this.crudSearchComponentsObj.subCategoryName],
      'key1': [this.crudSearchComponentsObj.key1],
      'value1': [this.crudSearchComponentsObj.value1],
      'active': [this.crudSearchComponentsObj.active]
    });

    this.crudForm.valueChanges.subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set validation messages now
  }

  onValueChanged(data?: any) {
    if (!this.crudForm) {
      return;
    }
    const form = this.crudForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'categoryName': '',
  };

  validationMessages = {
    'categoryName': {
      'required': 'Please select the category.'
    }
  };

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.cRUDConfigService.unsubscribe();
  }
}

