import {Component, Input, Output, EventEmitter} from '@angular/core';
import {Validators, FormGroup, FormControl} from '@angular/forms';
import {CrudConfigAddAndUpdateRequestModel} from '../../../models/crudConfig/crudConfigAddAndUpdateRequestModel';

@Component({
  selector: 'crudConfig-grid-edit-form',
  styles: ['input[type=text] { width: 100%; }'],
  templateUrl: './applicationConfigurationPopup.component.html'
})

export class ApplicationConfigurationPopupComponent {
  public active = false;
  public editForm: FormGroup = new FormGroup({
    'configId': new FormControl(),
    'category': new FormControl('', Validators.required),
    'subCategory': new FormControl('', Validators.required),
    'key': new FormControl('', Validators.required),
    'value': new FormControl('', Validators.required),
    'active': new FormControl(false)
  });

  // Get the values from the parent component
  @Input() public categoryItems_popup: Array<CategoryDropdownModel> = [];
  @Input() public subCategoryItems_popup: Array<SubCategoryDropdownModel> = [];

  // Get the selected dropdown values from the parent component
  @Input() public category_selectedValue_popup: CategoryDropdownModel;
  @Input() public subCategory_selectedValue_popup: SubCategoryDropdownModel;

  // Default Dropdown value
  public category_defaultText: CategoryDropdownModel = {'categoryName':'Select Category' , 'categoryID':-1};
  public subCategory_defaultText: SubCategoryDropdownModel = {'subCategoryName': 'Select SubCategory', 'subCategoryID':-1};

  @Input() public activeFlag;

  @Input() public isNew = false;

  @Input()
  public set model(crudConfigGridModel: CrudConfigAddAndUpdateRequestModel) {
    this.editForm.reset(crudConfigGridModel);
    this.active = crudConfigGridModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<CrudConfigAddAndUpdateRequestModel> = new EventEmitter();

  constructor() {
    console.log('category' + this.editForm.controls.category);
  }

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.editForm.value);
    this.active = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

}
