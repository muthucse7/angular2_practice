import {Component, EventEmitter, Input, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ManageBUUserRoleModel} from '../../../../models/manageBusinessUnits/manageUserRole/manageBUUserRoleModel';

@Component({
  selector: 'manage-add-user-role',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()">
      <kendo-dialog-titlebar>
        Assign BU User Role
      </kendo-dialog-titlebar>
      <form [formGroup]="addManageUserRoleForm" *ngIf="active" (ngSubmit)="onSave()" #formDirBU="ngForm" class="font13" novalidate>
        <div class="col-md-12">
          <div class="form-group">
            <label class="k-form-field">
              <span>Select User<span class="k-required">*</span></span>
            </label>
            <kendo-dropdownlist
              [data]="selectUserItems"
              [defaultItem]="userDefaultText"
              (valueChange)="selectUserChangeDropDownPopUp($event)"
              textField="userName"
              valueField="userId"
              formControlName="userName"
              id="userName" class="width100per input_text_standard" required>
            </kendo-dropdownlist>

            <!-- Select User dropdown validation-->
            <div class="k-tooltip k-tooltip-validation marginTop0px font12 font_weight_bold crudPopup_error" [hidden]="addManageUserRoleForm.controls.userName.valid || addManageUserRoleForm.controls.userName.pristine">
              <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert" /></span>
              User is required
            </div>

          </div>
          <div class="form-group">
            <label class="k-form-field">
              <span>Select BU<span class="k-required">*</span></span>
            </label>
            <kendo-dropdownlist
              [data]="popupSelectBUItems"
              [defaultItem]="buDefaultText"
              (valueChange)="selectBUChangeDropDownPopUp($event)"
              textField="buName"
              valueField="buId"
              formControlName="buName"
              id="buName" class="width100per input_text_standard" required>
            </kendo-dropdownlist>

            <!-- Select BU dropdown validation-->
            <div class="k-tooltip k-tooltip-validation marginTop0px font12 font_weight_bold crudPopup_error" [hidden]="addManageUserRoleForm.controls.buName.valid || addManageUserRoleForm.controls.buName.pristine">
              <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert" /></span>
              BU is required
            </div>

          </div>
          <div class="form-group">
            <label class="k-form-field">
              <span>Select Role<span class="k-required">*</span></span>
            </label>
            <kendo-dropdownlist
              [data]="selectRoleItems"
              [defaultItem]="roleDefaultText"
              (valueChange)="selectRoleChangeDropDownPopUp($event)"
              textField="buRoleName"
              valueField="buRoleId"
              formControlName="buRoleName"
              id="buRoleName" class="width100per input_text_standard" required>
            </kendo-dropdownlist>

            <!-- Select Role dropdown validation-->
            <div class="k-tooltip k-tooltip-validation marginTop0px font12 font_weight_bold crudPopup_error" [hidden]="addManageUserRoleForm.controls.buRoleName.valid || addManageUserRoleForm.controls.buRoleName.pristine">
              <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert" /></span>
              Role is required
            </div>

          </div>
        </div>
      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" (click)="onSave($event)" [disabled]="!addManageUserRoleForm.valid">
          Save
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>

    </kendo-dialog>
  `
})

export class AddManageUserRoleComponent {

  public active = false;

  public buDefaultText: SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};
  public userDefaultText: SelectUserRoleDropdownModel = {'userName': 'Select User Name', 'userId': 0};
  public roleDefaultText: SelectRoleDropdownModel = {'buRoleName': 'Select BU Role', 'buRoleId': 0};

  @Input()
  public selectRoleItems: Array<SelectRoleDropdownModel> = [];

  @Input()
  public selectUserItems: Array<SelectUserRoleDropdownModel> = [];

  @Input()
  public popupSelectBUItems: Array<SelectBUDropdownModel> = [];

  @Input()
  public set model(buUserRoleModelRequestModel: ManageBUUserRoleModel) {
    this.addManageUserRoleForm.reset(buUserRoleModelRequestModel);
    this.active = buUserRoleModelRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ManageBUUserRoleModel> = new EventEmitter();
  @Output() popupChangeBUDropDown: EventEmitter<SelectBUDropdownModel> = new EventEmitter();

  public addManageUserRoleForm: FormGroup = new FormGroup({
    'userName': new FormControl(Validators.required),
    'buName': new FormControl(Validators.required),
    'buRoleName': new FormControl(Validators.required)
  });

  public onSave(e): void {
    this.save.emit(this.addManageUserRoleForm.value);
    this.active = false;
    e.preventDefault();
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  public selectUserChangeDropDownPopUp(value): void {
    if (value.userId == 0) {
      this.addManageUserRoleForm.controls['userName'].setErrors({'incorrect': true}); 
    }
  }

  public selectBUChangeDropDownPopUp(value): void {

    if (value.buId != 0) {
      this.popupChangeBUDropDown.emit(this.addManageUserRoleForm.value);
    } else {
      this.addManageUserRoleForm.controls['buName'].setErrors({'incorrect': true}); 
    }
    
  }

  public selectRoleChangeDropDownPopUp(value): void {
    if (value.buRoleId == 0) {
      this.addManageUserRoleForm.controls['buRoleName'].setErrors({'incorrect': true}); 
    }
  }

}
