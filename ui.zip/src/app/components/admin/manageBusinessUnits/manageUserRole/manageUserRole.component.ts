import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  OnDestroy,
  Inject,
  EventEmitter,
  Output,
  ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import {GridDataResult, PageChangeEvent} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {FormGroup, FormBuilder, FormControl} from '@angular/forms';
import {map} from 'rxjs/operators/map';
import {ManageBUUserRoleModel} from '../../../../models/manageBusinessUnits/manageUserRole/manageBUUserRoleModel';
import {ManageUserRoleService} from '../../../../services/manageUserRole.service';
import {tap} from 'rxjs/operators/tap';
import {FailureMsgPopupComponent} from '../../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../../services/sessionTimeout.service';


const CREATE_ACTION = 'CREATE';
const REMOVE_ACTION = 'DELETE';

@Component({
  selector: 'manageFunction',
  templateUrl: './manageUserRole.component.html'
})

export class ManageUserRoleComponent implements OnInit, OnDestroy {

  public title = 'Manage BU User Roles';
  public selectUserItems: Array<SelectUserRoleDropdownModel> = [];
  public selectRoleItems: Array<SelectRoleDropdownModel> = [];
  public popupSelectBUItems: Array<SelectBUDropdownModel> = [];

  public selectBU_selectedValue: SelectBUDropdownModel;
  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public defaultBuItems : SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};

  private girdData: any[] = [];
  public buUserRoleMapping: Observable<GridDataResult>;
  public buRoleForm: FormGroup;
  public buUserRoleModelRequestModel: ManageBUUserRoleModel;
  private manageUserRoleService: ManageUserRoleService;
  private userNetworkId;
  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  public opened: Boolean = false;
  public selectedRowData : any;


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();


  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10
  };

  constructor(@Inject(ManageUserRoleService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.manageUserRoleService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.loadSelectBUDropDown();
    this.initializePopupForm();
  }

  private initializePopupForm() {
    this.buRoleForm = new FormGroup({
      'userName': new FormControl(''),
      'buName': new FormControl(''),
      'buRoleName': new FormControl('')
    });
  }

  public onStateChange(state: State) {
    this.gridState = state;
   /* if (this.selectBU_selectedValue.buId !== 0) {
      this.loadManageUserRoleGridComponent(this.selectBU_selectedValue.buId);
    }*/
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.buUserRoleMapping = this.manageUserRoleService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // method to add new BU request in pop up
  public addHandler() {
    this.buUserRoleModelRequestModel = new ManageBUUserRoleModel();
  }

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  public removeHandler({dataItem}) {
    this.opened = true;
    this.selectedRowData = dataItem;
  }

  /**
   * Close delete confirmation popup and remove slected row
   * @param fb
   */
  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === 'YES') {
      const inputRequestObj = {'buUserRoleId': this.selectedRowData.buUserRoleMappingId};
      this.createAndDeleteBUFunctionGridData(inputRequestObj, REMOVE_ACTION);
    }
  }

  public saveHandler(model: ManageBUUserRoleModel) {
    const inputRequestObj = {
      'buUserRoleId': model.buName['buId'],
      'buRoleId': model.buRoleName['buRoleId'],
      'buUserId': model.userName['userId'],
    };
    this.createAndDeleteBUFunctionGridData(inputRequestObj, CREATE_ACTION);
  }

  public cancelHandler() {
    this.buUserRoleModelRequestModel = undefined;
  }

  public stateChangeBUDropDown() {
    // Since 0 is default value from UI
    if (this.selectBU_selectedValue.buId !== 0) {
      this.loadManageUserRoleGridComponent(this.selectBU_selectedValue.buId);
    }
  }

  /**
   * Triggering popup BU Dropdown values
   * @param {SelectBUDropdownModel} model
   */
  public popupChangeBUDropDown(model: SelectBUDropdownModel) {
    this.getRolesBasedOnSelectedBU(model.buName['buId']);
  }

  /**
   * Load the manageBUFunction grid data
   */
  private loadManageUserRoleGridComponent(buId) {
  this.isGridLoadingIndicator = true;
    // Preparing input request
    const inputRequestObj = {
      'DASHBOARD_SELECT_USER_ALL_DROPDOWN': [
        {
          'key': 'uiComponentID',
          'value': 'DASHBOARD_SELECT_USER_ALL_DROPDOWN',
          'datatype': 'string'
        }
      ],
      'DASHBOARD_SELECT_BU_DROPDOWN': [
        {
          'key': 'uiComponentID',
          'value': 'DASHBOARD_SELECT_BU_DROPDOWN',
          'datatype': 'string'
        }
      ],
      'DASHBOARD_SELECT_ROLE_DROPDOWN': [
        {
          'key': 'buId',
          'value': buId,
          'datatype': 'int'
        },
        {
          'key': 'uiComponentID',
          'value': 'DASHBOARD_SELECT_ROLE_DROPDOWN',
          'datatype': 'string'
        }
      ],
      'DASHBOARD_USER_ROLE_GRID': [
        {
          'key': 'buId',
          'value': buId,
          'datatype': 'int'
        },
        {
          'key': 'uiComponentID',
          'value': 'DASHBOARD_USER_ROLE_GRID',
          'datatype': 'string'
        }
      ]
    };
    // Reset the paging
    this.gridState = {sort: [], skip: 0, take: 10};

    this.manageUserRoleService.getManageUserRoleGridComponent(inputRequestObj).subscribe(manageBUFunctionGridData => {
        manageBUFunctionGridData.response.filter(dataResponse => {
          if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'DASHBOARD_USER_ROLE_GRID'))) {
            if (dataResponse.data.length > 0) {
              this.girdData = dataResponse.data;
              this.buUserRoleMapping = this.manageUserRoleService.pipe(map(data => process(dataResponse.data, this.gridState)));
            } else {
              this.buUserRoleMapping = this.manageUserRoleService.pipe(map(data => process([], this.gridState)));
              this.failureMsgPopup.open();
              this.errorMessage = 'Sorry! There are no data available for this search criteria.';
            }

          } else if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_SELECT_USER_ALL_DROPDOWN')) {
            this.selectUserItems = [];
            dataResponse.data.forEach(userElement => {
              this.selectUserItems.push({
                'userName': userElement.userName,
                'userId': userElement.userId
              });
            });
          } else if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_SELECT_ROLE_DROPDOWN')) {
            this.selectRoleItems = [];
            dataResponse.data.forEach(roleElement => {
              this.selectRoleItems.push({
                'buRoleName': roleElement.buRoleName,
                'buRoleId': roleElement.buRoleId
              });
            });
          } else if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_SELECT_BU_DROPDOWN')) {
            this.popupSelectBUItems = [];
            dataResponse.data.forEach(buElement => {
              this.popupSelectBUItems.push({
                'buName': buElement.buName,
                'buId': buElement.buId
              });
            });
          } else if ((dataResponse.metadata.status).toUpperCase() === 'ERROR') {
            this.failureMsgPopup.open();
            this.errorMessage = dataResponse.metadata.errorMsg[0].errorDesc;
          }
          this.isGridLoadingIndicator = false;
          this._sessionTimeoutService.filter('Session timeout Reset called');
        });
      });
  }

  private getRolesBasedOnSelectedBU(buId) {
    const inputRequestObj = {
      'DASHBOARD_SELECT_ROLE_DROPDOWN': [
        {
          'key': 'buId',
          'value': buId,
          'datatype': 'int'
        },
        {
          'key': 'uiComponentID',
          'value': 'DASHBOARD_SELECT_ROLE_DROPDOWN',
          'datatype': 'string'
        }
      ]
    };

    this.manageUserRoleService.getManageUserRoleGridComponent(inputRequestObj).subscribe(manageBUFunctionGridData => {
      manageBUFunctionGridData.response.filter(dataResponse => {
        if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_SELECT_ROLE_DROPDOWN')) {
          this.selectRoleItems = [];
          dataResponse.data.forEach(roleElement => {
            this.selectRoleItems.push({
              'buRoleName': roleElement.buRoleName,
              'buRoleId': roleElement.buRoleId
            });
          });
          this._sessionTimeoutService.filter('Session timeout Reset called');
        }
      });
    });
  }

  /**
   * Add and Delete the data from Function grid component
   * @param dataItem
   * @param ACTION
   */
  private createAndDeleteBUFunctionGridData(dataItem, ACTION) {
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
    this.manageUserRoleService.createAndDeleteBURoleGridData(dataItem, ACTION).subscribe(manageBUFunctionGridData => {
      if (((manageBUFunctionGridData.metadata.status).toUpperCase() === 'SUCCESS')) {
        this.loadManageUserRoleGridComponent(this.selectBU_selectedValue.buId);
      } else if ((manageBUFunctionGridData.metadata.status).toUpperCase() === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = manageBUFunctionGridData.metadata.errorMsg[0].errorDesc;
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }

  /**
   * Load the select BU dropdown component
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = {'uIComponentID': 'AUTHORIZATION_BU'};
    this.manageUserRoleService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
        if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
         /* this.selectBU_selectedValue = selectBUDropDownResponse.data[0];
          this.loadManageUserRoleGridComponent(this.selectBU_selectedValue.buId);*/
          selectBUDropDownResponse.data.forEach(selectBUElement => {
            this.selectBUItems.push(selectBUElement);
          });
        }
        this.buDropdown_loading_indicator = false;
      },
      error => console.log(error)
    );
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.manageUserRoleService.unsubscribe();
  }
}
