import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  OnDestroy,
  ComponentFactoryResolver,
  ChangeDetectorRef,
  ViewChild,
  Output,
  EventEmitter
} from '@angular/core';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {ManageUserModel} from '../../../../models/manageBusinessUnits/manageUser/manageUserModel';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {ManageUserService} from '../../../../services/manageUser.service';
import {ManageUserSearchComponentModel} from '../../../../models/manageBusinessUnits/manageUser/manageUserSearchComponentModel';
import {ManageUserCreateAndUpdateRequestModel} from '../../../../models/manageBusinessUnits/manageUser/manageUserCreateAndUpdateRequestModel';
import {map} from 'rxjs/operators/map';
import {tap} from 'rxjs/operators/tap';
import {FailureMsgPopupComponent} from '../../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../../services/sessionTimeout.service';


const CREATE_ACTION = 'Create';
const UPDATE_ACTION = 'Update';
const REMOVE_ACTION = 'Delete';


@Component({
  selector: 'manageBUUser',
  templateUrl: './manageUser.component.html'
})
export class ManageUserComponent implements OnInit, OnDestroy {

  manageUserSearchForm: FormGroup;
  active = true;
  manageUserSearchComponentsObj = new ManageUserSearchComponentModel();
  public editDataItem: ManageUserModel;
  private manageUserService: ManageUserService;
  private girdData: any[] = [];
  public isNew: boolean;
  public userNetworkId;
  public activeFlag: String = 'checked';

  public title = 'Manage BU Users';
  public manageUserGridModel: ManageUserModel;
  public manageUserEditItem: ManageUserCreateAndUpdateRequestModel;
  public manageUserMapping: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  public addManageUserForm: FormGroup;
  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public selectBU_selectedValue: SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};
  public defaultItem: SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};

  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  public opened: Boolean = false;
  public selectedRowData : any;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ManageUserService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private componentFactoryResolver: ComponentFactoryResolver, private _sessionTimeoutService: SessionTimeoutService) {
    this.manageUserService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.addManageUserForm = new FormGroup({
      'firstName': new FormControl(''),
      'lastName': new FormControl(''),
      'networkId': new FormControl(''),
      'email': new FormControl(''),
      'active': new FormControl('')
    });

    this.manageUserSearchForm = this.formBuilder.group({
      'selectBU': [this.manageUserSearchComponentsObj.selectBU],
      'firstName': [this.manageUserSearchComponentsObj.firstName],
      'lastName': [this.manageUserSearchComponentsObj.lastName]
    });

    this.loadSelectBUDropDown();

  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    //this.onSearchManageUser();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.manageUserMapping = this.manageUserService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // TO ADD NEW BU USER
  public addHandler() {
    this.manageUserEditItem = new ManageUserCreateAndUpdateRequestModel();
    this.manageUserEditItem.active = 'true';
    this.isNew = true;
  }

  // TO EDIT EXISTING BU USER
  public editHandler({dataItem}) {
    // Converting active field values=> Active = true & Inactive = false
    if (dataItem.active.toUpperCase() === 'ACTIVE') {
      this.activeFlag = 'checked';
    } else {
      this.activeFlag = null;
    }

    this.isNew = false;
    this.manageUserEditItem = dataItem;
    console.log(this.manageUserEditItem.userId);
    this.manageUserEditItem.uIComponentID = 'DASHBOARD_USER_UPDATE';
  }

  // To SAVE / UPDATE BU USER DATA
  public saveHandler(manageUserActionItem: ManageUserCreateAndUpdateRequestModel) {
    const action = this.isNew ? CREATE_ACTION : UPDATE_ACTION;
    if (action === CREATE_ACTION) {
      manageUserActionItem.userId = 0;
      manageUserActionItem.uIComponentID = 'DASHBOARD_USER_CREATE';
    }
    if (action === UPDATE_ACTION) {
      console.log(this.manageUserEditItem.userId);

      manageUserActionItem.userId = this.manageUserEditItem.userId;
      manageUserActionItem.uIComponentID = 'DASHBOARD_USER_UPDATE';

    }
    // Converting active field values=> true = Active & false = Inactive
    if ((manageUserActionItem.active !== null) && (manageUserActionItem.active.toString() === 'true') || (manageUserActionItem.active === 'Active')) {
      manageUserActionItem.active = 'Active';
      this.manageUserEditItem.active = 'Active';
    } else {
      manageUserActionItem.active = 'Inactive';
      this.manageUserEditItem.active = 'Inactive';
    }

    this.createUpdateRemoveUser(manageUserActionItem, action);
    this.manageUserEditItem = undefined;
  }

  /**
   * CREATE, UPDATE & REMOVE USER
   * @param manageUserActionItem
   * @param ACTION
   */
  private createUpdateRemoveUser(manageUserActionItem, ACTION) {
    const selectedBUId = this.stateChangeBUDropDown();
    const firstName = this.manageUserSearchForm.value.firstName;
    const lastName = this.manageUserSearchForm.value.lastName;
    // Reset the paging
    this.gridState = {sort: [], skip: 0, take: 10};

    this.manageUserService.createUpdateRemoveUserGridData(manageUserActionItem, ACTION).subscribe(manageUserGridData => {
      if (((manageUserGridData.metadata.status).toUpperCase() === 'SUCCESS')) {
        if ((manageUserGridData.metadata.uIComponentID === 'DASHBOARD_USER_CREATE')) {
          this.manageUserMapping = this.manageUserService.pipe(map(data => process(manageUserGridData.data, this.gridState)));
        } else if ((manageUserGridData.metadata.uIComponentID === 'DASHBOARD_USER_UPDATE')) {
          if ((selectedBUId == 0) && (firstName == null) && (lastName == null)) {
            this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
          } else {
            this.onSearchManageUser();
          }
        }
      } else if ((manageUserGridData.metadata.status).toUpperCase() === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = manageUserGridData.metadata.errorMsg[0].errorDesc;
      } else if ((manageUserGridData.metadata.status).toUpperCase() === 'WARNING') {
        this.failureMsgPopup.open();
        this.errorMessage = manageUserGridData.metadata.errorMsg[0].errorDesc;
        if ((selectedBUId == 0) && (firstName == null) && (lastName == null)) {
          this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
        } else {
          this.onSearchManageUser();
        }
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }


  // TO REMOVE / DELETE BU USER DATA FROM DATABASE USING SERVICE CALL
  public removeHandler({dataItem}) {
    this.opened = true;
    this.selectedRowData = dataItem;

  }

  /**
   * Close delete confirmation popup and remove slected row
   * @param fb
   */
  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === 'YES') {
      const inputRequest = {'userId': this.selectedRowData.userId};
      const selectedBUId = this.stateChangeBUDropDown();
      const firstName = this.manageUserSearchForm.value.firstName;
      const lastName = this.manageUserSearchForm.value.lastName;

      this.manageUserService.createUpdateRemoveUserGridData(inputRequest, REMOVE_ACTION).subscribe(manageUserGridData => {
        if (((manageUserGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((manageUserGridData.metadata.uIComponentID === 'DASHBOARD_USER_DELETE'))) {
          if ((selectedBUId == 0) && (firstName == null) && (lastName == null)) {
            this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
          } else {
            this.onSearchManageUser();
          }
        } else if ((manageUserGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = manageUserGridData.metadata.errorMsg[0].errorDesc;
        } else if ((manageUserGridData.metadata.status).toUpperCase() === 'WARNING') {
          this.failureMsgPopup.open();
          this.errorMessage = manageUserGridData.metadata.errorMsg[0].errorDesc;
        }
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
    }
  }

  // CANCEL SAVE / UPDATE DATA
  public cancelHandler() {
    this.manageUserGridModel = undefined;
  }


  // TO GET BU ID OF DROPDOWN SELECTED VALUE
  public stateChangeBUDropDown() {
    if (this.selectBU_selectedValue != null) {
      return this.selectBU_selectedValue.buId;
    } else {
      return 0;
    }
  }

  /**
   * SHOW DATA IN GRID ON SEARCH CRITERIA
   */
  public onSearchManageUser() {
    let getBUId = this.stateChangeBUDropDown();
    if (this.manageUserSearchForm.valid) {
      this.manageUserSearchComponentsObj = this.manageUserSearchForm.value;
      let firstName = this.manageUserSearchComponentsObj.firstName;
      let lastName = this.manageUserSearchComponentsObj.lastName;

      if (firstName == null) {
        firstName = '';
      }
      if (lastName == null) {
        lastName = '';
      }

      // Invoking the services call to get the grid data values
      const inputSearchReqObj = {
        'buId': getBUId,
        'firstName': firstName,
        'lastName': lastName
      };
      this.getManageUserGridComponent(inputSearchReqObj);

    }
  }

  getManageUserGridComponent(inputSearchReqObj) {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
    this.manageUserService.getManageUserGridComponent(inputSearchReqObj)
      .pipe(
        tap(manageUserGridData => {
          this.girdData = manageUserGridData.data;
        }))
      .subscribe(manageUserGridData => {
        if (((manageUserGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((manageUserGridData.metadata.uIComponentID === 'DASHBOARD_USER_SEARCH'))) {
          if (manageUserGridData.data.length > 0) {
            this.manageUserMapping = this.manageUserService.pipe(map(data => process(manageUserGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }
        } else if ((manageUserGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = manageUserGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = {'uIComponentID': 'AUTHORIZATION_BU'};
    this.manageUserService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
        if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
          selectBUDropDownResponse.data.forEach(selectBUElement => {
            this.selectBUItems.push(selectBUElement);
          });
        }
        this.buDropdown_loading_indicator = false;
      },
      error => console.log(error)
    );
  }


  /**
   * SEARCH COMPONENT RESET VALIDATION FORM
   * @param fb
   */
  public resetMe(fb) {
    this.manageUserSearchForm.reset();
    this.isGridLoadingIndicator = false;
    this.defaultItem.buName = 'Please select BU';
    this.defaultItem.buId = 0;
    this.manageUserMapping = this.manageUserService.pipe(map(data => process([], this.gridState)));
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    //this.manageUserService.unsubscribe();
  }

}
