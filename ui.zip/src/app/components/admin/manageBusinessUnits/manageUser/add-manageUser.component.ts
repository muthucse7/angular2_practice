import {Component, EventEmitter, Input, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ManageUserModel} from '../../../../models/manageBusinessUnits/manageUser/manageUserModel';

@Component({
  selector: 'manage-add-edit-user',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13">
      <kendo-dialog-titlebar>
        {{ isNew ? 'Create BU User' : 'Edit BU User' }}
      </kendo-dialog-titlebar>

      <form [formGroup]="addManageUserForm" novalidate>
        <div class="form-group">
          <label for="firstName" class="control-label">First Name<span class="k-required">*</span></label>
          <input type="text" id="firstName" class="k-textbox input_text_standard" formControlName="firstName" placeholder="Enter First Name" required/>
          <!-- First Name dropdown validation-->
          <div class="k-tooltip k-tooltip-validation font12 font_weight_bold manageBUPopup_error"
               [hidden]="addManageUserForm.controls.firstName.valid || addManageUserForm.controls.firstName.pristine">
            <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert"/></span>First
            Name is required.
          </div>
        </div>

        <div class="form-group">
          <label for="lastName" class="control-label">Last Name<span class="k-required">*</span></label>
          <input type="text" id="lastName" class="k-textbox input_text_standard" formControlName="lastName" placeholder="Enter Last Name" required/>
          <!-- Last Name dropdown validation-->
          <div class="k-tooltip k-tooltip-validation font12 font_weight_bold manageBUPopup_error"
               [hidden]="addManageUserForm.controls.lastName.valid || addManageUserForm.controls.lastName.pristine">
            <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert"/></span>Last
            Name is required.
          </div>
        </div>

        <div class="form-group">
          <label for="networkId" class="control-label">Network ID<span class="k-required">*</span></label>
          <input type="text" id="networkId" class="k-textbox input_text_standard" formControlName="networkId" placeholder="Enter Network ID" required/>
          <!-- Network ID dropdown validation-->
          <div class="k-tooltip k-tooltip-validation font12 font_weight_bold manageBUPopup_error"
               [hidden]="addManageUserForm.controls.networkId.valid || addManageUserForm.controls.networkId.pristine">
            <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert"/></span>Network
            ID is required.
          </div>
        </div>

        <div class="form-group">
          <label for="email" class="control-label">Email ID<span class="k-required">*</span></label>
          <input type="text" id="email" class="k-textbox input_text_standard" formControlName="email" placeholder="Enter Email ID" required/>
          <!-- Email ID dropdown validation-->
          <div class="k-tooltip k-tooltip-validation font12 font_weight_bold manageBUPopup_error"
               [hidden]="addManageUserForm.controls.email.valid || addManageUserForm.controls.email.pristine">
            <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert"/></span>Email
            ID is required.
          </div>
        </div>

        <div class="form-group">
          <label>
            <input type="checkbox" formControlName="active" checked="{{activeFlag}}"/>
            Active
          </label>
        </div>
      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" [disabled]="!addManageUserForm.valid" (click)="onSave($event, (isNew ? 'SAVE' : 'UPDATE'))">
           {{ isNew ? 'Save' : 'Update' }}
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>
    </kendo-dialog>
  `
})

export class AddManageUserComponent {

  public active = false;
  emailPattern = '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-z]{2,4}$';
  @Input() public isNew = false;
  @Input() public activeFlag;

  @Input()
  public set model(manageUserModelRequestModel: ManageUserModel) {
    this.addManageUserForm.reset(manageUserModelRequestModel);
    this.active = manageUserModelRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ManageUserModel> = new EventEmitter();

  public addManageUserForm: FormGroup = new FormGroup({
    'firstName': new FormControl('', Validators.required),
    'lastName': new FormControl('', Validators.required),
    'networkId': new FormControl('', Validators.required),
    'email': new FormControl('', Validators.compose([Validators.required, Validators.pattern(this.emailPattern)])),
    'active': new FormControl(false)
  });

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.addManageUserForm.value);
    this.active = false;

  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }
}
