import {Component, EventEmitter, Input, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ManageBURoleModel} from '../../../../models/manageBusinessUnits/manageRole/manageBURoleModel';

@Component({
  selector: 'manage-add-role',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13">
      <kendo-dialog-titlebar>
        Create Role
      </kendo-dialog-titlebar>

      <form [formGroup]="addManageRoleForm"  novalidate>
        <div class="col-md-12">
        <div class="form-group">
          <label for="roleName">BU Role<span class="k-required">*</span></label>
          <input type="text" class="k-textbox input_text_standard" id="roleName" formControlName="roleName" placeholder="Enter BU role" required/>
          <div class="k-tooltip k-tooltip-validation font12 font_weight_bold manageBUPopup_error"
               [hidden]="addManageRoleForm.controls.roleName.valid || addManageRoleForm.controls.roleName.pristine">
            <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert"/></span>BU Role is required.
          </div>
        </div>
        <div class="form-group">
          <label>
            <input type="checkbox" formControlName="active" id="active" checked="checked"/>
            Active
          </label>
        </div>
        </div>
      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" (click)="onSave($event)" [disabled]="!addManageRoleForm.valid">
          Save
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>

    </kendo-dialog>

  `
})

export class AddManageRoleComponent {

  public active = false;

  @Input()
  public set model(buRoleModelRequestModel: ManageBURoleModel) {
    this.addManageRoleForm.reset(buRoleModelRequestModel);
    this.active = buRoleModelRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ManageBURoleModel> = new EventEmitter();

  public addManageRoleForm: FormGroup = new FormGroup({
    'roleName': new FormControl(Validators.required),
    'active': new FormControl(false)
  });

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.addManageRoleForm.value);
    this.active = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }
}
