import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  OnDestroy,
  ComponentFactoryResolver,
  ViewContainerRef,
  EventEmitter,
  Output,
  ViewChild,
  ChangeDetectorRef
} from '@angular/core';
import {GridDataResult, PageChangeEvent} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {FormGroup, FormBuilder, FormControl} from '@angular/forms';
import {map} from 'rxjs/operators/map';
import {ManageBURoleModel} from '../../../../models/manageBusinessUnits/manageRole/manageBURoleModel';
import {ManageBUFunctionModel} from '../../../../models/manageBusinessUnits/manageFunction/manageBUFunctionModel';
import {tap} from 'rxjs/operators/tap';
import {ManageFunctionService} from '../../../../services/manageFunction.service';
import {FailureMsgPopupComponent} from '../../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../../services/sessionTimeout.service';


const CREATE_ACTION = 'CREATE';
const REMOVE_ACTION = 'DELETE';

@Component({
  selector: 'manageFunction',
  templateUrl: './manageFunction.component.html'
})

export class ManageFunctionComponent implements OnInit, OnDestroy {

  public title = 'Manage BU Functions';
  public buFunctionMapping: Observable<GridDataResult>;
  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10
  };

  public addManageFunctionForm: FormGroup;
  private girdData: any[] = [];
  public opened: Boolean = false;
  public selectedRowData : any;

  public manageBUFunctionModel: ManageBUFunctionModel;
  public manageFunctionService: ManageFunctionService;
  public selectFunctionItems: Array<SelectFunctionDropdownModel> = [];
  public selectRoleItems: Array<SelectRoleDropdownModel> = [];

  public selectBU_selectedValue: SelectBUDropdownModel;
  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public defaultBuItems : SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};
  public userNetworkId;
  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ManageFunctionService) editServiceFactory: any, private formBuilder: FormBuilder, public viewContainerRef: ViewContainerRef, private componentFactoryResolver: ComponentFactoryResolver, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.manageFunctionService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.loadSelectBUDropDown();
    this.initializePopupFunction();
  }

  private initializePopupFunction() {
    this.addManageFunctionForm = new FormGroup({
      'buRoleName': new FormControl(''),
      'functionName': new FormControl('')
    });
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    /*if (this.selectBU_selectedValue.buId !== 0) {
      this.loadManageFunctionGridComponent(this.selectBU_selectedValue.buId);
    }*/
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.buFunctionMapping = this.manageFunctionService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public addHandler() {
    this.manageBUFunctionModel = new ManageBUFunctionModel();
  }

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  /**
   * Close delete confirmation popup and remove slected row
   * @param fb
   */
  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === 'YES') {
      const inputRequest = {'buFunctionId': this.selectedRowData.buFunctionId, 'uIComponentID': 'AUTHORIZATION_BU_FUNCTION'};
      this.createAndDeleteBUFunctionGridData(inputRequest, REMOVE_ACTION);
    }
  }

  public removeHandler({dataItem}) {
    this.opened = true;
    this.selectedRowData = dataItem;
  }

  public cancelHandler() {
    this.manageBUFunctionModel = undefined;
  }

  public stateChangeBUDropDown() {
    if (this.selectBU_selectedValue.buId !== 0) {
      this.loadManageFunctionGridComponent(this.selectBU_selectedValue.buId);
    }
  }

  public saveHandler(model: ManageBURoleModel) {
    const inputRequestObj = {
      'buId': this.selectBU_selectedValue.buId,
      'buRoleId': model.buRoleName['buRoleId'],
      'functionId': model.functionName['functionId'],
      'uIComponentID': 'AUTHORIZATION_BU_FUNCTION'
    };
    this.createAndDeleteBUFunctionGridData(inputRequestObj, CREATE_ACTION);
  }

  /**
   * Load the manageBUFunction grid data
   */
  private loadManageFunctionGridComponent(buId) {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
    const inputRequestObj = {'buId': buId, 'uIComponentID': 'AUTHORIZATION_BU_FUNCATION'};
    this.manageFunctionService.getManageBUFunctionGridComponent(inputRequestObj).subscribe(manageBUFunctionGridData => {
        manageBUFunctionGridData.response.filter(dataResponse => {
          if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'AUTHORIZATION_BU_FUNCTION'))) {
            if (dataResponse.data.length > 0) {
              this.girdData = dataResponse.data;
              this.buFunctionMapping = this.manageFunctionService.pipe(map(data => process(dataResponse.data, this.gridState)));
              this.refresh();
            } else {
              this.buFunctionMapping = this.manageFunctionService.pipe(map(data => process([], this.gridState)));
              this.failureMsgPopup.open();
              this.errorMessage = 'Sorry! There are no data available for this search criteria.';
            }
          } else if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'DASHBOARD_BU_FUNCTION')) {
            this.selectFunctionItems = [];
            dataResponse.data.forEach(selectFunctionElement => {
              this.selectFunctionItems.push({
                'functionName': selectFunctionElement.functionName,
                'functionId': selectFunctionElement.functionId
              });
            });
          } else if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && (dataResponse.metadata.uIComponentID === 'AUTHORIZATION_BU_ROLE')) {
            this.selectRoleItems = [];
            dataResponse.data.forEach(selectFunctionElement => {
              this.selectRoleItems.push({
                'buRoleName': selectFunctionElement.buRoleName,
                'buRoleId': selectFunctionElement.buRoleId
              });
            });
          } else if ((dataResponse.metadata.status).toUpperCase() === 'ERROR') {
            this.buFunctionMapping = this.manageFunctionService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = dataResponse.metadata.errorMsg[0].errorDesc;
          }
          this.isGridLoadingIndicator = false;
          this._sessionTimeoutService.filter('Session timeout Reset called');
        });
      });
  }

  /**
   * Add and Delete the data from Function grid component
   * @param dataItem
   * @param ACTION
   */
  private createAndDeleteBUFunctionGridData(dataItem, ACTION) {
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    this.manageFunctionService.createAndDeleteBURoleGridData(dataItem, ACTION).subscribe(manageBUFunctionGridData => {
      if (((manageBUFunctionGridData.metadata.status).toUpperCase() === 'SUCCESS')) {
        this.loadManageFunctionGridComponent(this.selectBU_selectedValue.buId);
      } else if ((manageBUFunctionGridData.metadata.status).toUpperCase() === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = manageBUFunctionGridData.metadata.errorMsg[0].errorDesc;
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }

  /**
   * Load the select BU dropdown component
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = {'uIComponentID': 'AUTHORIZATION_BU'};
    this.manageFunctionService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
        if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
          //this.selectBU_selectedValue = selectBUDropDownResponse.data[0];
          //this.loadManageFunctionGridComponent(this.selectBU_selectedValue.buId);
          selectBUDropDownResponse.data.forEach(selectBUElement => {
            this.selectBUItems.push(selectBUElement);
          });
        }
        this.buDropdown_loading_indicator = false;
      },
      error => console.log(error)
    );
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.manageFunctionService.unsubscribe();
  }

}
