import {Component, EventEmitter, Input, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ManageBUFunctionModel} from '../../../../models/manageBusinessUnits/manageFunction/manageBUFunctionModel';

@Component({
  selector: 'manage-add-function',
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13">
      <kendo-dialog-titlebar>
        Assign Function To Role
      </kendo-dialog-titlebar>

      <form [formGroup]="addManageFunctionForm">
        <div class="col-md-12">
          <div class="form-group">
            <label class="k-form-field">
              <span>Select Role<span class="k-required">*</span></span>
            </label>
            <kendo-dropdownlist
              [data]="selectRoleItems"
              [defaultItem]="defaultRoleText"
              (valueChange)="selectRoleChangeDropDownPopUp($event)"
              textField="buRoleName"
              valueField="buRoleId"
              formControlName="buRoleName"
              id="buRoleName" class="width100per input_text_standard" required>
            </kendo-dropdownlist>

            <!-- Select Role dropdown validation-->
            <div class="k-tooltip k-tooltip-validation marginTop0px font12 font_weight_bold crudPopup_error" [hidden]="addManageFunctionForm.controls.buRoleName.valid || addManageFunctionForm.controls.buRoleName.pristine">
              <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert" /></span>
              Role is required
            </div>

          </div>
          <div class="form-group">
            <label class="k-form-field">
              <span>Select Function<span class="k-required">*</span></span>
            </label>
            <kendo-dropdownlist
              [data]="selectFunctionItems"
              [defaultItem]="defaultFnText"
              (valueChange)="selectFunctionChangeDropDownPopUp($event)"
              textField="functionName"
              valueField="functionId"
              formControlName="functionName"
              id="functionName" class="width100per input_text_standard" required>
            </kendo-dropdownlist>

            <!-- Select Function dropdown validation-->
            <div class="k-tooltip k-tooltip-validation marginTop0px font12 font_weight_bold crudPopup_error" [hidden]="addManageFunctionForm.controls.functionName.valid || addManageFunctionForm.controls.functionName.pristine">
              <br><span class="margin-right-5"><img src="./assets/images/ico-error-alert.png" alt="" class="icons icons-alert" /></span>Function is required
            </div>

          </div>
        </div>
      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" (click)="onSave($event)" [disabled]="!addManageFunctionForm.valid">Save</button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>

    </kendo-dialog>
  `
})

export class AddManageFunctionComponent {

  public active = false;
  public defaultFnText: SelectFunctionDropdownModel = {'functionName': 'Select function name', 'functionId': 0};
  public defaultRoleText: SelectRoleDropdownModel = {'buRoleName': 'Select Role', 'buRoleId': 0};

  @Input()
  public selectFunctionItems: Array<SelectFunctionDropdownModel> = [];

  @Input()
  public selectRoleItems: Array<SelectRoleDropdownModel> = [];

  @Input()
  public set model(buFunctionModelRequestModel: ManageBUFunctionModel) {
    this.addManageFunctionForm.reset(buFunctionModelRequestModel);
    this.active = buFunctionModelRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ManageBUFunctionModel> = new EventEmitter();

  public addManageFunctionForm: FormGroup = new FormGroup({
    'buRoleName': new FormControl(Validators.required),
    'functionName': new FormControl(Validators.required)
  });

  public selectRoleChangeDropDownPopUp(value){
    if (value.buRoleId == 0) {
      this.addManageFunctionForm.controls['buRoleName'].setErrors({'incorrect': true}); 
    }
  }

  public selectFunctionChangeDropDownPopUp(value){
    if (value.functionId == 0) {
      this.addManageFunctionForm.controls['functionName'].setErrors({'incorrect': true}); 
    }
  }

  public onSave(e): void {
    this.save.emit(this.addManageFunctionForm.value);
    this.active = false;
    e.preventDefault();
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }
}
