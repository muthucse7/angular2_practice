import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  Input,
  EventEmitter,
  Output,
  ViewChild,
  ChangeDetectorRef, OnDestroy
} from '@angular/core';
import {GridDataResult, PageChangeEvent} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {FormGroup, FormBuilder} from '@angular/forms';
import {ManageBUComponentModel} from '../../../../models/manageBusinessUnits/manageBU/manageBUComponentModel';
import {ManageBUService} from '../../../../services/manageBU.service';
import {map} from 'rxjs/operators/map';

/**
 * Manage BU request and response model
 */
import {ManageBUCreateAndUpdateRequestModel} from '../../../../models/manageBusinessUnits/manageBU/manageBUCreateAndUpdateRequestModel';
import {FailureMsgPopupComponent} from '../../../../widgets/failureMsg-popup.component';
import {SessionTimeoutService} from '../../../../services/sessionTimeout.service';
import {tap} from 'rxjs/operators';


const CREATE_ACTION = 'Create';
const UPDATE_ACTION = 'Update';


@Component({
  selector: 'manage-bu',
  templateUrl: './manageBU.component.html'
})

export class ManageBUComponent implements OnInit, OnDestroy {
  public view: Observable<GridDataResult>;
  public gridState: State = {
    sort: [],
    skip: 0,
    take: 10
  };

  public isNew: boolean;
  private manageBUService: ManageBUService;
  public manageBUComponentObj: ManageBUComponentModel;
  public buActionEditModel: ManageBUCreateAndUpdateRequestModel;

  public selectUnitTypeItems: Array<SelectSearchTypeDropdownModel> = [];
  public unitName_selectedValue: SelectSearchTypeDropdownModel;

  @Input() editBUContainer: String = 'show';
  @Input() viewBUContainer: String = 'hidden';
  private girdData: any[] = [];
  public buSupportUnitChecked: String;
  public activeChecked: String = 'checked';
  public unitDropDownDisabled: Boolean = true;
  public isGridLoadingIndicator: Boolean = false;


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ManageBUService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.manageBUService = editServiceFactory();
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public ngOnInit(): void {
    this.loadGridData();
    this.loadSearchTypeElementDropDown();
  }


  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
    //this.loadGridData();
  }

  // load grid data
  private loadGridData() {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    const inputRequestObj = {'uIComponentID': 'AUTHORIZATION_BU', 'buId': ''};

    this.manageBUService.getManageBUComponentGridValues(inputRequestObj).pipe(
      tap(res => {
        this.girdData = res.data;
      })).subscribe(res => {
        if (((res.metadata.status).toUpperCase() === 'SUCCESS') && ((res.metadata.uIComponentID === 'AUTHORIZATION_BU'))) {
          if (res.data.length > 0) {
            this.view = this.manageBUService.pipe(map(data => process(res.data, this.gridState)));
          } else {
            this.view = this.manageBUService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }
        } else if ((res.metadata.status).toUpperCase() === 'ERROR') {
          this.view = this.manageBUService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = res.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });

  }

  public onStateChange(state: State) {
    this.gridState = state;
    //this.loadGridData();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.view = this.manageBUService.pipe(map(response => process(sortedData, this.gridState)));
    }

  }

  // method to add new BU request in pop up
  public addHandler() {
    this.buActionEditModel = new ManageBUCreateAndUpdateRequestModel();
    this.isNew = true;
    this.buActionEditModel.active = 'true';
    this.unitName_selectedValue = undefined;
  }

  public isSupportUnitChecked(event) {
    if (event.target.checked) {
      this.unitDropDownDisabled = false;
    } else {
      this.unitDropDownDisabled = true;
    }
  }

  // method to create new BU request and update existing request
  public saveHandler(buActionRequestModel: ManageBUCreateAndUpdateRequestModel) {

    const action = this.isNew ? CREATE_ACTION : UPDATE_ACTION;

    // If add bu, sending buID as 0
    if (action === 'Create') {
      buActionRequestModel.buId = 0;
      buActionRequestModel.uIComponentID = 'AUTHORIZATION_BU_CREATE';
    }
    if (action === 'Update') {
      console.log(this.buActionEditModel.buId);

      buActionRequestModel.buId = this.buActionEditModel.buId;
      buActionRequestModel.uIComponentID = 'AUTHORIZATION_BU_UPDATE';

      // checks for matching objects buActionRequestModel and buActionEditModel -> no servcie call -> no update found
      if ((buActionRequestModel.buName === this.buActionEditModel.buName) && (buActionRequestModel.buShortName === this.buActionEditModel.buShortName) &&
        (buActionRequestModel.buEmailId === this.buActionEditModel.buEmailId) && (buActionRequestModel.buContactPerson === this.buActionEditModel.buContactPerson) &&
        (buActionRequestModel.active === this.buActionEditModel.active) && (buActionRequestModel.buSupportUnit === this.buActionEditModel.buSupportUnit) && (buActionRequestModel.unitName === this.buActionEditModel.unitName)) {
        return;
      }

    }

    // Converting buSupportUnit field values=> true = Y & false = N
    if ((buActionRequestModel.buSupportUnit != null) && (buActionRequestModel.buSupportUnit.toString() === 'true') || (buActionRequestModel.buSupportUnit === 'Y')) {
      buActionRequestModel.buSupportUnit = 'Y';
      this.buActionEditModel.buSupportUnit = 'Y';
    } else {
      buActionRequestModel.buSupportUnit = 'N';
      this.buActionEditModel.buSupportUnit = 'N';
    }

    // Converting active field values=> true = Active & false = Inactive
    if ((buActionRequestModel.active != null) && (buActionRequestModel.active.toString() === 'true') || (buActionRequestModel.active === 'Active')) {
      buActionRequestModel.active = 'Active';
      this.buActionEditModel.active = 'Active';
    } else {
      buActionRequestModel.active = 'Inactive';
      this.buActionEditModel.active = 'Inactive';
    }

    //unitname
    if (this.unitDropDownDisabled) {
      buActionRequestModel.unitName = 'BusinessUnit';
    }

     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    // Service call for create and update action
    this.manageBUService.createAndUpdateBUGridData(buActionRequestModel, action).subscribe(buActionResponse => {
      if (((buActionResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((buActionResponse.metadata.uIComponentID === 'AUTHORIZATION_BU_CREATE') || (buActionResponse.metadata.uIComponentID === 'AUTHORIZATION_BU_UPDATE'))) {

        this.loadGridData();
      } else if ((buActionResponse.metadata.status).toUpperCase() === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = buActionResponse.metadata.errorMsg[0].errorDesc;
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });

    this.buActionEditModel = undefined;
  }


  /**
   * Load the select unit dropdown component
   */
  private loadSearchTypeElementDropDown() {
    const selectUnitTypeRequestObj = '{ "searchCriteria1": ' +
      '[{ "key": "uiComponentID", "value": "ADMIN_CONFIG_SEARCHBYID", "datatype": "string"},' +
      '{ "key": "categoryName", "value": "SupportUnit", "datatype": "string"}, ' +
      '{ "key": "subCategoryName", "value": "UnitName", "datatype": "string"}, ' +
      '{ "key": "active", "value": "Active", "datatype": "string"}]}';

    this.manageBUService.getSelectUnitNameDropDownValues(selectUnitTypeRequestObj).subscribe(crudConfigGridData => {
      crudConfigGridData.response.filter(dataResponse => {
        if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_CONFIG_SEARCHBYID'))) {
          dataResponse.data.forEach(selectSearchTypeElement => {
            this.selectUnitTypeItems.push(selectSearchTypeElement);
          });
        }
      });
    });
    error => console.log(error);

  }

  // Method for edit action
  public editHandler({dataItem}) {

    this.buActionEditModel = dataItem;
    this.isNew = false;
    this.editBUContainer = 'show';

    // Converting BuSupport values for the checkbox
    if (dataItem.buSupportUnit === 'Y') {
      this.buSupportUnitChecked = 'checked';
      this.unitDropDownDisabled = false;
    } else if (dataItem.buSupportUnit === 'N') {
      this.buSupportUnitChecked = null;
      this.unitDropDownDisabled = true;
    }

    // Converting Active/Inactive values for the checkbox
    if (dataItem.active === 'Active') {
      this.activeChecked = 'checked';
    } else if (dataItem.active === 'Inactive') {
      this.activeChecked = null;
    }

    this.unitName_selectedValue = dataItem.unitName;


    //this.unitName_selectedValue = {value: dataItem.unitName, key: dataItem.unitName.replace(/[\s]/g, '')};
  }

  public cancelHandler() {
    this.manageBUComponentObj = undefined;
  }

  public removeHandler({dataItem}) {
    this.manageBUService.remove(dataItem);
    this._sessionTimeoutService.filter('Session timeout Reset called');
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.manageBUService.unsubscribe();
  }

}
