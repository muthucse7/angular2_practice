import {Component, Input, Output, EventEmitter, OnInit, Inject, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {Validators, FormGroup, FormControl, FormBuilder} from '@angular/forms';
import {ManageBUService} from '../../../../services/manageBU.service';
import {Observable} from 'rxjs/Observable';
import {process, State} from '@progress/kendo-data-query';
import {map} from 'rxjs/operators/map';

import {GridDataResult} from '@progress/kendo-angular-grid';
import {ManageBUCreateAndUpdateRequestModel} from '../../../../models/manageBusinessUnits/manageBU/manageBUCreateAndUpdateRequestModel';


@Component({
  selector: 'manage-bu-grid-edit-buform',
  styles: [
    'input[type=text] { width: 100%; }'
  ],
  templateUrl: './edit-manageBU.component.html'
})
export class GridBUEditFormComponent implements OnInit {
  public active = false;
  private manageBUService: ManageBUService;
  public view: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';

  constructor(@Inject(ManageBUService) editServiceFactory: any, private formBuilder: FormBuilder, public viewContainerRef: ViewContainerRef, private componentFactoryResolver: ComponentFactoryResolver) {
    this.manageBUService = editServiceFactory();
  }

  public ngOnInit(): void {
  }

  public editForm: FormGroup = new FormGroup({
    'buName': new FormControl(Validators.required),
    'buShortName': new FormControl('', Validators.required),
    'buContactPerson': new FormControl(0, Validators.compose([Validators.required])),
    'buEmailId': new FormControl('', Validators.compose([Validators.required, Validators.pattern(this.emailPattern)])),
    'unitName': new FormControl(false),
    'buSupportUnit': new FormControl(false),
    'active': new FormControl(false)
  });

  @Input() public isNew = false;
  @Input() public buSupportUnitChecked;
  @Input() public activeChecked;
  @Input() public selectUnitTypeItems: Array<SelectSearchTypeDropdownModel> = [];
  @Input() public unitName_selectedValue: SelectSearchTypeDropdownModel;
  @Input() public unitDropDownDisabled;

  @Input()
  public set model(buActionRequestModel: ManageBUCreateAndUpdateRequestModel) {
    this.editForm.reset(buActionRequestModel);
    this.active = buActionRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ManageBUCreateAndUpdateRequestModel> = new EventEmitter();
  @Output() isSupportUnitChecked: EventEmitter<any> = new EventEmitter();


  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.editForm.value);
    this.active = false;
    console.log(this.editForm.value);
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  public onSupportUnitChecked(e): void{
    this.isSupportUnitChecked.emit(e);
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.manageBUService.unsubscribe();
  }
}
