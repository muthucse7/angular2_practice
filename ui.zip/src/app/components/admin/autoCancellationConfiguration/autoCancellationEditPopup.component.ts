import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AutoSuspendEditPopupModel } from '../../../models/autoSuspendConfig/autoSuspendEditPopupModel';

@Component({
  selector: 'auto-pass-edit-config',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="autoPassEditPopupIsactive" (close)="closeForm()" class="font13" [width]="300">
      <kendo-dialog-titlebar>
      Edit Auto Pass Config
      </kendo-dialog-titlebar>

      <form [formGroup]="autoPassEditConfigForm" class="fofTestData" novalidate>
        <div class="form-group">
          <input type="checkbox" class="k-checkbox" id="isAutoSuspendEnabled" 
          formControlName="statusModal" checked={{isAutoPassEnabledCheckbox}}>
          <label class="k-checkbox-label" for="isAutoSuspendEnabled"> IS Auto Pass Enabled</label>
        </div>

        <div class="form-group">
          <label for="runFrequencyInMins" class="control-label width100per">
            <span>Run Frequency In-Mins</span><span class="k-required">*</span>
          </label>
          <kendo-numerictextbox
            [autoCorrect]="true"
            [format]="alertFormat"
            [min]="5"
            [max]="60"
            id="runFrequencyInMins"
            class="width100per input_text_standard"
            formControlName="runFrequencyMinsModel"
            placeholder="Enter Run Frequency In-Mins"
            required>
          </kendo-numerictextbox>
        </div>

      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" [disabled]="!autoPassEditConfigForm.valid" (click)="onSave($event, ('UPDATE'))">
        Update
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>
    </kendo-dialog>
  `
})

export class AutoCancellationEditPopupComponent {

  public alertFormat: string = 'n2';

  @Input() public autoPassEditPopupIsactive;
  @Input() public isAutoPassEnabledCheckbox;

  @Input()
  public set model(AutoPassEditPopupRequestModel: AutoSuspendEditPopupModel) {
    this.autoPassEditConfigForm.reset(AutoPassEditPopupRequestModel);
    this.autoPassEditPopupIsactive = AutoPassEditPopupRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<AutoSuspendEditPopupModel> = new EventEmitter();

  public autoPassEditConfigForm: FormGroup = new FormGroup({
    'autoSuspendPassConfigIdModal': new FormControl(),
    'autoActionModal': new FormControl(),
    'statusModal': new FormControl(),
    'startCutoffTimeModal': new FormControl(),
    'endCutoffTimeModal': new FormControl(),
    'runFrequencyMinsModel': new FormControl('', Validators.required)
  });

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.autoPassEditConfigForm.value);
    this.autoPassEditPopupIsactive = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.autoPassEditPopupIsactive = false;
    this.cancel.emit();
  }

}
