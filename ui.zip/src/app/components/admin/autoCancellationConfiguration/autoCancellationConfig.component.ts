import {
  Component,
  OnInit,
  Inject,
  OnDestroy,
  ComponentFactoryResolver,
  ChangeDetectorRef,
  ViewChild,
  Output,
  EventEmitter, Input
} from '@angular/core';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {Observable} from 'rxjs/Observable';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SessionTimeoutService} from '../../../services/sessionTimeout.service';
import {FailureMsgPopupComponent} from '../../../widgets/failureMsg-popup.component';
import { SuccessMsgPopupComponent } from '../../../widgets/successMsg-popup.component';
import {map} from 'rxjs/operators/map';
import {tap} from 'rxjs/operators/tap';
import { AutoCancellationConfigService } from '../../../services/autoCancellationConfig.service';
import { AutoSuspendEditPopupModel } from '../../../models/autoSuspendConfig/autoSuspendEditPopupModel';



@Component({
  selector: 'autoCancellationConfig',
  templateUrl: './autoCancellationConfig.component.html'
})

export class AutoCancellationConfigComponent implements OnInit, OnDestroy {

  public autoPassConfigGridData: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  private autoCancellationConfigService: AutoCancellationConfigService;
  public autoPassEditPopupModel: AutoSuspendEditPopupModel;

  public isGridLoadingIndicator: Boolean = false;
  public isRefreshBtnEnabled: Boolean = false;
  public isAutoPassRequestEnabled: Boolean = false;
  public accourdianTitle: String = 'Loading...';

  // Edit popup values
  public isAutoPassEnabledCheckbox = null;
  public autoPassEditPopupIsactive = true;

  // Batch config data
  public isAutoPassBatchRunning: String = "";
  public lastAutoPassBatchCompletedDateTime: String = "";
  
  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('successMsgPopup')
  private successMsgPopup: SuccessMsgPopupComponent;
  public successMessage;
  
  constructor(@Inject(AutoCancellationConfigService) autoCancellationConfigServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private componentFactoryResolver: ComponentFactoryResolver, private _sessionTimeoutService: SessionTimeoutService) {
    this.autoCancellationConfigService = autoCancellationConfigServiceFactory();
  }

  public ngOnInit(): void {
    this.getAutoPassConfigGridComponent();
    this.getAutoPassBatchConfigComponent();
    this.verifyReadAndWriteAccess();
  }

  // Enabling config update button based on the access model
 private verifyReadAndWriteAccess() {
  let isAutoSuspendRequestFlag = localStorage.getItem('isAutoPassRequestEnabled');
  if (isAutoSuspendRequestFlag != '' && isAutoSuspendRequestFlag != null) {
    this.isAutoPassRequestEnabled = JSON.parse(localStorage.getItem('isAutoPassRequestEnabled'));
  } else {
    this.isAutoPassRequestEnabled = false;
  }
}
  private getAutoPassConfigGridComponent() {
    const inputRequestObj = { 
      "autoAction": "Pass",
      "isActive":"Active",
      'uIComponentID': 'GET_AUTO_SUSPEND_PASS_CONFIG_INFO' 
    };
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
    this.autoCancellationConfigService.getAutoCancellationConfigServiceGridComponent(inputRequestObj)
      .subscribe(autoCancellationConfigData => {
        if (((autoCancellationConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((autoCancellationConfigData.metadata.uIComponentID === 'GET_AUTO_SUSPEND_PASS_CONFIG_INFO'))) {
          if (autoCancellationConfigData.data.length > 0) {
            this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process(autoCancellationConfigData.data, this.gridState)));
            this.refresh();
          } else {
            this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }
        } else if ((autoCancellationConfigData.metadata.status).toUpperCase() === 'ERROR') {
          this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = autoCancellationConfigData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  // Get batch config details
  private getAutoPassBatchConfigComponent(){
    const inputRequestObj = { 
      'autoAction': 'Pass',
      'uIComponentID': 'GET_AUTO_SUSPEND_PASS_BATCH_CONFIG' };
    this.autoCancellationConfigService.getAutoCancellationBatchConfig(inputRequestObj)
      .subscribe(suspendBatchData => {
        if (((suspendBatchData.metadata.status).toUpperCase() === 'SUCCESS') && ((suspendBatchData.metadata.uIComponentID === 'GET_AUTO_SUSPEND_PASS_BATCH_CONFIG'))) {
          if (suspendBatchData.data.length > 0) {
            suspendBatchData.data.filter(configData => {
              this.isAutoPassBatchRunning = configData.batchRunning;
              this.lastAutoPassBatchCompletedDateTime = configData.batchCompleteTime; 
              this.accourdianTitle = 'Auto Pass Batch Configuration (SERVER: '+configData.serverName+')';
            });
          }
        } else if ((suspendBatchData.metadata.status).toUpperCase() === 'ERROR') {
          this.failureMsgPopup.open();
          this.errorMessage = suspendBatchData.metadata.errorMsg[0].errorDesc;
        }
        this._sessionTimeoutService.filter('Session timeout Reset called');
        this.isRefreshBtnEnabled= false;
      });
  }

  public autoPassConfigEditHandler({dataItem}){ 
    this.autoPassEditPopupModel = dataItem;
    if ((dataItem.status!=undefined) && (dataItem.status!=null) && (dataItem.status === 'Enabled')) {
      this.isAutoPassEnabledCheckbox = 'checked';
    } else {
      this.isAutoPassEnabledCheckbox = null;
    }
    this.autoPassEditPopupModel.statusModal = dataItem.status;
    this.autoPassEditPopupModel.autoSuspendPassConfigIdModal = dataItem.autoSuspendPassConfigId;
    this.autoPassEditPopupModel.runFrequencyMinsModel = +dataItem.runFrequencyMins;
    this.autoPassEditPopupIsactive = false;
   }

   public autoPassSaveHandler(autoPassSaveModel: AutoSuspendEditPopupModel) {
    if ((autoPassSaveModel.statusModal !== null) && (autoPassSaveModel.statusModal.toString() === 'true') || (autoPassSaveModel.statusModal === 'Enabled')) {
      autoPassSaveModel.statusModal = 'Enabled';
    } else {
      autoPassSaveModel.statusModal = 'Disabled';
    }
    const inputRequestObj = {
      'autoSuspendPassConfigId': autoPassSaveModel.autoSuspendPassConfigIdModal,
      'autoAction': 'Pass',
      'isActive': 'Active',
      'status': autoPassSaveModel.statusModal,
      'startCutoffTime': null,
      'endCutoffTime': null,
      'runFrequencyMins': autoPassSaveModel.runFrequencyMinsModel,
      'uIComponentID': 'UPDATE_AUTO_SUSPEND_PASS_CONFIG'
    };
    // Trigger Update Service call
    this.updateAutoSuspendConfig(inputRequestObj);
  }

  // Update the pass Config data and refresh the grid component
  private updateAutoSuspendConfig(inputRequestObj){
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = {sort: [], skip: 0, take: 10};
    this.autoCancellationConfigService.updateAutoPassConfig(inputRequestObj)
      .subscribe(autoSuspendConfigData => {
        if (((autoSuspendConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((autoSuspendConfigData.metadata.uIComponentID === 'UPDATE_AUTO_SUSPEND_PASS_CONFIG'))) {
          if (autoSuspendConfigData.data.length > 0) {
            this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process(autoSuspendConfigData.data, this.gridState)));
            this.refresh();
          } else {
            this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! We are unable to update the Config data.';
          }
        } else if ((autoSuspendConfigData.metadata.status).toUpperCase() === 'ERROR') {
          this.autoPassConfigGridData = this.autoCancellationConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = autoSuspendConfigData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
   }

   public autoPassCancelHandler() {
    this.autoPassEditPopupModel = undefined;
  }

  public getRefreshAutoPassBatch(){
    this.isRefreshBtnEnabled= true;
    this.getAutoPassBatchConfigComponent();
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() { 
    this.autoCancellationConfigService.unsubscribe();
  }

}
