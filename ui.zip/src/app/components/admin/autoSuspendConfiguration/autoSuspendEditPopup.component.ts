import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AutoSuspendEditPopupModel } from '../../../models/autoSuspendConfig/autoSuspendEditPopupModel';

@Component({
  selector: 'auto-suspend-edit-config',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="autoSuspendEditPopupIsactive" (close)="closeForm()" class="font13" [width]="300">
      <kendo-dialog-titlebar>
      Edit Auto Suspend Config
      </kendo-dialog-titlebar>

      <form [formGroup]="autoSuspendEditConfigForm" class="fofTestData" novalidate>
        <div class="form-group">
          <input type="checkbox" class="k-checkbox" id="isAutoSuspendEnabled" 
          formControlName="statusModal" checked={{isAutoSuspendEnabledCheckbox}}>
          <label class="k-checkbox-label" for="isAutoSuspendEnabled"> IS Auto Suspend Enabled</label>
        </div>

        <div class="form-group">
          <label for="startCutOffTime" class="control-label width100per">
            <span>Start Cut Off Time</span><span class="k-required">*</span>
          </label>
          <kendo-timepicker 
          class="width100per input_text_standard"
          [(value)]="startCutOffTimeValue" 
          [format]="'HH:mm'" 
          formControlName="startCutoffTimeModal" 
          id="startCutOffTime"
          placeholder="Select Start Time" required>
          </kendo-timepicker>
        </div>

        <div class="form-group">
          <label for="endCutOffTime" class="control-label width100per">
            <span>End Cut Off Time</span><span class="k-required">*</span>
          </label>
          <kendo-timepicker 
          class="width100per input_text_standard"
          [format]="'HH:mm'" 
          [(value)]="endCutOffTimeValue" 
          formControlName="endCutoffTimeModal" 
          id="endCutOffTime"
          placeholder="Select End Time" required>
          </kendo-timepicker>
        </div>

        <div class="form-group">
          <label for="runFrequencyInMins" class="control-label width100per">
            <span>Run Frequency In-Mins</span><span class="k-required">*</span>
          </label>
          <kendo-numerictextbox
            [autoCorrect]="true"
            [format]="alertFormat"
            [min]="5"
            [max]="60"
            id="runFrequencyInMins"
            class="width100per input_text_standard"
            formControlName="runFrequencyMinsModel"
            placeholder="Enter Run Frequency In-Mins"
            required>
          </kendo-numerictextbox>
        </div>

      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" [disabled]="!autoSuspendEditConfigForm.valid" (click)="onSave($event, ('UPDATE'))">
        Update
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>
    </kendo-dialog>
  `
})

export class AutoSuspendEditPopupComponent {

  public alertFormat: string = 'n2';

  @Input() public autoSuspendEditPopupIsactive;
  @Input() public isAutoSuspendEnabledCheckbox;
  @Input() public startCutOffTimeValue;
  @Input() public endCutOffTimeValue;

  @Input()
  public set model(AutoSuspendEditPopupRequestModel: AutoSuspendEditPopupModel) {
    this.autoSuspendEditConfigForm.reset(AutoSuspendEditPopupRequestModel);
    this.autoSuspendEditPopupIsactive = AutoSuspendEditPopupRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<AutoSuspendEditPopupModel> = new EventEmitter();

  public autoSuspendEditConfigForm: FormGroup = new FormGroup({
    'autoSuspendPassConfigIdModal': new FormControl(),
    'autoActionModal': new FormControl(),
    'statusModal': new FormControl(),
    'startCutoffTimeModal': new FormControl('', Validators.required),
    'endCutoffTimeModal': new FormControl('', Validators.required),
    'runFrequencyMinsModel': new FormControl('', Validators.required)
  });

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.autoSuspendEditConfigForm.value);
    this.autoSuspendEditPopupIsactive = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.autoSuspendEditPopupIsactive = false;
    this.cancel.emit();
  }

}
