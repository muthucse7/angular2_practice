import {
  Component,
  OnInit,
  Inject,
  OnDestroy,
  ComponentFactoryResolver,
  ChangeDetectorRef,
  ViewChild,
  Output,
  EventEmitter, Input
} from '@angular/core';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import { AutoSuspendConfigService } from '../../../services/autoSuspendConfig.service';
import {Observable} from 'rxjs/Observable';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SessionTimeoutService} from '../../../services/sessionTimeout.service';
import {FailureMsgPopupComponent} from '../../../widgets/failureMsg-popup.component';
import { SuccessMsgPopupComponent } from '../../../widgets/successMsg-popup.component';
import {map} from 'rxjs/operators/map';
import {tap} from 'rxjs/operators/tap';
import { AutoSuspendEditPopupModel } from '../../../models/autoSuspendConfig/autoSuspendEditPopupModel';
import * as moment from 'moment';

@Component({
  selector: 'autoSuspendConfig',
  templateUrl: './autoSuspendConfig.component.html'
})

export class AutoSuspendConfigComponent implements OnInit, OnDestroy {

  public autoSuspendConfigGridData: Observable<GridDataResult>;
  public gridState: State = {sort: [], skip: 0, take: 10};
  private autoSuspendConfigService: AutoSuspendConfigService;
  public autoSuspendEditPopupModel: AutoSuspendEditPopupModel;
  public isAutoSuspendRequestEnabled: Boolean = false;

  public isGridLoadingIndicator: Boolean = false;
  public isRefreshBtnEnabled: Boolean = false;
  public accourdianTitle: String = 'Loading...';

  // Edit Poup passing values 
  public isUpdateConfrimationOpen: Boolean = false;
  public isAutoSuspendEnabledCheckbox = null;
  public autoSuspendEditPopupIsactive = true;
  public startCutOffTimeValue : Date = null;
  public endCutOffTimeValue: Date = null;

  // Batch config data
  public isAutoSuspendBatchRunning: String = "";
  public lastAutoSuspendBatchCompletedDateTime: String = "";
  
  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('successMsgPopup')
  private successMsgPopup: SuccessMsgPopupComponent;
  public successMessage;
  
  constructor(@Inject(AutoSuspendConfigService) autoSuspendConfigServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private componentFactoryResolver: ComponentFactoryResolver, private _sessionTimeoutService: SessionTimeoutService) {
    this.autoSuspendConfigService = autoSuspendConfigServiceFactory();
  }

  public ngOnInit(): void {
    this.getAutoSuspendConfigGridComponent();
    this.getAutoSuspendBatchConfigComponent();
    this.verifyReadAndWriteAccess();
  }

  // Enabling config update button based on the access model
 private verifyReadAndWriteAccess() {
    let isAutoSuspendRequestFlag = localStorage.getItem('isAutoSuspendRequestEnabled');
    if (isAutoSuspendRequestFlag != '' && isAutoSuspendRequestFlag != null) {
      this.isAutoSuspendRequestEnabled = JSON.parse(localStorage.getItem('isAutoSuspendRequestEnabled'));
    } else {
      this.isAutoSuspendRequestEnabled = false;
    }
  }
 
  // get Auto Suspend Config Grid Content value
 private getAutoSuspendConfigGridComponent() {
    const inputRequestObj = { 
      "autoAction": "Suspend",
      "isActive":"Active",
      'uIComponentID': 'GET_AUTO_SUSPEND_PASS_CONFIG_INFO' 
    };
  
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    this.autoSuspendConfigService.getAutoSuspendConfigServiceGridComponent(inputRequestObj)
      .subscribe(autoSuspendConfigData => {
        if (((autoSuspendConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((autoSuspendConfigData.metadata.uIComponentID === 'GET_AUTO_SUSPEND_PASS_CONFIG_INFO'))) {
          if (autoSuspendConfigData.data.length > 0) {
            this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process(autoSuspendConfigData.data, this.gridState)));
            this.refresh();
          } else {
            this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }
        } else if ((autoSuspendConfigData.metadata.status).toUpperCase() === 'ERROR') {
          this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = autoSuspendConfigData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  // get Auto Suspend Batch Config value
  private getAutoSuspendBatchConfigComponent(){
    const inputRequestObj = { 
    'autoAction': 'Suspend',
    'uIComponentID': 'GET_AUTO_SUSPEND_PASS_BATCH_CONFIG' };
    this.autoSuspendConfigService.getAutoSuspendBatchConfig(inputRequestObj)
      .subscribe(suspendBatchData => {
        if (((suspendBatchData.metadata.status).toUpperCase() === 'SUCCESS') && ((suspendBatchData.metadata.uIComponentID === 'GET_AUTO_SUSPEND_PASS_BATCH_CONFIG'))) {
          if (suspendBatchData.data.length > 0) {
            suspendBatchData.data.filter(configData => {
              this.isAutoSuspendBatchRunning = configData.batchRunning;
              this.lastAutoSuspendBatchCompletedDateTime = configData.batchCompleteTime; 
              this.accourdianTitle = 'Auto Suspend Batch Configuration (SERVER: '+configData.serverName+')';
            });
          }
        } else if ((suspendBatchData.metadata.status).toUpperCase() === 'ERROR') {
          this.failureMsgPopup.open();
          this.errorMessage = suspendBatchData.metadata.errorMsg[0].errorDesc;
        }
        this._sessionTimeoutService.filter('Session timeout Reset called');
        this.isRefreshBtnEnabled= false;
      });
  }

  public autoSuspendConfigEditHandler({dataItem}){
    this.autoSuspendEditPopupModel = dataItem;
    if ((dataItem.status!=undefined) && (dataItem.status!=null) && (dataItem.status === 'Enabled')) {
      this.isAutoSuspendEnabledCheckbox = 'checked';
    } else {
      this.isAutoSuspendEnabledCheckbox = null;
    }
    this.autoSuspendEditPopupModel.statusModal = dataItem.status;
    this.autoSuspendEditPopupModel.autoSuspendPassConfigIdModal = dataItem.autoSuspendPassConfigId;
    this.autoSuspendEditPopupModel.startCutoffTimeModal = new Date(moment(dataItem.startCutoffTime, ["HH:mm"]).format());
    this.autoSuspendEditPopupModel.endCutoffTimeModal =  new Date(moment(dataItem.endCutoffTime, ["HH:mm"]).format());
    this.autoSuspendEditPopupModel.runFrequencyMinsModel = +dataItem.runFrequencyMins;
    this.autoSuspendEditPopupIsactive = false;
   }

   public autoSuspendSaveHandler(autoSuspendSaveModel: AutoSuspendEditPopupModel) {
    if ((autoSuspendSaveModel.statusModal !== null) && (autoSuspendSaveModel.statusModal.toString() === 'true') || (autoSuspendSaveModel.statusModal === 'Enabled')) {
      autoSuspendSaveModel.statusModal = 'Enabled';
    } else {
      autoSuspendSaveModel.statusModal = 'Disabled';
    }
    const inputRequestObj = {
      'autoSuspendPassConfigId': autoSuspendSaveModel.autoSuspendPassConfigIdModal,
      'autoAction': 'Suspend',
      'isActive': 'Active',
      'status': autoSuspendSaveModel.statusModal,
      'startCutoffTime': moment(autoSuspendSaveModel.startCutoffTimeModal).format('HH:mm'),
      'endCutoffTime': moment(autoSuspendSaveModel.endCutoffTimeModal).format('HH:mm'),
      'runFrequencyMins': autoSuspendSaveModel.runFrequencyMinsModel,
      'uIComponentID': 'UPDATE_AUTO_SUSPEND_PASS_CONFIG'
    };
    // Trigger Update Service call
    this.updateAutoSuspendConfig(inputRequestObj);
   }

   private updateAutoSuspendConfig(inputRequestObj){
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = {sort: [], skip: 0, take: 10};

    this.autoSuspendConfigService.updateAutoSuspendConfig(inputRequestObj)
      .subscribe(autoSuspendConfigData => {
        if (((autoSuspendConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((autoSuspendConfigData.metadata.uIComponentID === 'UPDATE_AUTO_SUSPEND_PASS_CONFIG'))) {
          if (autoSuspendConfigData.data.length > 0) {
            this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process(autoSuspendConfigData.data, this.gridState)));
            this.refresh();
          } else {
            this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! We are unable to update the Config data.';
          }
        } else if ((autoSuspendConfigData.metadata.status).toUpperCase() === 'ERROR') {
          this.autoSuspendConfigGridData = this.autoSuspendConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = autoSuspendConfigData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
   }

   public autoSuspendCancelHandler() {
    this.autoSuspendEditPopupModel = undefined;
  }

  public getRefreshAutoSuspendBatch(){
    this.isRefreshBtnEnabled= true;
    this.getAutoSuspendBatchConfigComponent();
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }


  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() { 
    this.autoSuspendConfigService.unsubscribe();
  }

}
