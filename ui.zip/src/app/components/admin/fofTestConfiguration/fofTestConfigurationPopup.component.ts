import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FofAddDataModel } from '../../../models/fofConfig/fofConfigAddData';

@Component({
  selector: 'fof-add-data-config',
  styles: ['input[type=text] { width: 100%; }'],
  template: `
    <kendo-dialog *ngIf="active" (close)="closeForm()" class="font13" [width]="300">
      <kendo-dialog-titlebar>
        {{ isNew ? 'Add New Data Config' : 'Edit Data Config' }}
      </kendo-dialog-titlebar>

      <form [formGroup]="addFofConfigForm" class="fofTestData" novalidate>
        <div class="form-group">
          <label class="control-label width100per">
            <span>Select BU</span><span class="k-required">*</span>
            <kendo-dropdownlist
              [data]="businessTypeItems_popup"
              [defaultItem]="defaultBusinessTypeItem"
              [(ngModel)]="businessType_selectedValue_popup"
              [disabled]="isNew ? false : true"
              textField="businessType"
              valueField="businessId"
              class="width100per input_text_standard"
              [valuePrimitive]="true"
              id="businessType"
              formControlName="businessType" required>
            </kendo-dropdownlist>
          </label>
        </div>
        <div class="form-group">
          <label class="control-label width100per">
            <span>Select Format</span><span class="k-required">*</span>
            <kendo-dropdownlist
              [data]="selectFormatItems_popup"
              [defaultItem]="defaultFormatItem"
              [(ngModel)]="format_selectedValue_popup"
              [disabled]="isNew ? false : true"
              textField="value"
              valueField="key"
              class="width100per input_text_standard"
              formControlName="format"
              [valuePrimitive]="true"
              id="format" required>
            </kendo-dropdownlist>
          </label>
        </div>

        <div class="form-group">
          <label for="hitRateMin" class="control-label width100per">Alert Rate Min<span class="k-required">*</span></label>
          <kendo-numerictextbox
            [autoCorrect]="true"
            [decimals]="2"
            [format]="alertFormat"
            [min]="0"
            [max]="100"
            id="hitRateMin"
            class="width100per input_text_standard"
            formControlName="hitRateMin"
            placeholder="Enter Alert Rate Min"
            required>
          </kendo-numerictextbox>
        </div>

        <div class="form-group">
          <label for="hitRateMax" class="control-label width100per">Alert Rate Max<span class="k-required">*</span></label>
          <kendo-numerictextbox
            [autoCorrect]="true"
            [decimals]="2"
            [format]="alertFormat"
            [min]="0"
            [max]="100"
            id="hitRateMin"
            class="width100per input_text_standard"
            formControlName="hitRateMax"
            placeholder="Enter Alert Rate Max"
            required>
          </kendo-numerictextbox>
        </div>

        <div class="form-group">
          <label for="dataDays" class="control-label width100per">Data days<span class="k-required">*</span></label>
          <kendo-numerictextbox
            [autoCorrect]="true"
            [decimals]="0"
            [format]="dataDaysFormat"
            [min]="1"
            [max]="30"
            id="hitRateMin"
            class="width100per input_text_standard"
            formControlName="dataDays"
            placeholder="Enter Data Days"
            required>
          </kendo-numerictextbox>
        </div>

        <div class="form-group">
          <label class="k-form-field marginTop15px">
            <input type="checkbox" class="k-checkbox" id="randomSampleSizeIsActive" formControlName="randomSampleSizeIsActive" (change)="applyRandomSampleSizeChange($event)" checked={{applyRandomSampleSizeCheckbox}}>
            <label class="k-checkbox-label" for="randomSampleSizeIsActive">Apply Random Sample Size</label>
          </label>
        </div>

        <div class="form-group">
          <label for="dataDays" class="control-label width100per">Random Sample Size Per/Day<span class="k-required">*</span></label>
          <kendo-numerictextbox
            [decimals]="1"
            [format]="dataDaysFormat"
            [min]="1"
            id="randomSampleSizePerDay"
            class="width100per input_text_standard"
            formControlName="randomSampleSizePerDay"
            placeholder="Enter Random Sample Size"
            [attr.disabled]="applyRandomSampleSizeDisabled ? '' : null">
          </kendo-numerictextbox>
        </div>

      </form>

      <kendo-dialog-actions class="margin_zero">
        <button class="k-button k-primary yes_update_button" [disabled]="!addFofConfigForm.valid" (click)="onSave($event, (isNew ? 'SAVE' : 'UPDATE'))">
        {{ isNew ? 'Save' : 'Update' }}
        </button>
        <button class="k-button k-primary no_cancel_button" (click)="onCancel($event)">Cancel</button>
      </kendo-dialog-actions>
    </kendo-dialog>
  `
})

export class FofTestConfigurationPopupComponent {

  public alertFormat: string = 'n2';
  public dataDaysFormat: string = 'n0';

  public active = false;
  public defaultBusinessTypeItem: BusinessTypeDropdownModel = { businessType: 'Please select BU', businessId: 'placeholder' };
  public defaultFormatItem: SelectFormatDropdownModel = { value: 'Please select format', key: 'placeholder' };

  @Input() public isNew = false;
  @Input() businessTypeItems_popup: Array<BusinessTypeDropdownModel> = [];
  @Input() businessType_selectedValue_popup: BusinessTypeDropdownModel;

  @Input() selectFormatItems_popup: Array<SelectFormatDropdownModel> = [];
  @Input() format_selectedValue_popup: SelectFormatDropdownModel;

  @Input() public applyRandomSampleSizeCheckbox;
  @Input() public applyRandomSampleSizeDisabled;


  @Input()
  public set model(FofAddDataRequestModel: FofAddDataModel) {
    this.addFofConfigForm.reset(FofAddDataRequestModel);
    this.active = FofAddDataRequestModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<FofAddDataModel> = new EventEmitter();

  public addFofConfigForm: FormGroup = new FormGroup({
    'businessType': new FormControl('', Validators.required),
    'format': new FormControl('', Validators.required),
    'hitRateMax': new FormControl('', Validators.required),
    'hitRateMin': new FormControl('', Validators.required),
    'dataDays': new FormControl('', Validators.required),
    'fofDataConfigId': new FormControl(''),
    'randomSampleSizeIsActive': new FormControl(''),
    'randomSampleSizePerDay': new FormControl('')
  });

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.addFofConfigForm.value);
    this.active = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.cancel.emit();
  }

  public applyRandomSampleSizeChange(event){
    if(event.target.checked){
      this.applyRandomSampleSizeDisabled = false;
    }else{
      this.applyRandomSampleSizeDisabled = true;
    }
  }
    

}
