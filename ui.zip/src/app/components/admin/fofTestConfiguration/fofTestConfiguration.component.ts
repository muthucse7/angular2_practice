import {Observable} from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  OnDestroy,
  ComponentFactoryResolver,
  ChangeDetectorRef,
  ViewChild,
  Output,
  EventEmitter, Input
} from '@angular/core';
import {GridDataResult} from '@progress/kendo-angular-grid';
import {State, process} from '@progress/kendo-data-query';
import {FofConfigSearchComponentModel} from '../../../models/fofConfig/fofConfigSearchComponentModel';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FofTestConfigurationService} from '../../../services/fofTestConfiguration.service';
import {SessionTimeoutService} from '../../../services/sessionTimeout.service';
import {FailureMsgPopupComponent} from '../../../widgets/failureMsg-popup.component';
import {FofConfigCreateAndUpdateRequestModel} from '../../../models/fofConfig/fofConfigCreateAndUpdateRequestModel';
import {map} from 'rxjs/operators/map';
import {tap} from 'rxjs/operators/tap';
import {SuccessMsgPopupComponent} from '../../../widgets/successMsg-popup.component';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';

@Component({
  selector: 'fofTestDataConfig',
  templateUrl: './fofTestConfiguration.component.html'
})
export class FofTestConfigurationComponent implements OnInit, OnDestroy {

  fofConfigSearchForm: FormGroup;
  fofConfigSearchComponentsObj = new FofConfigSearchComponentModel();
  active = true;
  private fofTestDataConfigService: FofTestConfigurationService;
  private girdData: any[] = [];
  public isNew: boolean;

  public title = 'FOF Test Configuration';
  public fofConfigMapping: Observable<GridDataResult>;
  public fofConfigEditItem: FofConfigCreateAndUpdateRequestModel;
  public gridState: State = {sort: [], skip: 0, take: 10};
  public selectBUItems: Array<SelectBUDropdownModel> = [];
  public defaultItem: SelectBUDropdownModel = {buName: 'Please select BU', buId: 0};

  public selectFormatItems: Array<SelectFormatDropdownModel> = [];
  public defaultFormatItem: SelectFormatDropdownModel = {value: 'Please select format', key: 'SelectFormat'};

  //Popup Dropdowns
  public businessTypeItems_popup: Array<BusinessTypeDropdownModel> = [];
  public businessType_selectedValue_popup: BusinessTypeDropdownModel;

  public selectFormatItems_popup: Array<SelectFormatDropdownModel> = [];
  public format_selectedValue_popup: SelectFormatDropdownModel;

  public buDropdown_loading_indicator: Boolean = false;
  public formatDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  public fof_test_current_status = false;
  public fofTestStatus = true;
  public opened: Boolean = false;

  public applyRandomSampleSizeCheckbox: String = null;
  public applyRandomSampleSizeDisabled: Boolean = true;


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('successMsgPopup')
  private successMsgPopup: SuccessMsgPopupComponent;
  public successMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(FofTestConfigurationService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private componentFactoryResolver: ComponentFactoryResolver, private _sessionTimeoutService: SessionTimeoutService) {
    this.fofTestDataConfigService = editServiceFactory();
  }

  public ngOnInit(): void {
    const requestObj = {'uIComponentID': 'FOFTEST_DATA_CONFIG'};
    this.fofConfigSearchForm = this.formBuilder.group({
      'selectBU': [this.fofConfigSearchComponentsObj.selectBU, [Validators.required]],
      'formatName': [this.fofConfigSearchComponentsObj.formatName]
    });

    this.fofConfigSearchForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
    this.loadSelectBUDropDown();
    this.loadSelectFormatDropDown();
    this.loadFofTestCurrentStatus(requestObj);
  }

  onValueChanged(data?: any) {
    if (!this.fofConfigSearchForm) {
      return;
    }
    const form = this.fofConfigSearchForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'selectBU': ''
  };

  validationMessages = {
    'selectBU': {
      'required': 'Please select the BU'
    }
  };

  public onStateChange(state: State) {
    this.gridState = state;
    //this.onSearch();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public onSearch() {
    if (this.fofConfigSearchForm.valid) {
      let businessType, buId, formatName, inputSearchReqObj;
      this.fofConfigSearchComponentsObj = this.fofConfigSearchForm.value;
      if (this.fofConfigSearchForm.controls.selectBU.value != null) {
        businessType = this.fofConfigSearchForm.controls.selectBU.value.buName;
        buId = this.fofConfigSearchForm.controls.selectBU.value.buId;
      }
      if (this.fofConfigSearchForm.controls.formatName.value != null) {
        formatName = this.fofConfigSearchForm.controls.formatName.value.key;
      }

      if ((buId === 0)) {
        this.formErrors['selectBU'] = 'Please select the BU';
        this.fofConfigSearchForm.markAsDirty({});
        return;
      }

      // Invoking the services call to get the grid data values
      if (formatName != '' && formatName != null && formatName!= 'SelectFormat') {
        inputSearchReqObj = {
          'businessType': businessType,
          'format': formatName,
          'uiComponentID': 'FOFTEST_DATA_CONFIG'
        };
      } else {
        inputSearchReqObj = {
          'businessType': businessType,
          'uiComponentID': 'FOFTEST_DATA_CONFIG'
        };
      }
      this.getFofTestDataConfigGridComponent(inputSearchReqObj);
    }
  }

  getFofTestDataConfigGridComponent(inputSearchReqObj) {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
    this.fofTestDataConfigService.getFofTestDataConfigGridComponent(inputSearchReqObj)
      .pipe(
        tap(fofConfigGridData => {
          this.girdData = fofConfigGridData.data;
        }))
      .subscribe(fofConfigGridData => {
        if (((fofConfigGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((fofConfigGridData.metadata.uIComponentID === 'FOFTEST_DATA_CONFIG'))) {
          if (fofConfigGridData.data.length > 0) {
            this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process(fofConfigGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }
        } else if ((fofConfigGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = fofConfigGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  public editHandler({dataItem}) {
    this.fofConfigEditItem = dataItem;
    if ((dataItem.randomSampleSizeIsActive!=undefined) && (dataItem.randomSampleSizeIsActive!=null) && (dataItem.randomSampleSizeIsActive.toUpperCase() === 'ACTIVE')) {
      this.applyRandomSampleSizeCheckbox = 'checked';
      this.applyRandomSampleSizeDisabled = false;

    } else {
      this.applyRandomSampleSizeCheckbox = null;
      this.applyRandomSampleSizeDisabled = true;
    }
    this.isNew = false;
    this.businessType_selectedValue_popup = {businessId: dataItem.businessType, businessType: dataItem.businessType};
    this.format_selectedValue_popup = {key: dataItem.format, value: dataItem.format};
  }

  public addHandler() {
    this.fofConfigEditItem = new FofConfigCreateAndUpdateRequestModel();
    this.isNew = true;    
    this.businessType_selectedValue_popup = undefined;
    this.format_selectedValue_popup = undefined;
  }

  public cancelHandler() {
    this.fofConfigEditItem = undefined;
  }

  public saveHandler(fofConfigEditItem: FofConfigCreateAndUpdateRequestModel) {
    this.isGridLoadingIndicator = true;
    let buId, inputRequestObj;
    const action = this.isNew ? CREATE_ACTION : UPDATE_ACTION;
    if (this.fofConfigSearchForm.controls.selectBU.value != null) {
      buId = this.fofConfigSearchForm.controls.selectBU.value.buId;
    }

    // Converting active field values=> true = Active & false = Inactive
    if ((fofConfigEditItem.randomSampleSizeIsActive !== null) && (fofConfigEditItem.randomSampleSizeIsActive.toString() === 'true') || (fofConfigEditItem.randomSampleSizeIsActive === 'Active')) {
      fofConfigEditItem.randomSampleSizeIsActive = 'Active';
    } else {
      fofConfigEditItem.randomSampleSizeIsActive = 'Inactive';
    }
    
    // randomSampleSizePerDay
    if(fofConfigEditItem.randomSampleSizePerDay==null){
      fofConfigEditItem.randomSampleSizePerDay = 0;
    }

    if (action === CREATE_ACTION) {
      inputRequestObj = {
        'businessType': fofConfigEditItem.businessType,
        'format': fofConfigEditItem.format,
        'active': 'Active',
        'hitRateMin': fofConfigEditItem.hitRateMin,
        'hitRateMax': fofConfigEditItem.hitRateMax,
        'dataDays': fofConfigEditItem.dataDays,
        'randomSampleSizeIsActive': fofConfigEditItem.randomSampleSizeIsActive,
        'randomSampleSizePerDay': fofConfigEditItem.randomSampleSizePerDay,
        'uiComponentID': 'FOFTEST_DATA_CONFIG'
      };
    } else {
      inputRequestObj = {
        'fofDataConfigId': fofConfigEditItem.fofDataConfigId,
        'businessType': fofConfigEditItem.businessType['businessType'],
        'format': fofConfigEditItem.format['key'],
        'active': 'Active',
        'hitRateMin': fofConfigEditItem.hitRateMin,
        'hitRateMax': fofConfigEditItem.hitRateMax,
        'dataDays': fofConfigEditItem.dataDays,
        'randomSampleSizeIsActive': fofConfigEditItem.randomSampleSizeIsActive,
        'randomSampleSizePerDay': fofConfigEditItem.randomSampleSizePerDay,
        'uiComponentID': 'FOFTEST_DATA_CONFIG'
      };
    }


    this.fofTestDataConfigService.insertAndUpdateAndUpdateConfigData(inputRequestObj, action).subscribe(configGridResponse => {
      const uIComponentID = configGridResponse.metadata.uIComponentID.toUpperCase();
      const responseStatus = configGridResponse.metadata.status.toUpperCase();

      if ((responseStatus === 'SUCCESS') && (uIComponentID === 'FOFTEST_DATA_CONFIG')) {
        if ((buId == 0)) {
          this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process(configGridResponse.data, this.gridState)));
        } else {
          this.onSearch();
        }
      } else if (responseStatus === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = configGridResponse.metadata.errorMsg[0].errorDesc;
      }
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
    this.fofConfigEditItem = undefined;
  }

  public removeHandler({dataItem}) {
    this.isGridLoadingIndicator = true;
    let buId;
    this.fofConfigSearchComponentsObj = this.fofConfigSearchForm.value;
    if (this.fofConfigSearchForm.controls.selectBU.value != null) {
      buId = this.fofConfigSearchForm.controls.selectBU.value.buId;
    }
    const inputRequest = {
      'fofDataConfigId': dataItem.fofDataConfigId,
      'uiComponentID': 'FOFTEST_DATA_CONFIG'
    };

    this.fofTestDataConfigService.removeFoftTestDataConfig(inputRequest).subscribe(fofConfigGridData => {
      if (((fofConfigGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((fofConfigGridData.metadata.uIComponentID === 'FOFTEST_DATA_CONFIG'))) {
        if ((buId == 0)) {
          this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process([], this.gridState)));
        } else {
          this.onSearch();
        }
      } else if ((fofConfigGridData.metadata.status).toUpperCase() === 'ERROR') {
        this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process([], this.gridState)));
        this.failureMsgPopup.open();
        this.errorMessage = fofConfigGridData.metadata.errorMsg[0].errorDesc;
      }
      this.isGridLoadingIndicator = false;
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }


  public resetMe(fb) {
    this.fofConfigSearchForm.reset();
    this.fofConfigMapping = this.fofTestDataConfigService.pipe(map(data => process([], this.gridState)));
    this.isGridLoadingIndicator = false;
  }

  /**
   * Load the select BU dropdown component
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = {uIComponentID: 'AUTHORIZATION_BU'};
    this.fofTestDataConfigService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
        if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
          selectBUDropDownResponse.data.forEach(selectBUElement => {
            this.selectBUItems.push(selectBUElement);
            this.businessTypeItems_popup.push({businessType: selectBUElement.buName, businessId: selectBUElement.buName});
          });
        }
        this.buDropdown_loading_indicator = false;
      },
      error => console.log(error)
    );
  }

  /**
   * Load the select Format dropdown component
   */
  private loadSelectFormatDropDown() {
    this.formatDropdown_loading_indicator = true;
    const selectFormatRequestObj = '{ "searchCriteria1": [{ "key": "categoryName", "value": "Transaction", "datatype": "string"}, { "key": "subCategoryName", "value": "Format", "datatype": "string"}, { "key": "active", "value": "Active", "datatype": "string"},{ "key": "uiComponentID","value": "ADMIN_CONFIG_SEARCHBYID","datatype": "string"}]}';
    this.fofTestDataConfigService.getSelectFormatDropDownValues(selectFormatRequestObj).subscribe(crudConfigGridData => {
      crudConfigGridData.response.filter(dataResponse => {
        if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_CONFIG_SEARCHBYID'))) {
          dataResponse.data.forEach(selectFormatElement => {
            this.selectFormatItems.push(selectFormatElement);
            this.selectFormatItems_popup.push(selectFormatElement);
          });
        }
        this.formatDropdown_loading_indicator = false;
      });
    });
    error => console.log(error);

  }

  public fofTestDorpdownValueChange(e){
    if(e.target.checked){
      this.fofTestStatus = true;
    }else{
      this.fofTestStatus = false;
    }
  }

  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === 'YES') {
      let requestObj;
      if (this.fofTestStatus && !this.fof_test_current_status) {
        requestObj = {
          'status': 'Enabled',
          'uIComponentID': 'FOFTEST_DATA_CONFIG'
        };
      } else {
        requestObj = {
          'status': 'Disabled',
          'uIComponentID': 'FOFTEST_DATA_CONFIG'
        };
      }
      this.loadFofTestUpdateService(requestObj);
    }
  }

  // Update fof test data update  status
  public updateFOFTestConfig() {
    this.opened = true;
  }

  loadFofTestUpdateService(requestObj) {
    this.fofTestDataConfigService.fofTestCurrentAndUpdateService(requestObj).subscribe(fofConfigData => {
      if (((fofConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((fofConfigData.metadata.uIComponentID === 'FOFTEST_DATA_CONFIG'))) {
        if (fofConfigData.data.length > 0) {
          fofConfigData.data.forEach(dataElement => {
            if (dataElement.status.toLocaleUpperCase() === 'ENABLED') {
              this.fof_test_current_status = true;
            } else {
              this.fof_test_current_status = false;
            }
          });
          this.fofTestStatus = true;
          this.successMsgPopup.open();
          this.successMessage = 'The FOF test job run status updated successfully.';
        }
      } else if ((fofConfigData.metadata.status).toUpperCase() === 'ERROR') {
        this.fofTestStatus = false;
        this.failureMsgPopup.open();
        this.errorMessage = fofConfigData.metadata.errorMsg[0].errorDesc;
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }

  loadFofTestCurrentStatus(requestObj) {
    this.fofTestDataConfigService.getFofTestCurrentStatus(requestObj).subscribe(fofConfigData => {
      if (((fofConfigData.metadata.status).toUpperCase() === 'SUCCESS') && ((fofConfigData.metadata.uIComponentID === 'FOFTEST_DATA_CONFIG'))) {
        if (fofConfigData.data.length > 0) {
          fofConfigData.data.forEach(dataElement => {
            if (dataElement.status.toLocaleUpperCase() === 'ENABLED') {
              this.fof_test_current_status = true;
            } else {
              this.fof_test_current_status = false;
            }
          });
        }
      }
      this._sessionTimeoutService.filter('Session timeout Reset called');
    });
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.fofTestDataConfigService.unsubscribe();
  }

}
