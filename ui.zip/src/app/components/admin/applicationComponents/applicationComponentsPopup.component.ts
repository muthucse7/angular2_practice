import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { ApplicationComponentsAddAndUpdateRequestModel } from '../../../models/applicationComponents/applicationComponentsAddAndUpdateRequestModel';

@Component({
  selector: 'applicationComponents-grid-edit-form',
  styles: ['input[type=text] { width: 100%; }'],
  templateUrl: './applicationComponentsPopup.component.html'
})

export class ApplicationComponentsPopupComponent {
  public active = false;
  public editForm: FormGroup = new FormGroup({
    'module': new FormControl('', Validators.required),
    'server': new FormControl('', Validators.required),
    'component':new FormControl('', Validators.required),
    'serverStatus': new FormControl(false)
  });

  // Get the values from the parent component
  @Input() public moduleNameItems_popup: Array<ModuleNameDropdownModel> = [];
  @Input() public serverNameItems_popup: Array<ServerNameDropdownModel> = [];
  @Input() public componentNameItems_popup: Array<ComponentNameDropdownModel> = [];

  // Get the selected dropdown values from the parent component
  @Input() public moduleName_selectedValue_popup: ModuleNameDropdownModel;
  @Input() public serverName_selectedValue_popup: ServerNameDropdownModel;
  @Input() public componentName_selectedValue_popup: ComponentNameDropdownModel;

  // Default Dropdown value
  public moduleName_defaultText: ModuleNameDropdownModel = { 'moduleName': 'Select Module Name', 'moduleId': -1 };
  public serverName_defaultText: ServerNameDropdownModel = { 'serverName': 'Select Server Name', 'serverId': -1 };
  public componentName_defaultText: ComponentNameDropdownModel = { 'componentName': 'Select Component Name', 'componentId': -1 };
  public isUpdate_saveBtn_enabled: Boolean = true;

  @Input() public enableFlag;
  @Input() public is_component_server_dropDown_disabled;

  @Input() public isNew = false;

  @Input()
  public set model(applicationCompoentsGridModel: ApplicationComponentsAddAndUpdateRequestModel) {
    this.editForm.reset(applicationCompoentsGridModel);
    this.active = applicationCompoentsGridModel !== undefined;
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() save: EventEmitter<ApplicationComponentsAddAndUpdateRequestModel> = new EventEmitter();
  @Output() moduleValueChangeDropDown: EventEmitter<any> = new EventEmitter();

  constructor() {
    console.log('moduleName' + this.editForm.controls.moduleName);
  }

  public onSave(e): void {
    e.preventDefault();
    this.save.emit(this.editForm.value);
    this.active = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.editForm.reset();
    this.closeForm();
  }

  private closeForm(): void {
    this.active = false;
    this.editForm.reset();
    this.cancel.emit();
  }

  public moduleValueChangeDropDownPopUp(value) {
    if (value.moduleId != -1) {
      this.moduleValueChangeDropDown.emit(value);
    } else {
      this.editForm.controls['module'].setErrors({'incorrect': true}); 
    }
    this.editForm.controls['server'].reset();
    this.editForm.controls['component'].reset();
    
  }

  public serverValueChangeDropDownPopUp(value){
    if (value.serverId == -1) {
      this.editForm.controls['server'].setErrors({'incorrect': true}); 
    }
  }

  public componentValueChangeDropDownPopUp(value){
    if (value.componentId == -1) {
      this.editForm.controls['component'].setErrors({'incorrect': true}); 
    }
  }

}
