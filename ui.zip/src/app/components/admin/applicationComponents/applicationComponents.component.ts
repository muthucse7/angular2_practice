import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  OnDestroy,
  Inject,
  ChangeDetectorRef,
  EventEmitter,
  Output,
  ViewChild,
} from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { ApplicationComponentsAddAndUpdateRequestModel } from '../../../models/applicationComponents/applicationComponentsAddAndUpdateRequestModel';
import { ApplicationComponentsService } from '../../../services/applicationComponents.service';
import { map } from 'rxjs/operators/map';
import { tap } from 'rxjs/operators/tap';
import { ApplicationComponentsGridComponentModel } from '../../../models/applicationComponents/ApplicationComponentsGridComponentModel';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

const CREATE_ACTION = 'CREATE';
const UPDATE_ACTION = 'UPDATE';

@Component({
  selector: 'application-component-screen',
  templateUrl: './applicationComponents.component.html'
})

export class ApplicationComponentsComponent extends BehaviorSubject<any[]> implements OnInit, OnDestroy {

  public view: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  applicationComponentsGridComponentObj = new ApplicationComponentsGridComponentModel();
  appCompForm: FormGroup;
  public editDataItem: ApplicationComponentsAddAndUpdateRequestModel;
  public isNew: boolean;
  private applicationComponentsService: ApplicationComponentsService;

  private girdData: any[] = [];
  public is_component_server_dropDown_disabled: Boolean = true;

  // Add and edit popup drop-down  
  public moduleName_selectedValue_popup: ModuleNameDropdownModel;
  public serverName_selectedValue_popup: ServerNameDropdownModel;
  public componentName_selectedValue_popup: ComponentNameDropdownModel;
  public enableFlag: String = 'checked';

  // Popup dorodown POJO
  public moduleNameItems_popup: Array<ModuleNameDropdownModel> = [];
  public serverNameItems_popup: Array<ServerNameDropdownModel> = [];
  public componentNameItems_popup: Array<ComponentNameDropdownModel> = [];

  //Loading Indicator
  public moduleName_loading_indicator: Boolean = false;
  public serverName_loading_indicator: Boolean = false;
  public componentName_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  // Trigger error message popup if the service is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ApplicationComponentsService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeout: SessionTimeoutService) {
    super([]);
    this.applicationComponentsService = editServiceFactory();
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  public ngOnInit(): void {
    this.loadAppComponentGridData();
    this.loadSelectModuleNameDropDown();
    this.buildForm();
  }

  public onStateChange(state: State) {
    this.gridState = state;
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.view = this.applicationComponentsService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public addHandler() {
    this.editDataItem = undefined;
    this.editDataItem = new ApplicationComponentsAddAndUpdateRequestModel();
    this.isNew = true;
    this.editDataItem.serverStatus = 'true';

    // Reset the selected dropdown values => Add/Edit
    this.moduleName_selectedValue_popup = undefined;
    this.serverName_selectedValue_popup = undefined;
    this.componentName_selectedValue_popup = undefined;

    // Clear Server and component dropdown values. The value should fecth based on the modeulName dorpdown selection
    this.serverNameItems_popup = [];
    this.componentNameItems_popup = [];

  }

  public editHandler({ dataItem }) {
    // Converting server status field values=> Enabled = true & Disabled = false
    if (dataItem.serverStatus.toUpperCase() === 'ENABLED') {
      this.enableFlag = 'checked';
    } else {
      this.enableFlag = null;
    }

    this.editDataItem = dataItem;
    this.isNew = false;
    this.moduleName_selectedValue_popup = { moduleName: dataItem.moduleName, moduleId: dataItem.moduleId };

    // Load the server and component service before setting the detault value
    this.loadSelectServerNameDropDown(dataItem.moduleName, dataItem.moduleId);
    this.loadSelectComponentNameDropDown(dataItem.moduleName, dataItem.moduleId);

    // Setting default value to the dropdown
    this.serverName_selectedValue_popup = { serverName: dataItem.serverName, serverId: dataItem.serverId };
    this.componentName_selectedValue_popup = { componentName: dataItem.componentName, componentId: dataItem.componentId };

  }

  public saveHandler(appComponentGridData: ApplicationComponentsAddAndUpdateRequestModel) {
    const action = this.isNew ? CREATE_ACTION : UPDATE_ACTION;
    let uIComponentID = '';
    // If add component, sending configId as 0
    if (action === CREATE_ACTION) {
        appComponentGridData.configId = 0;
        uIComponentID =  "CONFIG_SERVER_COMPONENTS";
    } else{
        appComponentGridData.configId = this.editDataItem.configId;
        uIComponentID =  "UPDATE_SERVER_COMPONENTS";
    }
    // Converting serverStatus field values=> true = Enabled & false = Disabled
    if ((appComponentGridData.serverStatus !== null) && (appComponentGridData.serverStatus.toString() === 'true') || (appComponentGridData.serverStatus === 'Enabled')) {
      appComponentGridData.serverStatus = 'Enabled';
      this.editDataItem.serverStatus = 'Enabled';
    } else {
      appComponentGridData.serverStatus = 'Disabled';
      this.editDataItem.serverStatus = 'Disabled';
    }

    let inputRequestObj = {
        "configId" : appComponentGridData.configId,
        "moduleId" : appComponentGridData.module['moduleId'],
        "componentId" :	 appComponentGridData.component['componentId'],
        "componentName" : appComponentGridData.component['componentName'],
        "serverId" : appComponentGridData.server['serverId'],
        "serverName" : appComponentGridData.server['serverName'],
        "serverStatus" : appComponentGridData.serverStatus,
        "uIComponentID" : uIComponentID
    };

     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};

    this.applicationComponentsService.insertAndUpdateAppComponentData(inputRequestObj, action).subscribe(crudConfigGridResponse => {
      const uIComponentID = crudConfigGridResponse.metadata.uIComponentID.toUpperCase();
      const responseStatus = crudConfigGridResponse.metadata.status.toUpperCase();
      if ((responseStatus === 'SUCCESS') && ((uIComponentID === 'CONFIG_SERVER_COMPONENTS') || (uIComponentID === 'UPDATE_SERVER_COMPONENTS'))) {
        this.loadAppComponentGridData();
      } else if (responseStatus === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = crudConfigGridResponse.metadata.errorMsg[0].errorDesc;
      }

      this._sessionTimeout.filter('Session timeout Reset called');
    });
    this.editDataItem = undefined;
  }

  public loadAppComponentGridData() {
    const inputSearchReqObj = { 'uIComponentID': 'GET_SERVER_COMPONENT_DETAILS' };
    this.getApplicationComponentGridData(inputSearchReqObj);
  }

  getApplicationComponentGridData(inputRequestObj) {
    this.isGridLoadingIndicator = true;
     // Reset the paging
     this.gridState = {sort: [], skip: 0, take: 10};
     
      this.applicationComponentsService.getAppComponentsGridValues(inputRequestObj).subscribe(dataResponse => {
          
          const uIComponentID = dataResponse.metadata.uIComponentID.toUpperCase();
          const responseStatus = dataResponse.metadata.status.toUpperCase();

          if ((responseStatus === 'SUCCESS') && (uIComponentID === 'GET_SERVER_COMPONENT_DETAILS')) {
            if (dataResponse.data.length > 0) {
              this.view = this.applicationComponentsService.pipe(map(data => process(dataResponse.data, this.gridState)));
              this.girdData = dataResponse.data; 
              this.refresh();
            } else {
              this.view = this.applicationComponentsService.pipe(map(data => process([], this.gridState)));
              this.failureMsgPopup.open();
              this.errorMessage = 'Sorry! There are no data available for this search criteria.';
            }

          } else if (responseStatus === 'ERROR') {
            this.view = this.applicationComponentsService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = dataResponse.metadata.errorMsg[0].errorDesc;
          }
          this.isGridLoadingIndicator = false;
          this._sessionTimeout.filter('Session timeout Reset called');
        });
  }

  /**
   * Event will triggered, when the popup module name dorpdown changed
   */
  moduleValueChangeDropDown(dropdownValue) {
    this.loadSelectServerNameDropDown(dropdownValue.moduleName, dropdownValue.moduleId);
    this.loadSelectComponentNameDropDown(dropdownValue.moduleName, dropdownValue.moduleId);
  }

  /**
   * Load the select Module Name dropdown component
   */
  private loadSelectModuleNameDropDown() {
    this.moduleName_loading_indicator = true;
    const selectServerNameRequestObj = { uIComponentID: 'ADMIN_COMPONENT_APP_MODULE_NAME' };
    this.applicationComponentsService.getSelectModuleNameDropDownValues(selectServerNameRequestObj).subscribe(dataResponse => {
      if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_COMPONENT_APP_MODULE_NAME'))) {
        dataResponse.data.forEach(selectModuleNameElement => {
          this.moduleNameItems_popup.push(selectModuleNameElement);
        });
      }
      this.moduleName_loading_indicator = false;
    });
    error => console.log(error);
  }

  /**
   * Load the select Server Name dropdown component
   */
  private loadSelectServerNameDropDown(moduleName, moduleId) {
    this.serverName_loading_indicator = true;
    const selectServerNameRequestObj = {
      'moduleId': moduleId,
      'moduleName': moduleName,
      'uIComponentID': 'ADMIN_COMPONENT_APP_SERVER_NAME'
    };
    this.serverNameItems_popup =[];
    this.applicationComponentsService.getSelectServerNameDropDownValues(selectServerNameRequestObj).subscribe(dataResponse => {
      if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_COMPONENT_APP_SERVER_NAME'))) {
        dataResponse.data.forEach(selectServerNameElement => {
          this.serverNameItems_popup.push(selectServerNameElement);
        });
        this.is_component_server_dropDown_disabled = false;
      }
      this.serverName_loading_indicator = false;
    });
    error => console.log(error);
  }

  /**
   * Load the select Component Name dropdown component
   */
  private loadSelectComponentNameDropDown(moduleName, moduleId) {
    this.componentName_loading_indicator = true;
    const selectComponentNameRequestObj = {
      'moduleId': moduleId,
      'moduleName': moduleName,
      'uIComponentID': 'ADMIN_COMPONENT_APP_COMPONENT_NAME'
    };
    this.componentNameItems_popup =[];
    this.applicationComponentsService.getSelectComponentNameDropDownValues(selectComponentNameRequestObj).subscribe(dataResponse => {
      if (((dataResponse.metadata.status).toUpperCase() === 'SUCCESS') && ((dataResponse.metadata.uIComponentID === 'ADMIN_COMPONENT_APP_COMPONENT_NAME'))) {
        dataResponse.data.forEach(selectComponentNameElement => {
          this.componentNameItems_popup.push(selectComponentNameElement);
        });
        this.is_component_server_dropDown_disabled = false;
      }
      this.componentName_loading_indicator = false;
    });
    error => console.log(error);
  }

  /**
   * Initializing the search component
   */
  buildForm(): void {
    this.appCompForm = this.formBuilder.group({
      'moduleName': [this.applicationComponentsGridComponentObj.moduleName, [Validators.required]],
      'serverName': [this.applicationComponentsGridComponentObj.serverName],
      'componentName': [this.applicationComponentsGridComponentObj.componentName],
      'serverStatus': [this.applicationComponentsGridComponentObj.serverStatus]
    });

    this.appCompForm.valueChanges.subscribe(data => this.onValueChanged(data));

    this.onValueChanged(); // (re)set validation messages now
  }

  onValueChanged(data?: any) {
    if (!this.appCompForm) {
      return;
    }
    const form = this.appCompForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'moduleName': '',
    'serverName': '',
    'componentName': '',
  };

  validationMessages = {
    'moduleName': {
      'required': 'Please select the Module Name'
    },
    'serverName': {
      'required': 'Please select the Server Name'
    },
    'componentName': {
      'required': 'Please select the Component Name'
    }
  };

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.applicationComponentsService.unsubscribe();
  }
}

