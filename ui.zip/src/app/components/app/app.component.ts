import { Component, Inject, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { DashboardAuthGuardUtil } from "../../utils/dashboardAuthGuardUtil";
import { Router } from "@angular/router";
import { AuthContextService } from "../../services/authContext.service";
import { FailureMsgPopupComponent } from "../../widgets/failureMsg-popup.component";
import { SessionTimeoutService } from "../../services/sessionTimeout.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html"
})

/**
 * Application landing component
 **/
export class AppComponent implements OnInit, OnDestroy {
  showHeader: Boolean = true;
  showFooter: Boolean = true;
  public userName;
  public businessUnitName;
  public buId;
  public unitName;
  public userRole;

  // Parent menu items
  public isAdminEnabled = false;
  public isSearchEnabled = false;
  public isRescanEnabled = false;
  public isReportEnabled = false;
  public isBuSupportUnit;

  // Child menu items
  public isBusinessUnitEnabled = false;
  public isCrudConfigEnabled = false;
  public isManageBUEnabled = false;
  public isManageUserEnabled = false;
  public isManageRoleEnabled = false;
  public isManageUserRoleEnabled = false;
  public isManageFunctionEnabled = false;
  public isTnxRescanningEnabled = false;
  public isLogSearchEnabled = false;
  public isSlaReportEnabled = false;
  public isPerformanceManagementReportEnabled = false;
  public isOnDemandReportingEnabled = false;
  public isFofTestDataConfigEnabled = false;
  public isProductionReportEnabled = false;
  public isApplicationComponentsEnabled = false;
  public isUserActivityEnabled = false;
  public isAutoSuspendConfigEnabled = false;
  public isAutoCancellationConfigEnabled = false;
  public isRescreenReconciliationEnabled = false;
  public userNetworkId;
  public isMultiBUAccess;
  public isCustomerSearchEnabled = false;
  public isCustomerResearchEnabled = false;
  public isKYCMenuEnabled = false;

  // Session timeout
  public seconds;
  public minutes;
  public count_seconds;

  public dashboardAuthGuardUtil = new DashboardAuthGuardUtil();
  private authContextService: AuthContextService;

  // Trigger error message popup if the services is throwing an error
  @ViewChild("failureMsgPopup")
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  constructor(
    @Inject(AuthContextService) authContextServiceFactory: any,
    private http: HttpClient,
    private router: Router,
    private sessionTimeoutService: SessionTimeoutService
  ) {
    this.authContextService = authContextServiceFactory();
    this.triggerSessionEvent(sessionTimeoutService);
  }

  public triggerSessionEvent(sessionTimeoutService) {
    sessionTimeoutService.listen().subscribe((m: any) => {
      this.moreTime("OK");
    });
  }

  public ngOnInit(): void {
    this.inactivityTime();
    this.router.events.subscribe(event => this.modifyHeader(event));
    this.loadAuthContextWebService();
    this.disableBackButton();
  }

  disableBackButton() {
    //BackButton disabled for the application
    history.pushState(null, null, location.href);
    window.onpopstate = function(event) {
      history.go(1);
    };
  }

  /* Hide Header and Footer in login page only*/
  modifyHeader(location) {
    if (location.url === "/login") {
      this.showHeader = false;
      this.showFooter = false;
    } else {
      this.showHeader = true;
      this.showFooter = true;
    }
  }

  // Invoke the services call if the session is empty
  invokeContextService(location) {
    const sessionValid = localStorage.getItem("context");
    const role = localStorage.getItem("user_name");
    if (location.url === "/home") {
      if (sessionValid === null || sessionValid === "") {
        this.loadAuthContextWebService();
      }
    }
  }

  loadAuthContextWebService() {
    this.authContextService.getContextService().subscribe(
      response => {
        if (
          response.metadata.status.toUpperCase() === "SUCCESS" &&
          response.metadata.uIComponentID === "OFAC_USER_CONTEXT"
        ) {
          // Storing the values in the session object
          localStorage.setItem("context", JSON.stringify(response));

          // Enabling read and write access for the logged-in user
          this.dashboardAuthGuardUtil.enableReadAndWriteAccess();

          // Getting the values from the context services
          this.userName = response.userInfo.userName.toUpperCase();

          response.context.filter(context => {
            // Getting Business Unit name
            this.businessUnitName = context.bu.buShortName;
            this.buId = context.bu.buId;
            localStorage.setItem(
              "currentBUName",
              JSON.stringify(context.bu.buName)
            );
            localStorage.setItem(
              "currentBUId",
              JSON.stringify(context.bu.buId)
            );
            localStorage.setItem(
              "unitName",
              JSON.stringify(context.bu.unitName)
            );

            if (response.userInfo.buSupportUnit === "Y") {
              this.isBuSupportUnit = true;
            } else {
              this.isBuSupportUnit = false;
            }

            // Passing flag to header component userNetworkID and isMultiBUAccess
            this.userNetworkId = response.userInfo.userNetworkId;
            this.userRole = this.isMultiBUAccess = context.role[0].buRoleName;

            if (response.userInfo.isMultiBUAccess) {
              this.isMultiBUAccess = response.userInfo.isMultiBUAccess;
            } else {
              this.isMultiBUAccess = false;
            }

            // Passing unitName
            this.unitName = context.bu.unitName;

            // Storing the userNetworkId in the session
            localStorage.setItem(
              "userNetworkId",
              JSON.stringify(response.userInfo.userNetworkId)
            );
            localStorage.setItem(
              "isMultiBUAccess",
              JSON.stringify(response.userInfo.isMultiBUAccess)
            );

            this.dashboardAuthGuardUtil
              .roleMappingWithFunction(context)
              .filter(dashboardUIMenu => {
                if (dashboardUIMenu === "isCrudConfigEnabled") {
                  this.isCrudConfigEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isApplicationComponentsEnabled" ) {
                  this.isApplicationComponentsEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isFofTestDataConfigEnabled") {
                  this.isFofTestDataConfigEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isManageBUEnabled") {
                  this.isManageBUEnabled = true;
                  this.isBusinessUnitEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isManageUserEnabled") {
                  this.isManageUserEnabled = true;
                  this.isBusinessUnitEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isManageRoleEnabled") {
                  this.isManageRoleEnabled = true;
                  this.isBusinessUnitEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isManageUserRoleEnabled") {
                  this.isManageUserRoleEnabled = true;
                  this.isBusinessUnitEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isManageFunctionEnabled") {
                  this.isManageFunctionEnabled = true;
                  this.isBusinessUnitEnabled = true;
                  this.isAdminEnabled = true;
                } else if (dashboardUIMenu === "isTnxRescanningEnabled") {
                  this.isTnxRescanningEnabled = true;
                  this.isRescanEnabled = true;
                } else if (dashboardUIMenu === "isLogSearchEnabled") {
                  this.isLogSearchEnabled = true;
                  this.isSearchEnabled = true;
                } else if (dashboardUIMenu === "isSlaEnabled") {
                  this.isReportEnabled = true;
                  this.isSlaReportEnabled = true;
                } else if (dashboardUIMenu === "isPerformanceManagementReportEnabled") {
                  this.isReportEnabled = true;
                  this.isPerformanceManagementReportEnabled = true;
                } else if (dashboardUIMenu === "isOnDemandReportingEnabled") {
                  this.isReportEnabled = true;
                  this.isOnDemandReportingEnabled = true;
                } else if (dashboardUIMenu === "isProductionReportEnabled") {
                  this.isReportEnabled = true;
                  this.isProductionReportEnabled = true;
                } else if (dashboardUIMenu === "isUserActivityEventEnabled") {
                  this.isUserActivityEnabled = true;
                  this.isSearchEnabled = true;
                } else if (dashboardUIMenu === "isAutoSuspendConfigEnabled") {
                  this.isAutoSuspendConfigEnabled = true;
                  this.isAdminEnabled = true;
                }else if (dashboardUIMenu === "isAutoCancellationConfigEnabled") {
                  this.isAutoCancellationConfigEnabled = true;
                  this.isAdminEnabled = true;
                }else if (dashboardUIMenu === "isRescreenReconciliationEnabled") {
                  this.isRescanEnabled = true;
                  this.isRescreenReconciliationEnabled = true;
                }else if (dashboardUIMenu === "isCustomerSearchEnabled") {
                  this.isKYCMenuEnabled = true;
                  this.isCustomerSearchEnabled = true;
                }else if (dashboardUIMenu === "isCustomerResearchEnabled") {
                  this.isKYCMenuEnabled = true;
                  this.isCustomerResearchEnabled = true;
                } 
              });
          });
        } else if (response.metadata.status.toUpperCase() === "ERROR") {
          this.dashboardAuthGuardUtil.enableReadAndWriteAccess();
          localStorage.clear();
          this.failureMsgPopup.open();
          this.errorMessage = response.metadata.errorMsg[0].errorDesc;
        }
      },
      error => {
        this.dashboardAuthGuardUtil.enableReadAndWriteAccess();
        localStorage.clear();
        this.failureMsgPopup.open();
        this.errorMessage = error.message;
      }
    );
  }

  // If the user is idle for 30 minutes then the page will redirected to session timeout page.
  public inactivityTime() {
    const _this = this;

    // Capturing user active or inactive
    const countDownDate = new Date();
    countDownDate.setMinutes(countDownDate.getMinutes() + 30);

    _this.count_seconds = setInterval(function() {
      // Get todays date and time
      const now = new Date().getTime();
      const distance = countDownDate.getTime() - now;

      // Time calculations for days, hours, minutes and seconds
      _this.minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      _this.seconds = Math.floor((distance % (1000 * 60)) / 1000);

      if (distance < 0) {
        clearInterval(_this.count_seconds);
        localStorage.clear();
        window.location.href =
          "/rtss/logout.jsp?end_url=/rtss/logoutconfirmation.jsp";
      }
    }, 1000);

    function resetTimer() {
      clearInterval(_this.count_seconds);
      _this.inactivityTime();
    }
  }

  /**
   * Triggering the backend and UI session timeout
   * NO - UI widget values, OK - If any web services call success
   * @param status
   */
  public moreTime(status) {
    if (status.toUpperCase() === "NO" || status.toUpperCase() === "OK") {
      clearTimeout(this.count_seconds);
      this.inactivityTime();
      if (status.toUpperCase() !== "OK") {
        this.resetToBackendSystem();
      }
    }
  }

  resetToBackendSystem() {
    this.authContextService.resetSessionTimeout().subscribe(response => {
      console.log("Session reset request = " + response);
    });
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.authContextService.unsubscribe();
  }
}
