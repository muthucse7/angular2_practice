/**
 * Angular2 components imports
 */
import { BrowserModule } from "@angular/platform-browser";
import { NgModule, OnInit } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import {
  HttpClient,
  HttpClientModule,
  HttpClientJsonpModule
} from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { DatePipe } from "@angular/common";
import { APP_BASE_HREF } from "@angular/common";
import { MomentModule } from "angular2-moment";
import { MomentTimezoneModule } from "angular-moment-timezone";

/**
 * KendoUI components imports
 */
import { DialogModule } from "@progress/kendo-angular-dialog";
import {
  GridModule,
  PDFModule,
  ExcelModule
} from "@progress/kendo-angular-grid";
import "hammerjs";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { UploadModule } from "@progress/kendo-angular-upload";
import { IntlModule } from "@progress/kendo-angular-intl";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { NumericTextBoxModule } from "@progress/kendo-angular-inputs";
import { DropDownListModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { PopupModule } from "@progress/kendo-angular-popup";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { RippleModule } from "@progress/kendo-angular-ripple";
import { DialogsModule } from "@progress/kendo-angular-dialog";

/**
 * Custom components imports
 */
import { AppComponent } from "./app.component";
import { ApplicationConfigurationComponent } from "../admin/applicationConfiguration/applicationConfiguration.component";
import { PopupAnchorDirective } from "../directive/popup.anchor-target.directive";
import { FooterComponent } from "../../widgets/footer.component";
import { HeaderComponent } from "../../widgets/header.component";
import { ManageBUComponent } from "../admin/manageBusinessUnits/manageBU/manageBU.component";
import { ApplicationConfigurationPopupComponent } from "../admin/applicationConfiguration/applicationConfigurationPopup.component";
import { SuccessMsgPopupComponent } from "../../widgets/successMsg-popup.component";
import { FailureMsgPopupComponent } from "../../widgets/failureMsg-popup.component";
import { GridBUEditFormComponent } from "../admin/manageBusinessUnits/manageBU/edit-manageBU.component";
import { ManageRoleComponent } from "../admin/manageBusinessUnits/manageRole/manageRole.component";
import { ManageFunctionComponent } from "../admin/manageBusinessUnits/manageFunction/manageFunction.component";
import { ManageUserComponent } from "../admin/manageBusinessUnits/manageUser/manageUser.component";
import { ManageUserRoleComponent } from "../admin/manageBusinessUnits/manageUserRole/manageUserRole.component";
import { AddManageRoleComponent } from "../admin/manageBusinessUnits/manageRole/add-manageRole.component";
import { AddManageFunctionComponent } from "../admin/manageBusinessUnits/manageFunction/add-manageFunction.component";
import { AddManageUserRoleComponent } from "../admin/manageBusinessUnits/manageUserRole/add-manageUserRole.component";
import { AddManageUserComponent } from "../admin/manageBusinessUnits/manageUser/add-manageUser.component";
import { TnxRescanningComponent } from "../rescan/transactionRescanning/tnxRescanning.component";
import { LogSearchComponent } from "../search/logSearch/logSearch.component";
import { HomeComponent } from "../home/home.component";
import { SlaReportComponent } from "../report/slaReport/slaReport.component";
import { PerformanceManagementReportComponent } from "../report/performanceManagementReport/performanceManagementReport.component";
import { DonutChartComponent } from "../../widgets/charts/donut-chart/donut-chart.component";
import { PieChartComponent } from "../../widgets/charts/piechart/pie-chart.component";
import { AppServerMonitoringComponent } from "../home/gridLayouts/prodSupportGridLayouts/appServerMonitoring/appServerMonitoring.component";
import { AppServerDetailsPopup } from "../home/gridLayouts/prodSupportGridLayouts/appServerMonitoring/appServerDetailsPopup.component";
import { DailyOverallSummaryComponent } from "../home/gridLayouts/coeGridLayouts/dailyOverallSummary/dailyOverallSummary.component";
import { BatchServerMonitoringComponent } from "../home/gridLayouts/prodSupportGridLayouts/batchServerMonitoring/batchServerMonitoring.component";
import { ListManagementComponent } from "../home/gridLayouts/coeGridLayouts/listManagement/listManagement.component";
import { ListManagementKZComponent } from "../home/gridLayouts/coeGridLayouts/listManagementKZ/listManagementKZ.component";
import { OnDemandReportingComponent } from "../report/demand/onDemandReporting.component";
import { BarChartComponent } from "../../widgets/charts/bar-chart/bar-chart.component";
import { BarChartSeriesComponent } from "../../widgets/charts/bar-chart-series-type/bar-chart-series.component";
import { RescanStatusCompletedComponent } from "../rescan/transactionRescanning/rescanStatusCompleted.component";
import { FofTestConfigurationComponent } from "../admin/fofTestConfiguration/fofTestConfiguration.component";
import { FofTestConfigurationPopupComponent } from "../admin/fofTestConfiguration/fofTestConfigurationPopup.component";
import { ProductionReportComponent } from "../report/productionReport/productionReport.component";
import { LineChartComponent } from "../../widgets/charts/line-chart/lineChart.component";
import { MultiBarChartComponent } from "../../widgets/charts/multiBarChart/multiBar-chart.component";
import { ApplicationComponentsComponent } from "../admin/applicationComponents/applicationComponents.component";
import { ApplicationComponentsPopupComponent } from "../admin/applicationComponents/applicationComponentsPopup.component";
import { UserActivityEventComponent } from "../search/userActivityEvent/userActivityEvent.component";
import { AutoSuspendConfigComponent } from "../admin/autoSuspendConfiguration/autoSuspendConfig.component";
import { AutoCancellationConfigComponent } from "../admin/autoCancellationConfiguration/autoCancellationConfig.component";
import { AutoSuspendEditPopupComponent } from "../admin/autoSuspendConfiguration/autoSuspendEditPopup.component";
import { AutoCancellationEditPopupComponent } from "../admin/autoCancellationConfiguration/autoCancellationEditPopup.component";
import { RescreenReconciliationComponent } from "../rescan/rescreenReconciliation/rescreenReconciliation.component";
import { CustomerSearchComponent } from "../kyc/customerSearch/customerSearch.component";
import { CustomerResearchComponent } from "../kyc/customerResearch/customerResearch.component";

/**
 * Service layer imports
 */
import { ApplicationConfigurationService } from "../../services/applicationConfiguration.service";
import { ManageBUService } from "../../services/manageBU.service";
import { ManageRoleService } from "../../services/manageRole.service";
import { ManageFunctionService } from "../../services/manageFunction.service";
import { ManageUserService } from "../../services/manageUser.service";
import { ManageUserRoleService } from "../../services/manageUserRole.service";
import { TnxRescanningService } from "../../services/tnxRescanning.service";
import { LogSearchService } from "../../services/logSearch.service";
import { AuthContextService } from "../../services/authContext.service";
import { OnDemandReportingService } from "../../services/onDemandReporting.service";
import { FofTestConfigurationService } from "../../services/fofTestConfiguration.service";
import { ProductionReportService } from "../../services/productionReport.service";
import { ApplicationComponentsService } from "../../services/applicationComponents.service";
import { UserActivityEventService } from "../../services/userActivityEvent.service";
import { AutoSuspendConfigService } from "../../services/autoSuspendConfig.service"
import { AutoCancellationConfigService } from "../../services/autoCancellationConfig.service";
import { RescreenReconciliationService } from "../../services/rescreenReconciliation.service";
import { CustomerSearchService } from "../../services/customerSearch.service";
/**
 * AUTH Guard imports
 */
import { SlaReportService } from "../../services/slaReport.service";
import { PerformanceManagementReportService } from "../../services/performanceManagementReport.service";
import { SessionTimeoutService } from "../../services/sessionTimeout.service";
import { ChartsModule } from "@progress/kendo-angular-charts";
import { HomeService } from "../../services/home.service";
/**
 * @type {({path: string; component: LoginComponent} | {path: string; component: DailyOverallSummaryComponent} | {path: string; component: AppServerMonitoringComponent} | {path: string; component: ApplicationConfigurationComponent} | {path: string; component: UploadComponent})[]}
 */
const appRoutes: Routes = [
  { path: "crudConfig", component: ApplicationConfigurationComponent },
  { path: "manageBU", component: ManageBUComponent },
  { path: "manageRole", component: ManageRoleComponent },
  { path: "manageFunction", component: ManageFunctionComponent },
  { path: "manageUserRole", component: ManageUserRoleComponent },
  { path: "manageUser", component: ManageUserComponent },
  { path: "tnxRescanning", component: TnxRescanningComponent },
  { path: "logSearch", component: LogSearchComponent },
  { path: "slaReport", component: SlaReportComponent },
  {
    path: "performanceManagementReport",
    component: PerformanceManagementReportComponent
  },
  { path: "onDemandReporting", component: OnDemandReportingComponent },
  { path: "fofTestDataConfig", component: FofTestConfigurationComponent },
  { path: "productionReport", component: ProductionReportComponent },
  { path: "applicationComponents", component: ApplicationComponentsComponent },
  { path: "userActivityEvent", component: UserActivityEventComponent},
  { path: "autoSuspendConfig", component: AutoSuspendConfigComponent},
  { path: "autoCancellationConfig", component: AutoCancellationConfigComponent},
  { path: "rescreenRecon", component: RescreenReconciliationComponent},
  { path: "customerSearch", component: CustomerSearchComponent},
  { path: "customerResearch", component: CustomerResearchComponent},
  { path: "**", component: CustomerResearchComponent }
];

/***
 * NgModule component and services import
 */
@NgModule({
  declarations: [
    AppComponent,
    ApplicationConfigurationComponent,
    PopupAnchorDirective,
    FooterComponent,
    HeaderComponent,
    ManageBUComponent,
    ApplicationConfigurationPopupComponent,
    SuccessMsgPopupComponent,
    FailureMsgPopupComponent,
    GridBUEditFormComponent,
    ManageRoleComponent,
    ManageFunctionComponent,
    ManageUserComponent,
    ManageUserRoleComponent,
    AddManageRoleComponent,
    AddManageFunctionComponent,
    AddManageUserRoleComponent,
    AddManageUserComponent,
    TnxRescanningComponent,
    LogSearchComponent,
    HomeComponent,
    SlaReportComponent,
    PerformanceManagementReportComponent,
    DonutChartComponent,
    PieChartComponent,
    DailyOverallSummaryComponent,
    AppServerMonitoringComponent,
    AppServerDetailsPopup,
    BatchServerMonitoringComponent,
    ListManagementComponent,
    ListManagementKZComponent,
    OnDemandReportingComponent,
    BarChartComponent,
    BarChartSeriesComponent,
    RescanStatusCompletedComponent,
    FofTestConfigurationComponent,
    ProductionReportComponent,
    LineChartComponent,
    FofTestConfigurationPopupComponent,
    MultiBarChartComponent,
    ApplicationComponentsComponent,
    ApplicationComponentsPopupComponent,
    UserActivityEventComponent,
    AutoSuspendConfigComponent,
    AutoCancellationConfigComponent,
    AutoSuspendEditPopupComponent,
    AutoCancellationEditPopupComponent,
    RescreenReconciliationComponent,
    CustomerSearchComponent,
    CustomerResearchComponent
  ],

  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    ReactiveFormsModule,
    DialogModule,
    GridModule,
    ButtonsModule,
    LayoutModule,
    UploadModule,
    FormsModule,
    IntlModule,
    DateInputsModule,
    NumericTextBoxModule,
    DropDownListModule,
    InputsModule,
    PopupModule,
    DropDownsModule,
    RouterModule,
    RippleModule,
    DialogsModule,
    PDFModule,
    ExcelModule,
    ChartsModule,
    MomentModule,
    MomentTimezoneModule
  ],
  providers: [
    {
      provide: APP_BASE_HREF,
      useValue: "/rtss/app/dashboard/"
    },
    SessionTimeoutService,
    {
      deps: [HttpClient],
      provide: ApplicationConfigurationService,
      useFactory: (jsonp: HttpClient) => () =>
        new ApplicationConfigurationService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ManageBUService,
      useFactory: (jsonp: HttpClient) => () => new ManageBUService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ManageRoleService,
      useFactory: (jsonp: HttpClient) => () => new ManageRoleService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ManageFunctionService,
      useFactory: (jsonp: HttpClient) => () => new ManageFunctionService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ManageUserService,
      useFactory: (jsonp: HttpClient) => () => new ManageUserService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ManageUserRoleService,
      useFactory: (jsonp: HttpClient) => () => new ManageUserRoleService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: TnxRescanningService,
      useFactory: (jsonp: HttpClient) => () => new TnxRescanningService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: LogSearchService,
      useFactory: (jsonp: HttpClient) => () => new LogSearchService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: AuthContextService,
      useFactory: (jsonp: HttpClient) => () => new AuthContextService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: PerformanceManagementReportService,
      useFactory: (jsonp: HttpClient) => () =>
        new PerformanceManagementReportService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: SlaReportService,
      useFactory: (jsonp: HttpClient) => () => new SlaReportService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: OnDemandReportingService,
      useFactory: (jsonp: HttpClient) => () =>
        new OnDemandReportingService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: HomeService,
      useFactory: (jsonp: HttpClient) => () => new HomeService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: FofTestConfigurationService,
      useFactory: (jsonp: HttpClient) => () =>
        new FofTestConfigurationService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ProductionReportService,
      useFactory: (jsonp: HttpClient) => () =>
        new ProductionReportService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: ApplicationComponentsService,
      useFactory: (jsonp: HttpClient) => () =>
        new ApplicationComponentsService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: UserActivityEventService,
      useFactory: (jsonp: HttpClient) => () => new UserActivityEventService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: AutoSuspendConfigService,
      useFactory: (jsonp: HttpClient) => () => new AutoSuspendConfigService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: AutoCancellationConfigService,
      useFactory: (jsonp: HttpClient) => () => new AutoCancellationConfigService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: RescreenReconciliationService,
      useFactory: (jsonp: HttpClient) => () => new RescreenReconciliationService(jsonp)
    },
    {
      deps: [HttpClient],
      provide: CustomerSearchService,
      useFactory: (jsonp: HttpClient) => () => new CustomerSearchService(jsonp)
    },
    DatePipe
  ],

  bootstrap: [AppComponent]
})
export class AppModule {}
