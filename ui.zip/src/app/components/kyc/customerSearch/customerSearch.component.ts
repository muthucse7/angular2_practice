import { Component, OnInit, OnDestroy, Inject, ViewChild } from '@angular/core';
import { CustomerSearchService } from '../../../services/customerSearch.service';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerSearchFromModel } from '../../../models/customerSearch/customerSearchFromModel';


@Component({
  selector: 'customerSearch',
  templateUrl: './customerSearch.component.html'
})

export class CustomerSearchComponent implements OnInit, OnDestroy {

  public customerSearchService: CustomerSearchService;
  public listOfCustomerProfiles: any[];
  public isCustomerProfileSectionDisplayed: boolean = true;
  public customerSearchForm: FormGroup;
  public error: any = { isError: false, errorMessage: '' };
  private customerSearchFromModel = new CustomerSearchFromModel();
  public isGridLoadingIndicator: Boolean = false;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  constructor(@Inject(CustomerSearchService) customerSearchServiceServiceFactory: any, private formBuilder: FormBuilder) {
    this.customerSearchService = customerSearchServiceServiceFactory();
  }

  public ngOnInit(): void {
    this.initiateCustomerSearchForm();
  }

  // Customer Search validation and error message 
  initiateCustomerSearchForm(): void {
    this.customerSearchForm = this.formBuilder.group({
      'customerName': [this.customerSearchFromModel.customerName, [Validators.required]],
      'accountNo': [this.customerSearchFromModel.accountNo, [Validators.maxLength(20)]],
      'ssnTin': [this.customerSearchFromModel.ssnTin, [Validators.maxLength(10)]]
    });
    this.customerSearchForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }


  onValueChanged(data?: any) {
    if (!this.customerSearchForm) {
      return;
    }
    const form = this.customerSearchForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'customerName': ''
  };

  validationMessages = {
    'customerName': {
      'required': 'Please Customer Name'
    }
  };


  // Reset the search form and cutomer values
  public resetMe() {
    this.isCustomerProfileSectionDisplayed = true;
    this.isGridLoadingIndicator = false;

  }

  // Onclick event from search button
  public onCustomerSearch(): void {
    if (this.customerSearchForm.valid) {
      let name = this.customerSearchForm.controls.customerName.value;
      let accountNo = this.customerSearchForm.controls.accountNo.value;
      let ssnOrtin = this.customerSearchForm.controls.ssnTin.value;

      if(accountNo=='' && accountNo==null){
        accountNo = "";
      }
      if(ssnOrtin=='' && ssnOrtin==null){
        ssnOrtin = "";
      }
     
      let inputRequestObj = {
        'name':name,
        'accountNo': accountNo,
        'ssnOrTin': ssnOrtin
      };

      this.isGridLoadingIndicator = true;
      this.getCustomerProfile(inputRequestObj);
    }
  }

  // Get the customer details based on the filter
  public getCustomerProfile(requestObj) {
    this.customerSearchService.getCustomerProfile(requestObj).subscribe(customerProfileData => {
      if (((customerProfileData.metadata.status).toUpperCase() === 'SUCCESS') && ((customerProfileData.metadata.uIComponentID === 'CUSTOMER_SEARCH'))) {
        if (customerProfileData.data.length > 0) {
          this.isCustomerProfileSectionDisplayed = false;
          this.listOfCustomerProfiles = customerProfileData.data;
        }
      } else if ((customerProfileData.metadata.status).toUpperCase() === 'ERROR') {
        this.failureMsgPopup.open();
        this.errorMessage = customerProfileData.metadata.errorMsg[0].errorDesc;
      }
      this.isGridLoadingIndicator = false;
    });
  }

  // Copy Clipboard
  copyMessage(section, index) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = this.getSelectTextData(section, index);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  // Get the HTML DOM objects for Clipboard
  private getSelectTextData(section, i) {
    let clipboardText = "";
    if (section === 'CUSTOMER_DETAILS') {
      let _name = "Full Name: " + document.getElementById("cust_name_" + i).innerHTML;
      let _altName = "Alternative Name: " + document.getElementById("cust_altName_" + i).innerHTML;
      let _occupation = "Occupation: " + document.getElementById("cust_occupation_" + i).innerHTML;
      let _nationality = "Nationality: " + document.getElementById("cust_nationality_" + i).innerHTML;
      let _dob = "Nationality: " + document.getElementById("cust_dob_" + i).innerHTML;
      clipboardText = "Customer Details" + " = " + _name + " | " + _altName + " | " + _occupation + " | " + _nationality + " | " + _dob;
   
    } else if (section === 'CUSTOMER_ID') {
      let _ssnOrTin = "Customer ID = " + "SSN/TIN: " + document.getElementById("cust_ssnOrTin_" + i).innerHTML;
      clipboardText = _ssnOrTin;
 
    } else if (section === 'CUSTOMER_CONTACT_DETAILS') {
      let _address1 = "Address 1: " + document.getElementById("cust_address1_" + i).innerHTML;
      let _address2 = "Address 2: " + document.getElementById("cust_address2_" + i).innerHTML;
      let _address3 = "Address 3: " + document.getElementById("cust_address3_" + i).innerHTML;
      let _address4 = "Address 4: " + document.getElementById("cust_address4_" + i).innerHTML;
      let _workPhone = "Work Phone: " + document.getElementById("cust_workPhone_" + i).innerHTML;
      let _homePhone = "Home Phone: " + document.getElementById("cust_homePhone_" + i).innerHTML;
      let _contactPhone = "Contact Phone: " + document.getElementById("cust_contactPhone_" + i).innerHTML;
      let _mobilePhone = "Mobile Phone: " + document.getElementById("cust_mobilePhone_" + i).innerHTML;
      clipboardText = "Contact Details = " + _address1 + " | " + _address2 + " | " + _address3 + " | " + _address4 + " | " + _workPhone + " | " + _homePhone + " | " + _contactPhone + " | " + _mobilePhone;
   
    } else if (section === 'USB_RELATIONSHIP') {
      let _bankIdNo = "Bank ID No: " + document.getElementById("cust_bankIdNo_" + i).innerHTML;
      let _productNo = "Product No: " + document.getElementById("cust_productNo_" + i).innerHTML;
      let _accountNo = "Account No: " + document.getElementById("cust_accountNo_" + i).innerHTML;
      let _branhcCostCtr = "Branhc Cost Ctr: " + document.getElementById("cust_branhcCostCtr_" + i).innerHTML;
      let _kycName = "KYC Name: " + document.getElementById("cust_kycName_" + i).innerHTML;
      clipboardText = "U.S Bank Relationship = " + _bankIdNo + " | " + _productNo + " | " + _accountNo + " | " + _branhcCostCtr + " | " + _kycName;

    } else if (section === 'NON_USA_CITIZEN_COUNTRIES') {
      let _nonUsaCitizenCntry1 = "Non USA Citizen Counntry 1: " + document.getElementById("cust_nonUsaCitizenCntry1_" + i).innerHTML;
      let _nonUsaCitizenCntry2 = "Non USA Citizen Counntry 2: " + document.getElementById("cust_nonUsaCitizenCntry2_" + i).innerHTML;
      let _nonUsaCitizenCntry3 = "Non USA Citizen Counntry 3: " + document.getElementById("cust_nonUsaCitizenCntry3_" + i).innerHTML;
      let _nonUsaCitizenCntry4 = "Non USA Citizen Counntry 4: " + document.getElementById("cust_nonUsaCitizenCntry4_" + i).innerHTML;
      let _nonUsaCitizenCntry5 = "Non USA Citizen Counntry 5: " + document.getElementById("cust_nonUsaCitizenCntry5_" + i).innerHTML;
      let _cntryOfPrimaryRes = "Country Of Primary Residence: " + document.getElementById("cust_cntryOfPrimaryRes_" + i).innerHTML;
      let _cntryOfAddRes1 = "Country Of Add Residence 1: " + document.getElementById("cust_cntryOfAddRes1_" + i).innerHTML;
      let _cntryOfAddRes2 = "Country Of Add Residence 2: " + document.getElementById("cust_cntryOfAddRes2_" + i).innerHTML;
      let _cntryOfAddRes3 = "Country Of Add Residence 3: " + document.getElementById("cust_cntryOfAddRes3_" + i).innerHTML;
      let _cntryOfAddRes4 = "Country Of Add Residence 4: " + document.getElementById("cust_cntryOfAddRes4_" + i).innerHTML;
      let _cntryOfAddRes5 = "Country Of Add Residence 5: " + document.getElementById("cust_cntryOfAddRes5_" + i).innerHTML;
      clipboardText = "Non USA Citizen Countries = " + _nonUsaCitizenCntry1 + " | " + _nonUsaCitizenCntry2 + " | " + _nonUsaCitizenCntry3 + " | " + _nonUsaCitizenCntry4 + " | " + _nonUsaCitizenCntry5 + " | " + _cntryOfPrimaryRes + " | " + _cntryOfAddRes1 + " | " + _cntryOfAddRes2 + " | " + _cntryOfAddRes3 + " | " + _cntryOfAddRes4 + " | " + _cntryOfAddRes5;
    }

    return clipboardText;
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {

  }

}
