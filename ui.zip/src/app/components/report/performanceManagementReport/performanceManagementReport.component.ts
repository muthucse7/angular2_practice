import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  ChangeDetectorRef,
  ViewChild,
  ViewEncapsulation,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { map } from 'rxjs/operators/map';
import { State, process } from '@progress/kendo-data-query';
import { IntradayReportComponentModel } from '../../../models/report/intraday/intradayReportComponentModel';
import { PerformanceManagementReportService } from '../../../services/performanceManagementReport.service';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { tap } from 'rxjs/operators';
import { DashBoardUtil } from '../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';
import * as moment from 'moment';



@Component({
  selector: 'performanceManagementReport',
  templateUrl: './performanceManagementReport.component.html',
  encapsulation: ViewEncapsulation.None

})
export class PerformanceManagementReportComponent implements OnInit, OnDestroy {

  intradayReportForm: FormGroup;
  active = true;
  intradayReportComponentsObj = new IntradayReportComponentModel();
  private girdData: any[] = [];
  public error: any = { isError: false, errorMessage: '' };

  public title = 'Performance Management Report';
  public intrdayReportMapping: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  private intradayReportService: PerformanceManagementReportService;
  public dashBoardUtil = new DashBoardUtil();

  public selectBUItems: Array<SelectBUDropdownModel> = [{ buName: 'ALL', buId: 0 }];
  public selectBU_selectedValue: SelectBUDropdownModel = { buName: 'ALL', buId: 0 };
  public defaultItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: -1 };
  public operatorSelectedValue: String;

  public buDropdown_loading_indicator: Boolean = false;

  public userNetworkId;
  public isGridLoadingIndicator: Boolean = false;
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');
  public todaysDate = new DashBoardUtil().getCurrDate_MMDDYYYY_format();


  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(PerformanceManagementReportService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.intradayReportService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.initializeReportForm();
    this.loadSelectBUDropDown();
  }

  private initializeReportForm() {
    this.intradayReportForm = this.formBuilder.group({
      'selectBU': [this.intradayReportComponentsObj.selectBU, [Validators.required]],
      'operatorId': [this.intradayReportComponentsObj.operatorId]
    });
    this.intradayReportForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }


  onValueChanged(data?: any) {
    if (!this.intradayReportForm) {
      return;
    }
    const form = this.intradayReportForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'selectBU': ''
  };

  validationMessages = {
    'selectBU': {
      'required': 'Please select the selectBU'
    }
  };

  public onStateChange(state: State) {
    this.gridState = state;
    //this.generateReport();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.intrdayReportMapping = this.intradayReportService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    // Getting selected values for exporting the XL 
    let selectedbuName = this.selectBU_selectedValue.buName;
    let inputGenerateReportObj;

    if(selectedbuName === 'ALL'){
      selectedbuName = 'all';
    }
    
    if (this.operatorSelectedValue !== null && this.operatorSelectedValue !== '' && this.operatorSelectedValue !== undefined) {
      inputGenerateReportObj = {
        'buName': selectedbuName,
        'operatorId': this.operatorSelectedValue,
        'uIComponentID': 'INTRA_DAY_QUALITY_REPORT'
      };
    } else {
      inputGenerateReportObj = {
        'buName': selectedbuName,
        'uIComponentID': 'INTRA_DAY_QUALITY_REPORT'
      };
    }

    //this.getIntradayReportComponent(inputGenerateReportObj);
    return this.intradayReportService.exportAll(inputGenerateReportObj).pipe(
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  };

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }


  /**
   * SHOW DATA IN GRID ON GENERATE REPORT
   */
  public generateReport() {
    if (this.intradayReportForm.valid) {
      this.intradayReportComponentsObj = this.intradayReportForm.value;
      let buName = this.intradayReportForm.controls.selectBU.value.buName;
      let buId = this.intradayReportForm.controls.selectBU.value.buId;

      const operatorId = this.intradayReportComponentsObj.operatorId;

      if (buName === 'ALL') {
        buName = 'all';
      }

      if (buId == -1) {
        this.intradayReportForm.markAsDirty({});
        this.formErrors['selectBU'] = 'Please select the selectBU';
        return;
      } else {
        this.formErrors['selectBU'] = '';
      }

      /**
       * Request Obj
       * @type {{buName: any; operatorId: any}}
       */
      let inputGenerateReportObj;
      if (operatorId !== null && operatorId !== '' && operatorId !== undefined) {
        inputGenerateReportObj = {
          'buName': buName,
          'operatorId': operatorId,
          'uIComponentID': 'INTRA_DAY_QUALITY_REPORT'
        };
      } else {
        inputGenerateReportObj = {
          'buName': buName,
          'uIComponentID': 'INTRA_DAY_QUALITY_REPORT'
        };
      }
      // Invoking the services call to get the grid data values
      this.getIntradayReportComponent(inputGenerateReportObj);

    }
  }

  /**
   * To generate intraday report
   * @param inputSearchReqObj
   */
  getIntradayReportComponent(inputGenerateReportObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = {sort: [], skip: 0, take: 10};

    this.intradayReportService.getIntradayReportComponentGridValues(inputGenerateReportObj).pipe(
      tap(res => {
        this.girdData = res.data;
      })).subscribe(res => {
        if (((res.metadata.status).toUpperCase() === 'SUCCESS') && ((res.metadata.uIComponentID === 'INTRA_DAY_QUALITY_REPORT'))) {

          if (res.data.length > 0) {
            this.intrdayReportMapping = this.intradayReportService.pipe(map(data => process(res.data, this.gridState)));
          } else {
            this.intrdayReportMapping = this.intradayReportService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((res.metadata.status).toUpperCase() === 'ERROR') {
          this.intrdayReportMapping = this.intradayReportService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = res.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });

  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.intradayReportService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

  // TO GET BU ID OF DROPDOWN SELECTED VALUE
  public stateChangeBUDropDown() {
    return this.selectBU_selectedValue.buId;
  }

  /**
   * INTRADAY REPORT RESET VALIDATION FORM
   * @param fb
   */
  public resetMe(fb) {
    this.intradayReportForm.reset();
    this.isGridLoadingIndicator = false;
    this.intrdayReportMapping = this.intradayReportService.pipe(map(data => process([], this.gridState)));
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.intradayReportService.unsubscribe();
  }

}
