import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  ChangeDetectorRef,
  ViewChild,
  ViewEncapsulation,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { map } from 'rxjs/operators/map';
import { State, process } from '@progress/kendo-data-query';
import { OnDemandReportComponentModel } from '../../../models/report/demand/onDemandReportComponentModel';
import { OnDemandReportingService } from '../../../services/onDemandReporting.service';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { tap } from 'rxjs/operators';
import * as moment from 'moment';
import { DashBoardUtil } from '../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';


@Component({
  selector: 'onDemandReporting',
  templateUrl: './onDemandReporting.component.html',
  encapsulation: ViewEncapsulation.None
})

export class OnDemandReportingComponent implements OnInit, OnDestroy {
  onDemandReportForm: FormGroup;
  active = true;
  onDemandReportComponentsObj = new OnDemandReportComponentModel();
  private girdData: any[] = [];

  public title = 'On Demand Reporting';
  public onDemandReportMapping: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 1, take: 10 };
  private onDemandReportingService: OnDemandReportingService;
  public dashBoardUtil = new DashBoardUtil();

  public selectBUItems: Array<SelectBUDropdownModel> = [{ buName: 'ALL', buId: 0 }];
  public selectBU_selectedValue: SelectBUDropdownModel = { buName: 'ALL', buId: 0 };
  public defaultItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: -1 };

  public selectOperatorIdItems: Array<SelectOperatorDropdownModel> = [{ operatorId: 'all', operatorName: 'ALL' }];
  public selectOperatorId_selectedValue: SelectOperatorDropdownModel = { operatorId: 'all', operatorName: 'ALL' };
  public defaultOperatorId: SelectOperatorDropdownModel = { operatorId: 'placeholder', operatorName: 'Please select operator Id' };

  public selectStateItems: Array<SelectStateDropdownModel> = [{ remidiationStatus: 'ALL', remidiationStatusId: 0 }];
  public selectState_selectedValue: SelectStateDropdownModel = { remidiationStatus: 'ALL', remidiationStatusId: 0 };
  public defaultState: SelectStateDropdownModel = { remidiationStatus: 'Please select state', remidiationStatusId: -1 };

  public startTime;
  public endTime;
  public endDateMaxTime;

  public buDropdown_loading_indicator: Boolean = false;
  public operator_loading_indicator: Boolean = false;
  public state_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  public todaysDate = new DashBoardUtil().getCurrDate_MMDDYYYY_format();
  public userNetworkId;

  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(OnDemandReportingService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.onDemandReportingService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.endDateMaxTime = new Date(moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'));
    this.initializeReportForm();
    this.loadSelectBUDropDown();
    this.loadOperatorDropDown();
    this.loadStateDropDown();
  }

  private initializeReportForm() {
    this.onDemandReportForm = this.formBuilder.group({
      'selectBU': [this.onDemandReportComponentsObj.selectBU, [Validators.required]],
      'operatorId': [this.onDemandReportComponentsObj.operatorId, [Validators.required]],
      'state': [this.onDemandReportComponentsObj.stateId, [Validators.required]],
      'startTime': [this.onDemandReportComponentsObj.startTime],
      'endTime': [this.onDemandReportComponentsObj.endTime]
    });
    this.onDemandReportForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    if (!this.onDemandReportForm) {
      return;
    }
    const form = this.onDemandReportForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'selectBU': '',
    'operatorId': '',
    'state': ''
  };

  validationMessages = {
    'selectBU': {
      'required': 'Please select the selectBU'
    },
    'operatorId': {
      'required': 'Please select the operatorId'
    },
    'state': {
      'required': 'Please select the state'
    }
  };

  public onStateChange(state: State) {
    this.gridState = state;
    //this.generateReport();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.onDemandReportMapping = this.onDemandReportingService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    // Getting selected values for exporting the XL 
    let selectedbuName = this.selectBU_selectedValue.buName;
    let selectedoperatorId = this.selectOperatorId_selectedValue.operatorName;
    let selectedremidiationStatus = this.selectState_selectedValue.remidiationStatus;
    let selectedStartTime = this.startTime;
    let selectedEndTime = this.endTime;

    if (selectedbuName === 'ALL') {
      selectedbuName = 'all';
    }
    if (selectedoperatorId === 'ALL') {
      selectedoperatorId = 'all';
    }
    if (selectedremidiationStatus === 'ALL') {
      selectedremidiationStatus = 'all';
    }

    // Getting the selected date and defaut date
    if ((this.startTime !== null && this.endTime !== null) && (this.startTime !== '' && this.endTime !== '') && (this.startTime !== undefined && this.endTime !== undefined)) {
      selectedStartTime = moment(this.startTime).format('YYYY/MM/DD HH:mm:ss');
      selectedEndTime = moment(this.endTime).format('YYYY/MM/DD HH:mm:ss');
    } else {
      selectedStartTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD 00:00:00');
      selectedEndTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss');
    }

    const inputGenerateReportObj = {
      'buName': selectedbuName,
      'operatorId': selectedoperatorId,
      'remidiationStatus': selectedremidiationStatus,
      'startDateTime': selectedStartTime,
      'endDateTime': selectedEndTime,
      'uIComponentID': 'ON_DEMAND_REPORT'
    };

    return this.onDemandReportingService.exportAll(inputGenerateReportObj).pipe(
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  };

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }

  /**
   * SHOW DATA IN GRID ON GENERATE REPORT
   */
  public generateReport() {
    if (this.onDemandReportForm.valid) {
      this.onDemandReportComponentsObj = this.onDemandReportForm.value;
      let buName = this.onDemandReportForm.controls.selectBU.value.buName;
      const operatorId = this.onDemandReportForm.controls.operatorId.value;
      let stateId = this.onDemandReportForm.controls.state.value;
      const startTime = this.startTime;
      const endTime = this.endTime;
      const buIDConst = this.onDemandReportForm.controls.selectBU.value.buId;
      const operatorIdConst = this.onDemandReportForm.controls.operatorId.value.operatorId;
      const remidiationStatusIdConst = this.onDemandReportForm.controls.state.value.remidiationStatusId;

      // Additional UI validation
      if ((buIDConst === -1) && (operatorIdConst === 'placeholder') && (remidiationStatusIdConst === -1)) {
        this.formErrors['selectBU'] = 'Please select the selectBU';
        this.formErrors['operatorId'] = 'Please select the operatorId';
        this.formErrors['state'] = 'Please select the state';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst != -1) && (operatorIdConst === 'placeholder') && (remidiationStatusIdConst === -1)) {
        this.formErrors['state'] = 'Please select the state';
        this.formErrors['operatorId'] = 'Please select the operatorId';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst === -1) && (operatorIdConst != 'placeholder') && (remidiationStatusIdConst === -1)) {
        this.formErrors['state'] = 'Please select the state';
        this.formErrors['selectBU'] = 'Please select the selectBU';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst === -1) && (operatorIdConst === 'placeholder') && (remidiationStatusIdConst != -1)) {
        this.formErrors['operatorId'] = 'Please select the operatorId';
        this.formErrors['selectBU'] = 'Please select the selectBU';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst != -1) && (operatorIdConst != 'placeholder') && (remidiationStatusIdConst === -1)) {
        this.formErrors['state'] = 'Please select the state';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst != -1) && (operatorIdConst === 'placeholder') && (remidiationStatusIdConst != -1)) {
        this.formErrors['operatorId'] = 'Please select the operatorId';
        this.onDemandReportForm.markAsDirty({});
        return;
      } else if ((buIDConst === -1) && (operatorIdConst != 'placeholder') && (remidiationStatusIdConst != -1)) {
        this.formErrors['selectBU'] = 'Please select the selectBU';
        this.onDemandReportForm.markAsDirty({});
        return;
      }

      if (buName === 'ALL') {
        buName = 'all';
      }

      if (stateId['remidiationStatus'] === 'ALL') {
        stateId = 'all';
      } else {
        stateId = stateId['remidiationStatus'];
      }

      /**
       * Request Obj
       * @type {{buName: any; operatorId: any}}
       */
      let inputGenerateReportObj;
      if ((startTime !== null && endTime !== null) && (startTime !== '' && endTime !== '') && (startTime !== undefined && endTime !== undefined)) {
        inputGenerateReportObj = {
          'buName': buName,
          'operatorId': operatorId['operatorId'],
          'remidiationStatus': stateId,
          'startDateTime': moment(startTime).format('YYYY/MM/DD HH:mm:ss'),
          'endDateTime': moment(endTime).format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'ON_DEMAND_REPORT'

        };
      } else {
        inputGenerateReportObj = {
          'buName': buName,
          'operatorId': operatorId['operatorId'],
          'remidiationStatus': stateId,
          'startDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD 00:00:00'),
          'endDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'ON_DEMAND_REPORT'
        };
      }
      // Invoking the services call to get the grid data values
      this.getOnDemandReportComponent(inputGenerateReportObj);

    }
  }

  /**
   * To generate SLA report
   * @param inputSearchReqObj
   */
  getOnDemandReportComponent(inputGenerateReportObj) {
    this.isGridLoadingIndicator = true;

    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    this.onDemandReportingService.getOnDemandReportingComponentGridValues(inputGenerateReportObj).pipe(
      tap(res => {
        this.girdData = res.data;
      })).subscribe(res => {
        if (((res.metadata.status).toUpperCase() === 'SUCCESS') && ((res.metadata.uIComponentID === 'ON_DEMAND_REPORT'))) {

          if (res.data.length > 0) {
            this.onDemandReportMapping = this.onDemandReportingService.pipe(map(data => process(res.data, this.gridState)));
            this.refresh();
          } else {
            this.onDemandReportMapping = this.onDemandReportingService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((res.metadata.status).toUpperCase() === 'ERROR') {
          this.onDemandReportMapping = this.onDemandReportingService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = res.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });

  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.onDemandReportingService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

  /**
   * Load the operator dropdown data
   */

  private loadOperatorDropDown() {
    this.operator_loading_indicator = true;
    const selectOperatorRequestObj = { 'uIComponentID': 'REPORT_OPERATORS' };
    this.onDemandReportingService.getOperatorDropDownValues(selectOperatorRequestObj).subscribe(operatorsDropDownResponse => {
      if (((operatorsDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (operatorsDropDownResponse.metadata.uIComponentID === 'REPORT_OPERATORS')) {
        operatorsDropDownResponse.data.forEach(operatorElement => {
          this.selectOperatorIdItems.push({ operatorId: operatorElement.operatorId, operatorName: operatorElement.operatorId });
        });
      }
      this.operator_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

  /**
   * Load the state dropdown data
   */

  private loadStateDropDown() {
    this.state_loading_indicator = true;
    const stateRequestObj = { 'uIComponentID': 'REPORT_REMIDIATION_STATUS' };
    this.onDemandReportingService.getStateDropDownValues(stateRequestObj).subscribe(stateDropDownResponse => {
      if (((stateDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (stateDropDownResponse.metadata.uIComponentID === 'REPORT_REMIDIATION_STATUS')) {
        stateDropDownResponse.data.forEach(stateElement => {
          this.selectStateItems.push(stateElement);
        });
      }
      this.state_loading_indicator = false;
    },
      error => console.log(error)
    );
  }


  /**
   * SLA REPORT RESET VALIDATION FORM
   * @param fb
   */
  public resetMe(fb) {
    this.onDemandReportForm.reset();
    this.isGridLoadingIndicator = false;
    this.onDemandReportMapping = this.onDemandReportingService.pipe(map(data => process([], this.gridState)));
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.onDemandReportingService.unsubscribe();
  }


}
