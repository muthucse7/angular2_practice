import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  Inject,
  ChangeDetectorRef,
  ViewChild,
  ViewEncapsulation,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { map } from 'rxjs/operators/map';
import { State, process } from '@progress/kendo-data-query';
import { SlaReportComponentModel } from '../../../models/report/sla/slaReportComponentModel';
import { SlaReportService } from '../../../services/slaReport.service';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { tap } from 'rxjs/operators';
import * as moment from 'moment';
import { DashBoardUtil } from '../../../utils/dashBoardUtil';
import { finalize } from 'rxjs/operators';


@Component({
  selector: 'slaReport',
  templateUrl: './slaReport.component.html',
  encapsulation: ViewEncapsulation.None,
})

export class SlaReportComponent implements OnInit, OnDestroy {
  slaReportForm: FormGroup;
  active = true;
  slaReportComponentsObj = new SlaReportComponentModel();
  private girdData: any[] = [];

  public title = 'SLA Report';
  public slaReportMapping: Observable<GridDataResult>;
  public gridState: State = { sort: [], skip: 0, take: 10 };
  private slaReportService: SlaReportService;
  public dashBoardUtil = new DashBoardUtil();

  public selectBUItems: Array<SelectBUDropdownModel> = [{ buName: 'ALL', buId: 0 }];
  public selectBU_selectedValue: SelectBUDropdownModel = { buName: 'ALL', buId: 0 };
  public defaultItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: -1 };

  public error: any = { isError: false, errorMessage: '' };

  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;

  public userNetworkId;
  public startTime;
  public endTime;
  public endDateMaxTime;

  public todaysDate = new DashBoardUtil().getCurrDate_MMDDYYYY_format();
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');

  // Chart Data
  public display_bar_chart_series = 'hidden';
  public categoriesItem = [];
  public minutes0To30 = [];
  public minutes30To60 = [];
  public minutes60To90 = [];
  public minutes90To120 = [];
  public minutes120To150 = [];
  public minutes150To180 = [];
  public minutes180To210 = [];
  public minutes210To240 = [];
  public minutes240Plus = [];
  public setHeight;
  public seriesChartColors = ['#00CC66', '#99FF66', '#0066CC', '#00B0F0', '#FFFF00', '#FFC000', '#FF99FF', '#CC0099', '#FF0000'];

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(SlaReportService) editServiceFactory: any, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.slaReportService = editServiceFactory();
  }

  public ngOnInit(): void {
    const value = localStorage.getItem('userNetworkId');
    if (value != null && value != '') {
      this.userNetworkId = JSON.parse(value);
    }
    this.initializeReportForm();
    this.loadSelectBUDropDown();

    this.endDateMaxTime = new Date(moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'));
  }

  private initializeReportForm() {
    this.slaReportForm = this.formBuilder.group({
      'selectBU': [this.slaReportComponentsObj.selectBU, [Validators.required]],
      'startTime': [this.slaReportComponentsObj.startTime],
      'endTime': [this.slaReportComponentsObj.endTime]
    });
    this.slaReportForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }

  onValueChanged(data?: any) {
    if (!this.slaReportForm) {
      return;
    }
    const form = this.slaReportForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'selectBU': ''
  };

  validationMessages = {
    'selectBU': {
      'required': 'Please select the selectBU'
    }
  };


  public onStateChange(state: State) {
    this.gridState = state;
    //this.generateReport();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.slaReportMapping = this.slaReportService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }


  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    // Getting selected values for exporting the XL 
    let selectedbuName = this.selectBU_selectedValue.buName;
    let selectedStartTime = this.startTime;
    let selectedEndTime = this.endTime;

    if (selectedbuName === 'ALL') {
      selectedbuName = 'all';
    }

    // Getting the selected date and defaut date
    if ((this.startTime !== null && this.endTime !== null) && (this.startTime !== '' && this.endTime !== '') && (this.startTime !== undefined && this.endTime !== undefined)) {
      selectedStartTime = moment(this.startTime).format('YYYY/MM/DD HH:mm:ss');
      selectedEndTime = moment(this.endTime).format('YYYY/MM/DD HH:mm:ss');
    } else if ((this.startTime === null && this.endTime !== null) || (this.startTime === '' && this.endTime !== '') || (this.startTime === undefined && this.endTime !== undefined)) {
      selectedStartTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD');
      selectedEndTime = moment(this.endTime).format('YYYY/MM/DD HH:mm:ss');
    } else if ((this.startTime !== null && this.endTime === null) || (this.startTime !== '' && this.endTime === '') || (this.startTime !== undefined && this.endTime === undefined)) {
      selectedStartTime = moment(this.startTime).format('YYYY/MM/DD HH:mm:ss');
      selectedEndTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss');
    } else {
      selectedStartTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD');
      selectedEndTime = moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss');
    }

    const inputGenerateReportObj = {
      'buName': selectedbuName,
      'startDateTime': selectedStartTime,
      'endDateTime': selectedEndTime,
      'uIComponentID': 'SLA_REPORT'
    };

    return this.slaReportService.exportAll(inputGenerateReportObj).pipe(
      finalize(() => {
        this.isGridLoadingIndicator = false;
      }));
  };

  /**
   * SHOW DATA IN GRID ON GENERATE REPORT
   */
  public generateReport() {
    if (this.slaReportForm.valid) {
      this.slaReportComponentsObj = this.slaReportForm.value;
      let buName = this.slaReportForm.controls.selectBU.value.buName;
      let buId = this.slaReportForm.controls.selectBU.value.buId;
      const startTime = this.startTime;
      const endTime = this.endTime;

      if (buName === 'ALL') {
        buName = 'all';
      }

      if (buId == -1) {
        this.slaReportForm.markAsDirty({});
        this.formErrors['selectBU'] = 'Please select the selectBU';
        return;
      } else {
        this.formErrors['selectBU'] = '';
      }

      /**
       * Request Obj
       * @type {{buName: any; operatorId: any}}
       */
      let inputGenerateReportObj;
      if ((startTime !== null && endTime !== null) && (startTime !== '' && endTime !== '') && (startTime !== undefined && endTime !== undefined)) {
        inputGenerateReportObj = {
          'buName': buName,
          'startDateTime': moment(startTime).format('YYYY/MM/DD HH:mm:ss'),
          'endDateTime': moment(endTime).format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'SLA_REPORT'
        };
      } else if ((startTime === null && endTime !== null) || (startTime === '' && endTime !== '') || (startTime === undefined && endTime !== undefined)) {
        inputGenerateReportObj = {
          'buName': buName,
          'startDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD'),
          'endDateTime': moment(endTime).format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'SLA_REPORT'
        };
      } else if ((startTime !== null && endTime === null) || (startTime !== '' && endTime === '') || (startTime !== undefined && endTime === undefined)) {
        inputGenerateReportObj = {
          'buName': buName,
          'startDateTime': moment(startTime).format('YYYY/MM/DD HH:mm:ss'),
          'endDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'SLA_REPORT'
        };
      } else {
        inputGenerateReportObj = {
          'buName': buName,
          'startDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD'),
          'endDateTime': moment(moment.now()).tz('America/Chicago').format('YYYY/MM/DD HH:mm:ss'),
          'uIComponentID': 'SLA_REPORT'
        };
      }
      // Invoking the services call to get the grid data values
      this.getSlaReportComponent(inputGenerateReportObj);

    }
  }

  /**
   * To generate SLA report
   * @param inputSearchReqObj
   */
  getSlaReportComponent(inputGenerateReportObj) {
    this.isGridLoadingIndicator = true;
   // Reset the paging
   this.gridState = {sort: [], skip: 0, take: 10};

    this.slaReportService.getSlaReportComponentGridValues(inputGenerateReportObj).pipe(
      tap(res => {
        this.girdData = res.data;
      })).subscribe(res => {
        if (((res.metadata.status).toUpperCase() === 'SUCCESS') && ((res.metadata.uIComponentID === 'SLA_REPORT'))) {

          if (res.data.length > 0) {
            this.slaReportMapping = this.slaReportService.pipe(map(data => process(res.data, this.gridState)));
            this.renderQualityChart(res.data);
            this.refresh();
          } else {
            this.slaReportMapping = this.slaReportService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((res.metadata.status).toUpperCase() === 'ERROR') {
          this.slaReportMapping = this.slaReportService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = res.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });

  }

  renderQualityChart(chartResponse) {
    this.display_bar_chart_series = 'show';
    this.clearExistingChartData();
    chartResponse.forEach(chartElement => {
      let total = null;
      if (chartElement.flag === 'C') {
        this.minutes0To30.push(chartElement.min0to30);
        this.minutes30To60.push(chartElement.min30to60);
        this.minutes60To90.push(chartElement.min60to90);
        this.minutes90To120.push(chartElement.min90to120);
        this.minutes120To150.push(chartElement.min120to150);
        this.minutes150To180.push(chartElement.min150to180);
        this.minutes180To210.push(chartElement.min180to210);
        this.minutes210To240.push(chartElement.min210to240);
        this.minutes240Plus.push(chartElement.min240plus);
        total = chartElement.min0to30 + chartElement.min30to60 + chartElement.min60to90 + chartElement.min90to120 + chartElement.min120to150 + chartElement.min150to180 + chartElement.min180to210 + chartElement.min210to240 + chartElement.min240plus;
        this.categoriesItem.push(chartElement.buName + " (Total = " + total + ")");
      }
      this.setHeight = 100 + (this.categoriesItem.length * 80);
    });
  }

  clearExistingChartData() {
    this.categoriesItem = [];
    this.minutes0To30 = [];
    this.minutes30To60 = [];
    this.minutes60To90 = [];
    this.minutes90To120 = [];
    this.minutes120To150 = [];
    this.minutes150To180 = [];
    this.minutes180To210 = [];
    this.minutes210To240 = [];
    this.minutes240Plus = [];
  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.slaReportService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }

  // TO GET BU ID OF DROPDOWN SELECTED VALUE
  public stateChangeBUDropDown() {
    return this.selectBU_selectedValue.buId;
  }

  /**
   * SLA REPORT RESET VALIDATION FORM
   * @param fb
   */
  public resetMe(fb) {
    this.slaReportForm.reset();
    this.isGridLoadingIndicator = false;
    this.clearExistingChartData();
    this.display_bar_chart_series = 'hidden';
    this.slaReportMapping = this.slaReportService.pipe(map(data => process([], this.gridState)));
    this.startTime = undefined;
    this.endTime = undefined;
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.slaReportService.unsubscribe();
  }


}
