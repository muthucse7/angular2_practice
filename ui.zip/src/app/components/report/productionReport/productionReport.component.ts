import { Observable } from 'rxjs/Observable';
import {
  Component,
  OnInit,
  ChangeDetectorRef, Inject, ViewChild, Output, EventEmitter, OnDestroy
} from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ProductionReportService } from '../../../services/productionReport.service';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';
import { DatePipe } from '@angular/common';
import { FailureMsgPopupComponent } from '../../../widgets/failureMsg-popup.component';
import { SessionTimeoutService } from '../../../services/sessionTimeout.service';
import { ProductionReportSearchComponentModel } from '../../../models/report/productionReport/productionReportSeachComponentModel';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'productionReport',
  templateUrl: './productionReport.component.html',
})

export class ProductionReportComponent implements OnInit, OnDestroy {
  public title = 'Production Report';
  public prodReportGrid: Observable<GridDataResult>;
  private productionReportService: ProductionReportService;
  productionReportSearchComponentModel = new ProductionReportSearchComponentModel();
  public prodReportForm: FormGroup;
  public currentDateTime = moment(new Date()).format('YYYYMMDD_HHmmss');

  public error: any = { isError: false, errorMessage: '' };
  public errormsg1: any = { isError: false, errorMessage: '' };
  public errormsg2: any = { isError: false, errorMessage: '' };

  public selectBUItems: Array<SelectBUDropdownModel> = [{ buName: 'ALL', buId: 0 }];
  public selectBU_selectedValue: SelectBUDropdownModel = { buName: 'ALL', buId: 0 };
  public defaultBUItem: SelectBUDropdownModel = { buName: 'Please select BU', buId: -1 };

  public min: Date = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() - 7);
  public max: Date = new Date(this.getCurrDate());

  public gridState: State = { sort: [], skip: 0, take: 10 };
  private girdData: any[] = [];

  public isNew: boolean;
  public buDropdown_loading_indicator: Boolean = false;
  public isGridLoadingIndicator: Boolean = false;
  public startDateYYYYMMDD;
  public endDateYYYYDDMM;

  // Trigger error message popup if the services is throwing an error
  @ViewChild('failureMsgPopup')
  private failureMsgPopup: FailureMsgPopupComponent;
  public errorMessage;

  // Session timeout trigger event on success of webservice
  @Output() moreTime: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(ProductionReportService) productionReportServiceFactory: any, private datePipe: DatePipe, private formBuilder: FormBuilder, private cd: ChangeDetectorRef, private _sessionTimeoutService: SessionTimeoutService) {
    this.productionReportService = productionReportServiceFactory();
  }

  public ngOnInit(): void {
    this.initiateProdReportSearchForm();
    this.getCurrDate();
    this.loadSelectBUDropDown();
  }

  getCurrDate() {
    const dateMaxLimit = new Date();
    return dateMaxLimit;
  }

  public refresh() {
    this.cd.detectChanges();
    this.cd.markForCheck();
  }

  initiateProdReportSearchForm(): void {
    this.prodReportForm = this.formBuilder.group({
      'selectBU': [this.productionReportSearchComponentModel.buName, [Validators.required]],
      'startDate': [this.productionReportSearchComponentModel.startDateTime, [Validators.required]],
      'endDate': [this.productionReportSearchComponentModel.endDateTime, [Validators.required]]
    });

    this.prodReportForm.valueChanges.subscribe(data => this.onValueChanged(data));
    this.onValueChanged();
  }


  onValueChanged(data?: any) {
    if (!this.prodReportForm) {
      return;
    }
    const form = this.prodReportForm;

    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      this.error = '';
      const control = form.get(field);

      if (control && control.invalid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  // Setting XL sheet name 
  public onExcelExport(e: any): void {
    const rows = e.workbook.sheets[0].rows;
    // set alternating row color
    let altIdx = 0;
    rows.forEach((row) => {
      if (row.type === 'data') {
        if (altIdx % 2 !== 0) {
          row.cells.forEach((cell) => {
            cell.background = '#aabbcc';
          });
        }
        altIdx++;
      }
    });
  }


  formErrors = {
    'selectBU': '',
    'startDate': '',
    'endDate': ''
  };

  validationMessages = {
    'selectBU': {
      'required': 'Please select the selectBU'
    },
    'startDate': {
      'required': 'Please select the Start Date'
    },
    'endDate': {
      'required': 'Please select the End Date'
    }
  };

  public onStateChange(state: State) {
    this.gridState = state;
    //this.onSearch();
    if ((this.girdData != undefined) && (this.girdData.length)) {
      let sortedData = this.girdData.sort((a, b) => {
        if (a.name < b.name) return -1;
        else if (a.name > b.name) return 1;
        else return 0;
      });
      return this.prodReportGrid = this.productionReportService.pipe(map(response => process(sortedData, this.gridState)));
    }
  }

  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
  }

  public onSearch(): void {
    if (this.prodReportForm.valid) {
      let buId = this.prodReportForm.controls.selectBU.value.buId;
      let buName = this.prodReportForm.controls.selectBU.value.buName;
      let startDate = this.prodReportForm.controls.startDate.value;
      let endDate = this.prodReportForm.controls.endDate.value;
      let inputRequestObj;

      if (buName === 'ALL') {
        buName = 'all';
      }

      if (buId == -1) {
        this.prodReportForm.markAsDirty({});
        this.formErrors['selectBU'] = 'Please select the selectBU';
        return;
      }

      if (startDate != null || startDate != undefined) {
        if (endDate == null || endDate == undefined) {
          this.errormsg2 = { isError: true, errorMessage: 'Please select End Date' };
          this.errormsg1 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if (endDate != null || endDate != undefined) {
        if (startDate == null || startDate == undefined) {
          this.errormsg1 = { isError: true, errorMessage: 'Please select Start Date' };
          this.errormsg2 = { isError: false, errorMessage: '' };
          return;
        }
      }
      if ((endDate != null || endDate != undefined) && (startDate != null || startDate != undefined)) {
        this.errormsg1 = { isError: false, errorMessage: '' };
        this.errormsg2 = { isError: false, errorMessage: '' };
      }

      // Compare To date and from date
      if (new Date(this.prodReportForm.controls['endDate'].value) < new Date(this.prodReportForm.controls['startDate'].value)) {
        this.error = { isError: true, errorMessage: 'End date can not before start date' };
        return;
      } else {
        this.error = { isError: false, errorMessage: '' };
      }

      if (startDate != null) {

        this.startDateYYYYMMDD = moment(startDate).format('YYYY-MM-DD');
      } else {
        this.startDateYYYYMMDD = null;
      }

      if (endDate != null) {
        this.endDateYYYYDDMM = moment(endDate).format('YYYY-MM-DD');
      } else {
        this.endDateYYYYDDMM = null;
      }

      inputRequestObj = {
        'buName': buName,
        'startDateTime': this.startDateYYYYMMDD,
        'endDateTime': this.endDateYYYYDDMM,
        'uIComponentID': 'PRODUCTION_REPORT'
      };
      this.getProdReportGridData(inputRequestObj);
    }
  }

  private getProdReportGridData(inputRequestObj) {
    this.isGridLoadingIndicator = true;
    // Reset the paging
    this.gridState = { sort: [], skip: 0, take: 10 };

    this.productionReportService.getProdReportGridComponent(inputRequestObj)
      .pipe(
        tap(prodReportGridData => {
          this.girdData = prodReportGridData.data;
        }))
      .subscribe(prodReportGridData => {
        if (((prodReportGridData.metadata.status).toUpperCase() === 'SUCCESS') && ((prodReportGridData.metadata.uIComponentID === 'PRODUCTION_REPORT'))) {

          if (prodReportGridData.data.length > 0) {
            this.prodReportGrid = this.productionReportService.pipe(map(data => process(prodReportGridData.data, this.gridState)));
            this.refresh();
          } else {
            this.prodReportGrid = this.productionReportService.pipe(map(data => process([], this.gridState)));
            this.failureMsgPopup.open();
            this.errorMessage = 'Sorry! There are no data available for this search criteria.';
          }

        } else if ((prodReportGridData.metadata.status).toUpperCase() === 'ERROR') {
          this.prodReportGrid = this.productionReportService.pipe(map(data => process([], this.gridState)));
          this.failureMsgPopup.open();
          this.errorMessage = prodReportGridData.metadata.errorMsg[0].errorDesc;
        }
        this.isGridLoadingIndicator = false;
        this._sessionTimeoutService.filter('Session timeout Reset called');
      });
  }

  // Export XL fetching all the data from the database
  public fetchAll = (): Observable<any> => {
    this.isGridLoadingIndicator = true;

    if (this.prodReportForm.valid) {
      let buName = this.prodReportForm.controls.selectBU.value.buName;
      let startDate = this.prodReportForm.controls.startDate.value;
      let endDate = this.prodReportForm.controls.endDate.value;

      if (buName === 'ALL') {
        buName = 'all';
      }

      if (startDate != null) {
        this.startDateYYYYMMDD = moment(startDate).format('YYYY-MM-DD');
      } else {
        this.startDateYYYYMMDD = null;
      }

      if (endDate != null) {
        this.endDateYYYYDDMM = moment(endDate).format('YYYY-MM-DD');
      } else {
        this.endDateYYYYDDMM = null;
      }

      const inputGenerateReportObj = {
        'buName': buName,
        'startDateTime': this.startDateYYYYMMDD,
        'endDateTime': this.endDateYYYYDDMM,
        'uIComponentID': 'PRODUCTION_REPORT'
      };
      return this.productionReportService.getProdReportGridComponent(inputGenerateReportObj).pipe(
        finalize(() => {
          this.isGridLoadingIndicator = false;
        }));
    }
  };


  /**
   * SEARCH COMPONENT RESET VALIDATION FORM
   *
   */
  public resetMe() {
    this.prodReportForm.reset();
    this.prodReportGrid = this.productionReportService.pipe(map(data => process([], this.gridState)));
    this.isGridLoadingIndicator = false;
    this.errormsg1 = '';
    this.errormsg2 = '';
    this.error = '';
  }

  /**
   *  Unsubscribe to ensure no memory leaks
   */
  ngOnDestroy() {
    this.productionReportService.unsubscribe();
  }

  /**
   * LOAD THE BU DROPDOWN VALUES
   */
  private loadSelectBUDropDown() {
    this.buDropdown_loading_indicator = true;
    const selectBURequestObj = { uIComponentID: 'AUTHORIZATION_BU' };
    this.productionReportService.getSelectBUDropDownValues(selectBURequestObj).subscribe(selectBUDropDownResponse => {
      if (((selectBUDropDownResponse.metadata.status).toUpperCase() === 'SUCCESS') && (selectBUDropDownResponse.metadata.uIComponentID === 'AUTHORIZATION_BU')) {
        selectBUDropDownResponse.data.forEach(selectBUElement => {
          this.selectBUItems.push(selectBUElement);
        });
      }
      this.buDropdown_loading_indicator = false;
    },
      error => console.log(error)
    );
  }
  
  public convertDateToYYYYMMDDFormat(dateFormat){
    return moment(dateFormat).format('YYYYMMDD');
  }

}

