import {Component, Input} from '@angular/core';

@Component({
  selector: 'success-msg-popup',
  template: `
    <div id="successMsgPopup" class="example-wrapper">
      <kendo-dialog class="font14" title="Success" *ngIf="opened" (close)="close('cancel')" [minWidth]="250">
        <p class="failureMsgPopup_body success_msg_text margin_top20px" *ngIf="successMessage!='' ">
          <span><img src="./assets/images/success_icon.png" alt="" class="icons icons-alert success_msgIcon"/></span>
          {{successMessage}}</p>
        <kendo-dialog-actions class="error_msg_btn">
          <button class="btn primary_btn font12 margin_left75per width100px" (click)="close('yes')">Ok</button>
        </kendo-dialog-actions>
      </kendo-dialog>
    </div>
  `
})
export class SuccessMsgPopupComponent {

  @Input() successMessage;
  @Input() opened: Boolean = false;

  public close(status) {
    console.log(`Dialog result: ${status}`);
    this.opened = false;
  }

  public open() {
    this.opened = true;
  }
}
