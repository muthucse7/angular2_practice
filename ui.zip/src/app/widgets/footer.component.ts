import {Component} from '@angular/core';

@Component({
  selector: 'dashboard-footer',
  template: `
    <div class="clearfix">&nbsp;</div>
    <div class="clearfix">&nbsp;</div>
    <div class="clearfix">&nbsp;</div>
    <div class="footer_fixed_bottom">
      <footer class="footer_content">
        <span class="inner-footer">Customer Research Screening Dashboard &#169; {{currentYear}} U.S. BanK. All Rights Reserved.</span>
        <img class="footer_line" src="./assets/images/journeyline.svg"/>
      </footer>
    </div> `
})

export class FooterComponent {
  public currentYear = (new Date()).getFullYear();
}
