import {Component, ChangeDetectionStrategy, Input} from '@angular/core';

@Component({
  selector: 'line-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './lineChart.component.html'
})

export class LineChartComponent {

  @Input() businessUnit: any[];
  @Input() chartData: any[];
  @Input() seriesColors: String;
  @Input() title: String;

  public labelContent(e: any): string {
    return e.category;
  }
}
