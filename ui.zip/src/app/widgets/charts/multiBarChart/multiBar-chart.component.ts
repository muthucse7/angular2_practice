import {Component, Input} from '@angular/core';
import { SeriesLabels } from '@progress/kendo-angular-charts';

@Component({
  selector: 'multiBar-chart',
  templateUrl: './multiBar-chart.component.html'
})

export class MultiBarChartComponent {

  @Input() public categories;
  @Input() public completedStatus;
  @Input() public failedStatus;
  @Input() public pendingReviewStatus;

  public seriesLabels: SeriesLabels = {
    padding: 3,
    font: 'bold 16px Arial, "Helvetica Neue", Helvetica, Roboto, sans-serif'
  }
}
