import {Component, ChangeDetectionStrategy, Input} from '@angular/core';

@Component({
  selector: 'donut-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './donut-chart.component.html'
})

export class DonutChartComponent {

  @Input() messageWhitsData: any[];
  @Input() donutChartColors: any[];
  @Input() title: String;

  public labelContent(e: any): string {
    return e.category;
  }
}
