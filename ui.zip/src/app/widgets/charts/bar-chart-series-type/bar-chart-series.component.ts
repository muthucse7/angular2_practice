import {Component, Input} from '@angular/core';
import { SeriesLabels } from '@progress/kendo-angular-charts';

@Component({
  selector: 'bar-chart-series',
  templateUrl: './bar-chart-series.component.html'
})

export class BarChartSeriesComponent {

  @Input() categoriesItem = [];
  @Input() minutes0To30 = [];
  @Input() minutes30To60 = [];
  @Input() minutes60To90 = [];
  @Input() minutes90To120 = [];
  @Input() minutes120To150 = [];
  @Input() minutes150To180 = [];
  @Input() minutes180To210 = [];
  @Input() minutes210To240 = [];
  @Input() minutes240Plus = [];
  @Input() setHeight;

  @Input() seriesChartColors: any [];

  public seriesLabels: SeriesLabels = {
    padding: 3,
    font: 'bold 16px Arial, "Helvetica Neue", Helvetica, Roboto, sans-serif'
  }

}
