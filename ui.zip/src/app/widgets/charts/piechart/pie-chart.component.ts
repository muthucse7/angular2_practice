import {Component, Input} from '@angular/core';

@Component({
  selector: 'pie-chart',
  templateUrl: './pie-chart.component.html'
})
export class PieChartComponent {

  @Input() public pieChartData: any[];

  @Input() public pieChartColors: any[];

  @Input() title: String;

  public labelContent(e: any): string {
    return e.category;
  }
}
