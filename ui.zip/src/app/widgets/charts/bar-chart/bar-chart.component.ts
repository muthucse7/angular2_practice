import {Component, Input} from '@angular/core';
import { SeriesLabels } from '@progress/kendo-angular-charts';

@Component({
  selector: 'bar-chart',
  templateUrl: './bar-chart.component.html'
})


export class BarChartComponent {

  @Input() public messageReceived;
  @Input() public messageWithNoHits;
  @Input() public messageWithHits;
  @Input() public totalHits;
  @Input() public hitsPendingReview;

  public labelContent(e: any): string {
    return e.category;
  }
  
  public seriesLabels: SeriesLabels = {
    visible: true, 
    padding: 3,
    font: 'bold 16px Arial, "Helvetica Neue", Helvetica, Roboto, sans-serif'
  }
}
