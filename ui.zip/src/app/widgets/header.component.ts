import { Component, Input, OnInit } from "@angular/core";

@Component({
  selector: "dashboard-header",
  template: `
    <div id="navbar_mainContent">
      <nav class="navbar">
        <div class="container-fluid">
          <div class="header_left_section">
            <div class="navbar-header usbank_logo">
              <img
                src="./assets/images/usbank-logo.png"
                alt=""
                class="icons icons-user"
              />
            </div>
            <ul class="nav navbar-nav">
              <li
              class="dropdown"
              *ngIf="isKYCMenuEnabled"
              [routerLinkActiveOptions]="{ exact: true }"
              routerLinkActive="active">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#"
                >Customer Details from FCTY Pending Alerts<span class="caret"></span
              ></a>
              <ul class="dropdown-menu multi-level">
                <li *ngIf="isCustomerResearchEnabled">
                  <a routerLink="/customerResearch">Customer Research</a>
                </li>
                <li *ngIf="isCustomerSearchEnabled">
                <a routerLink="/customerSearch">Customer Search</a>
              </li>
              </ul>
            </li>
            </ul>
          </div>
          <div class="user_profile_section pull-right">
            <span class="pull-right" aria-hidden="true" (click)="logout()">
              <img
                src="./assets/images/ico-logout-24.png"
                alt="dashboard logout"
                class="logout_icon mouse_cursor"
              />
            </span>

            <div class="display_userName pull-right">
              <span *ngIf="userName != ''"> Hello, {{ userName }}</span> <br />
              <span class="display_buName" *ngIf="businessUnitName != ''">
                <!-- <span *ngIf="isBuSupportUnit" class="buSupport-font {{isBuSupportUnit? 'show' : 'hidden'}}">SupportUnit : {{unitName}} | </span>-->
                <span class="buSupport-font">ROLE: {{ userRole }} | </span>
                UNIT: {{ businessUnitName }}
                <span
                  href="#"
                  (click)="multiBuSelection()"
                  class="white-font mouse_cursor pull-right mutilBuSelect_link {{
                    isMultiBUAccess ? 'show' : 'hidden'
                  }}"
                  >| Switch BU</span
                >
              </span>
            </div>

            <span class="pull-right" aria-hidden="true">
              <img
                src="./assets/images/user_icon.png"
                alt="user icon"
                class="profile_icon"
              />
            </span>
          </div>
        </div>
      </nav>
    </div>

    <kendo-dialog
      title="Please confirm"
      *ngIf="opened"
      (close)="close('cancel')"
      [minWidth]="250"
      [width]="423"
    >
      <p class="confirmation_popupText">
        The application session will be cleared, Are you sure you want to
        logout?
      </p>
      <kendo-dialog-actions>
        <button
          class="yes_update_button"
          kendoButton
          (click)="close('yes')"
          primary="true"
        >
          Yes
        </button>
        <button
          class="no_cancel_button"
          kendoButton
          (click)="close('no')"
          primary="true"
        >
          No
        </button>
      </kendo-dialog-actions>
    </kendo-dialog>
  `
})
export class HeaderComponent {
  constructor() {}

  @Input() userName;
  @Input() businessUnitName;
  @Input() buId;
  @Input() userNetworkId;
  @Input() isMultiBUAccess;
  @Input() isBuSupportUnit;
  @Input() unitName;
  @Input() userRole;

  // Parent menu items
  @Input() isAdminEnabled;
  @Input() isSearchEnabled;
  @Input() isRescanEnabled;
  @Input() isReportEnabled;

  // Child menu items
  @Input() isBusinessUnitEnabled;
  @Input() isCrudConfigEnabled;
  @Input() isFofTestDataConfigEnabled;
  @Input() isManageBUEnabled;
  @Input() isManageUserEnabled;
  @Input() isManageRoleEnabled;
  @Input() isManageUserRoleEnabled;
  @Input() isManageFunctionEnabled;
  @Input() isTnxRescanningEnabled;
  @Input() isLogSearchEnabled;
  @Input() isSlaReportEnabled;
  @Input() isPerformanceManagementReportEnabled;
  @Input() isOnDemandReportingEnabled;
  @Input() isProductionReportEnabled;
  @Input() isApplicationComponentsEnabled;
  @Input() isUserActivityEnabled;
  @Input() isAutoSuspendConfigEnabled;
  @Input() isAutoCancellationConfigEnabled;
  @Input() isRescreenReconciliationEnabled;
  @Input() isCustomerSearchEnabled;
  @Input() isCustomerResearchEnabled;
  @Input() isKYCMenuEnabled;

  public buSupportUnit: Boolean = true;
  public opened: Boolean = false;

  public close(status) {
    this.opened = false;
    if (status.toUpperCase() === "YES") {
      localStorage.clear();
      window.location.href =
        "/rtss/logout.jsp?end_url=/rtss/logoutconfirmation.jsp";
    }
  }

  public logout() {
    this.opened = true;
  }

  public multiBuSelection() {
    localStorage.clear();
    // Sandbox and local Env
    window.location.href =
      "/rtss/multiBUSelect.jsp?userId=" +
      this.userNetworkId +
      "&buName=" +
      this.businessUnitName +
      "&buId=" +
      this.buId;

    // Other env
    // window.location.href = "/rtss/multiBUSelect.jsp?buName="+this.businessUnitName+'&buId='+this.buId;
  }
}
